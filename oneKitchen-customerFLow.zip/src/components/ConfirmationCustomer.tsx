import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./ConfirmationCustomer.css";

type ConfirmationCustomerType = {
  onClose?: () => void;
};

const ConfirmationCustomer: FunctionComponent<ConfirmationCustomerType> = ({
  onClose,
}) => {
  const navigate = useNavigate();

  const onYesClick = useCallback(() => {
    navigate("/customerprofile");
  }, [navigate]);

  return (
    <div className="confirmation-customer">
      <div className="are-you-sure">Are you sure about these changes?</div>
      <button className="yes" onClick={onYesClick}>
        Yes
      </button>
      <button className="no" onClick={onClose}>
        No
      </button>
      <img className="line-16-icon" alt="" src="/line16.svg" />
      <img className="icon-warning-2" alt="" src="/iconwarning2.svg" />
    </div>
  );
};

export default ConfirmationCustomer;
