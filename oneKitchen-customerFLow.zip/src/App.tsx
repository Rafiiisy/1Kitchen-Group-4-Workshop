import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import SplashScreenintroonce from "./pages/SplashScreenintroonce";
import CustomerProfile from "./pages/CustomerProfile";
import SuccessLogIn from "./pages/SuccessLogIn";
import CustomerSearchCategory2 from "./pages/CustomerSearchCategory2";
import SuccessSignUp from "./pages/SuccessSignUp";
import SuccessCustomer from "./pages/SuccessCustomer";
import CustomerProfileEditProfile from "./pages/CustomerProfileEditProfile";
import CustomerOrder1 from "./pages/CustomerOrder1";
import CustomerOrderMain from "./pages/CustomerOrderMain";
import CustomerHome from "./pages/CustomerHome";
import SEARCH from "./pages/SEARCH";
import CustomerOrderSuccession from "./pages/CustomerOrderSuccession";
import Login from "./pages/Login";
import SignUp from "./pages/SignUp";
import SignUp2 from "./pages/SignUp2";
import CustomerProfileFeedback from "./pages/CustomerProfileFeedback";
import CustomerOrderCart from "./pages/CustomerOrderCart";
import LogInSelection from "./pages/LogInSelection";
import { useEffect } from "react";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/customerprofile":
        title = "";
        metaDescription = "";
        break;
      case "/success-log-in":
        title = "";
        metaDescription = "";
        break;
      case "/customersearchcategory-2":
        title = "";
        metaDescription = "";
        break;
      case "/success-sign-up":
        title = "";
        metaDescription = "";
        break;
      case "/successcustomer":
        title = "";
        metaDescription = "";
        break;
      case "/customerprofileedit-profile":
        title = "";
        metaDescription = "";
        break;
      case "/customerorder-1":
        title = "";
        metaDescription = "";
        break;
      case "/customerorder-main":
        title = "";
        metaDescription = "";
        break;
      case "/home-customer":
        title = "";
        metaDescription = "";
        break;
      case "/customersearch":
        title = "";
        metaDescription = "";
        break;
      case "/customerordersuccession":
        title = "";
        metaDescription = "";
        break;
      case "/login":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-2":
        title = "";
        metaDescription = "";
        break;
      case "/customerprofilefeedback":
        title = "";
        metaDescription = "";
        break;
      case "/customerordercart":
        title = "";
        metaDescription = "";
        break;
      case "/loginselection":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag: HTMLMetaElement | null = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<SplashScreenintroonce />} />
      <Route path="/customerprofile" element={<CustomerProfile />} />
      <Route path="/success-log-in" element={<SuccessLogIn />} />
      <Route
        path="/customersearchcategory-2"
        element={<CustomerSearchCategory2 />}
      />
      <Route path="/success-sign-up" element={<SuccessSignUp />} />
      <Route path="/successcustomer" element={<SuccessCustomer />} />
      <Route
        path="/customerprofileedit-profile"
        element={<CustomerProfileEditProfile />}
      />
      <Route path="/customerorder-1" element={<CustomerOrder1 />} />
      <Route path="/customerorder-main" element={<CustomerOrderMain />} />
      <Route path="/home-customer" element={<CustomerHome />} />
      <Route path="/customersearch" element={<SEARCH />} />
      <Route
        path="/customerordersuccession"
        element={<CustomerOrderSuccession />}
      />
      <Route path="/login" element={<Login />} />
      <Route path="/sign-up" element={<SignUp />} />
      <Route path="/sign-up-2" element={<SignUp2 />} />
      <Route
        path="/customerprofilefeedback"
        element={<CustomerProfileFeedback />}
      />
      <Route path="/customerordercart" element={<CustomerOrderCart />} />
      <Route path="/loginselection" element={<LogInSelection />} />
    </Routes>
  );
}
export default App;
