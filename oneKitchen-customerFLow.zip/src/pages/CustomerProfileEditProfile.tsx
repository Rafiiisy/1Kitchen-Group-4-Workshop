import { FunctionComponent, useState, useCallback } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Form } from "react-bootstrap";
import ConfirmationCustomer from "../components/ConfirmationCustomer";
import PortalPopup from "../components/PortalPopup";
import { useNavigate } from "react-router-dom";
import "./CustomerProfileEditProfile.css";

const CustomerProfileEditProfile: FunctionComponent = () => {
  const [isConfirmationCustomerPopupOpen, setConfirmationCustomerPopupOpen] =
    useState(false);
  const navigate = useNavigate();

  const openConfirmationCustomerPopup = useCallback(() => {
    setConfirmationCustomerPopupOpen(true);
  }, []);

  const closeConfirmationCustomerPopup = useCallback(() => {
    setConfirmationCustomerPopupOpen(false);
  }, []);

  const onArrowleftIconClick = useCallback(() => {
    navigate("/customerprofile");
  }, [navigate]);

  return (
    <>
      <div className="customer-profile-edit-profile">
        <img className="avatar-icon1" alt="" src="/avatar1.svg" />
        <div className="credentials">
          <div className="text-fields">
            <Form.Group className="text-field-formgroup">
              <Form.Label>Name</Form.Label>
              <Form.Control type="text" placeholder="John Doe" />
            </Form.Group>
            <Form.Group className="text-field-formgroup">
              <Form.Label>Email</Form.Label>
              <Form.Control type="email" placeholder="johndoe123@gmail.com" />
            </Form.Group>
            <Form.Group className="text-field-formgroup">
              <Form.Label>Phone No.</Form.Label>
              <Form.Control type="tel" placeholder="+92 3014124781" />
            </Form.Group>
            <Form.Group className="text-field-formgroup">
              <Form.Label>Password</Form.Label>
              <Form.Control type="password" placeholder="Input placeholder" />
            </Form.Group>
          </div>
        </div>
        <button className="buttons" onClick={openConfirmationCustomerPopup}>
          <div className="button">
            <b className="button1">Save</b>
          </div>
        </button>
        <div className="spacer">
          <div className="spacer1" />
        </div>
        <div className="app-barcontainertop-bar">
          <div className="bg" />
          <b className="headline">Edit Account</b>
          <img
            className="arrowleft-icon"
            alt=""
            src="/arrowleft.svg"
            onClick={onArrowleftIconClick}
          />
          <div className="text-or-buttons">
            <div className="skip">Skip</div>
            <div className="buttons1">
              <img className="heart-icon" alt="" src="/heart.svg" />
              <img className="heart-icon" alt="" src="/sharenetwork.svg" />
              <img className="heart-icon" alt="" src="/dotsthreevertical.svg" />
            </div>
          </div>
        </div>
      </div>
      {isConfirmationCustomerPopupOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeConfirmationCustomerPopup}
        >
          <ConfirmationCustomer onClose={closeConfirmationCustomerPopup} />
        </PortalPopup>
      )}
    </>
  );
};

export default CustomerProfileEditProfile;
