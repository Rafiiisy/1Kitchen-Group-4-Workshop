import { FunctionComponent, useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./SuccessLogIn.css";

const SuccessLogIn: FunctionComponent = () => {
  const navigate = useNavigate();
  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add("animate");
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  const onContinueToLogInClick = useCallback(() => {
    navigate("/home-customer");
  }, [navigate]);

  return (
    <div className="success-log-in">
      <div className="success-parent">
        <b className="success">Success!</b>
        <b className="you-successfully-logged">{`You successfully logged in to your account! `}</b>
      </div>
      <div className="asset-1-1-parent">
        <img
          className="asset-1-1-icon"
          alt=""
          src="/asset-1-1.svg"
          data-animate-on-scroll
        />
        <div className="continue-to-log-in">
          <b className="continue-to-log">Continue to</b>
        </div>
        <button
          className="continue-to-log-in1"
          onClick={onContinueToLogInClick}
        >
          <b className="continue-to-log1">Home</b>
        </button>
      </div>
    </div>
  );
};

export default SuccessLogIn;
