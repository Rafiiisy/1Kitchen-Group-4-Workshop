import { FunctionComponent, useCallback } from "react";
import { Input } from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";
import "./SignUp2.css";

const SignUp2: FunctionComponent = () => {
  const navigate = useNavigate();

  const onSignUpButtonClick = useCallback(() => {
    navigate("/success-sign-up");
  }, [navigate]);

  const onRectangle4400Click = useCallback(() => {
    navigate("/login");
  }, [navigate]);

  return (
    <div className="sign-up-2">
      <header className="frame-30">
        <div className="frame-24-containertop-bar">
          <b className="welcome1">Welcome!</b>
          <div className="we-just-need">We just need a bit more info!</div>
        </div>
      </header>
      <div className="number-plate-component-inp-parent">
        <b className="number-plate">{`Home address `}</b>
        <Input
          className="frame-37462"
          variant="flushed"
          width="304px"
          focusBorderColor="#2c7e35"
          placeholder="Enter your Home address"
          w="304px"
        />
        <b className="city-componentinput-city-container">
          <span>{`City `}</span>
          <span className="span">*</span>
        </b>
        <Input
          className="frame-37463"
          variant="flushed"
          width="304px"
          focusBorderColor="#2c7e35"
          placeholder="Enter your City"
          w="304px"
        />
        <button className="sign-up-button" onClick={onSignUpButtonClick}>
          <div className="rectangle-44004" onClick={onRectangle4400Click} />
          <b className="sign-up2">Sign Up</b>
        </button>
        <div className="group-37419">
          <div className="group-37301">
            <div className="by-clicking-on-container">
              <span>{`By clicking on ‘sign up’, you’re agreeing to the Chunky app `}</span>
              <span className="terms-of-service">Terms of Service</span>
              <span>{` and `}</span>
              <span className="terms-of-service">Privacy</span>
              <span>{` `}</span>
              <span className="terms-of-service">Policy</span>
            </div>
          </div>
          <img className="vector-icon3" alt="" src="/vector2.svg" />
        </div>
        <b className="phone-number-container">
          <span>{`Phone number `}</span>
          <span className="span">*</span>
        </b>
        <Input
          className="frame-37464"
          variant="flushed"
          width="304px"
          focusBorderColor="#2c7e35"
          type="number"
          placeholder="Enter your phone number"
          w="304px"
        />
      </div>
    </div>
  );
};

export default SignUp2;
