import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./CustomerHome.css";

const CustomerHome: FunctionComponent = () => {
  const navigate = useNavigate();

  const onCardsImageClick = useCallback(() => {
    navigate("/customerhomecategory-1");
  }, [navigate]);

  const onImgClick = useCallback(() => {
    navigate("/customerorder-main");
  }, [navigate]);

  const onSearchButtonClick = useCallback(() => {
    navigate("/customersearch");
  }, [navigate]);

  const onAccountButtonClick = useCallback(() => {
    navigate("/customerprofile");
  }, [navigate]);

  const onWriteTextHerecomponentiClick = useCallback(() => {
    navigate("/customersearch");
  }, [navigate]);

  return (
    <div className="customer-home">
      <div className="banners-parent">
        <div className="banners">
          <div className="carousel-dots">
            <img className="carousel-dot-icon" alt="" src="/carouseldot.svg" />
            <img className="carousel-dot-icon" alt="" src="/carouseldot1.svg" />
            <img className="carousel-dot-icon" alt="" src="/carouseldot.svg" />
          </div>
        </div>
        <div className="frame-61container">
          <button className="cards-image" onClick={onCardsImageClick}>
            <img className="img-blur-icon" alt="" src="/imgblur@2x.png" />
            <img className="img-icon5" alt="" src="/img5@2x.png" />
            <div className="text">
              <div className="title7">Food</div>
              <div className="subtitle">Order food you love</div>
            </div>
          </button>
          <div className="cards-image1">
            <img className="img-blur-icon1" alt="" src="/imgblur1@2x.png" />
            <img className="img-icon5" alt="" src="/img6@2x.png" />
            <div className="text">
              <div className="title8">Drinks</div>
              <div className="subtitle1">To quench your thirst</div>
            </div>
          </div>
          <div className="cards-image2">
            <img className="img-blur-icon2" alt="" src="/imgblur2@2x.png" />
            <img className="img-icon5" alt="" src="/img7@2x.png" />
            <div className="text">
              <div className="title8">Deserts</div>
              <div className="subtitle1">Something Sweet</div>
            </div>
          </div>
        </div>
        <div className="frame-54containersliderdefa">
          <div className="content12">
            <div className="cards-food">
              <button className="img" onClick={onImgClick}>
                <img className="image-icon2" alt="" src="/image2@2x.png" />
                <div className="tag">
                  <b className="min1">40 min</b>
                </div>
                <img className="button-icon" alt="" src="/buttonicon.svg" />
              </button>
              <div className="content13">
                <div className="text3">
                  <b className="popperoni-pizza">Daily Deli</b>
                  <div className="daily-deli-1">Johar Town</div>
                </div>
                <div className="ratings1">
                  <img className="star-icon1" alt="" src="/star1.svg" />
                  <b className="b6">4.8</b>
                </div>
              </div>
            </div>
            <div className="cards-food1">
              <div className="img1">
                <img className="image-icon2" alt="" src="/image3@2x.png" />
                <div className="tag">
                  <b className="min2">12 min</b>
                </div>
                <img className="button-icon" alt="" src="/buttonicon.svg" />
              </div>
              <div className="content14">
                <div className="text3">
                  <b className="popperoni-pizza">Rice Bowl</b>
                  <div className="daily-deli-1">Wapda Town</div>
                </div>
                <div className="ratings1">
                  <img className="star-icon1" alt="" src="/star1.svg" />
                  <b className="b6">4.8</b>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="frame-59container">
          <div className="title10">
            <b className="deals2">Deals</b>
            <img className="arrowright-icon" alt="" src="/arrowright.svg" />
          </div>
        </div>
        <div className="frame-62container">
          <div className="banners1">
            <img className="sauces-icon" alt="" src="/sauces@2x.png" />
            <img className="pizza-icon" alt="" src="/pizza@2x.png" />
            <img className="pizza-hut-icon" alt="" src="/pizzahut.svg" />
            <div className="content15">
              <div className="text5">
                <div className="pizza-party">Pizza Party</div>
                <div className="enjoy-pizza-from">
                  Enjoy pizza from Johnny and get upto 30% off
                </div>
              </div>
              <div className="text6">
                <div className="starting-from">Starting from</div>
                <b className="b8">$10</b>
              </div>
            </div>
          </div>
        </div>
        <div className="frame-60container">
          <div className="explore-more">
            <b className="popperoni-pizza">Explore More</b>
            <div className="frame-1">
              <div className="cards-food2">
                <div className="img1">
                  <img className="image-icon2" alt="" src="/image4@2x.png" />
                  <div className="tag">
                    <b className="min2">40 min</b>
                  </div>
                  <img className="button-icon" alt="" src="/buttonicon.svg" />
                </div>
                <div className="content14">
                  <div className="text3">
                    <b className="popperoni-pizza">Jean’s Cakes</b>
                    <div className="daily-deli-1">Johar Town</div>
                  </div>
                  <div className="ratings1">
                    <img className="star-icon1" alt="" src="/star1.svg" />
                    <b className="b6">4.8</b>
                  </div>
                </div>
              </div>
              <div className="cards-food2">
                <div className="img1">
                  <img className="image-icon2" alt="" src="/image5@2x.png" />
                  <div className="tag">
                    <b className="min2">20 min</b>
                  </div>
                  <img className="button-icon" alt="" src="/buttonicon.svg" />
                </div>
                <div className="content14">
                  <div className="text3">
                    <b className="popperoni-pizza">Thicc Shakes</b>
                    <div className="daily-deli-1">Wapda Town</div>
                  </div>
                  <div className="ratings1">
                    <img className="star-icon1" alt="" src="/star1.svg" />
                    <b className="b6">4.5</b>
                  </div>
                </div>
              </div>
              <div className="cards-food2">
                <div className="img1">
                  <img className="image-icon2" alt="" src="/image6@2x.png" />
                  <div className="tag">
                    <b className="min2">30 min</b>
                  </div>
                  <img className="button-icon" alt="" src="/buttonicon.svg" />
                </div>
                <div className="content14">
                  <div className="text3">
                    <b className="popperoni-pizza">Daily Deli</b>
                    <div className="daily-deli-1">Garden Town</div>
                  </div>
                  <div className="ratings1">
                    <img className="star-icon1" alt="" src="/star1.svg" />
                    <b className="b6">4.8</b>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <footer className="footer2">
        <button className="home-button2">
          <img className="vector-home-icon2" alt="" src="/vectorhome2.svg" />
          <div className="home2">Home</div>
        </button>
        <button className="search-button2" onClick={onSearchButtonClick}>
          <div className="frame-822">
            <img
              className="searchvector-icon2"
              alt=""
              src="/searchvector.svg"
            />
            <div className="explore2">Explore</div>
          </div>
        </button>
        <div className="orders-button2">
          <img className="vector-clock-icon2" alt="" src="/vectorclock.svg" />
          <div className="orders3">Orders</div>
        </div>
        <button className="account-button2" onClick={onAccountButtonClick}>
          <img className="vector-user-icon2" alt="" src="/vectoruser2.svg" />
          <div className="account2">Account</div>
        </button>
      </footer>
      <header className="home-barcontainertop-barhid">
        <img className="pattern-icon" alt="" src="/pattern@2x.png" />
        <div className="text-field3">
          <img className="arrowright-icon" alt="" src="/magnifyingglass.svg" />
          <div
            className="write-text-herecomponenti"
            onClick={onWriteTextHerecomponentiClick}
          >
            Search...
          </div>
        </div>
        <div className="location2">
          <img className="arrowright-icon" alt="" src="/mappin1.svg" />
          <div className="block-b-phase1">
            Block B Phase 2 Johar Town, Lahore
          </div>
        </div>
      </header>
      <div className="cart-button-layer">
        <img className="button-icon5" alt="" src="/buttonicon1.svg" />
        <div className="badge4">
          <div className="div16">4</div>
        </div>
      </div>
    </div>
  );
};

export default CustomerHome;
