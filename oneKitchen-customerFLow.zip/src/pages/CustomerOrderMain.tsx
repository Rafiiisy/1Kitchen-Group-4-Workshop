import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./CustomerOrderMain.css";

const CustomerOrderMain: FunctionComponent = () => {
  const navigate = useNavigate();

  const onArrowleftClick = useCallback(() => {
    navigate("/home-customer");
  }, [navigate]);

  const onContainerClick = useCallback(() => {
    navigate("/customerorder-1");
  }, [navigate]);

  return (
    <div className="customer-order-main">
      <div className="app-bar1">
        <div className="bg2" />
        <b className="headline2">Daily Deli</b>
        <img className="arrowleft-icon2" alt="" src="/arrowleft1.svg" />
        <div className="text-or-buttons2">
          <div className="skip2">Skip</div>
          <div className="buttons3">
            <img className="heart-icon2" alt="" src="/heart2.svg" />
            <img className="heart-icon2" alt="" src="/sharenetwork2.svg" />
            <img className="heart-icon2" alt="" src="/dotsthreevertical1.svg" />
          </div>
        </div>
      </div>
      <div className="frame-67">
        <img className="image-icon1" alt="" src="/image1@2x.png" />
        <div className="johar-town">Johar Town</div>
        <b className="daily-deli">Daily Deli</b>
        <div className="tabs">
          <div className="tabs1">
            <div className="content1">
              <b className="tab-title">Popular</b>
            </div>
            <div className="indicator" />
          </div>
          <div className="tabs2">
            <div className="content1">
              <b className="tab-title">Deals</b>
            </div>
            <div className="spacer10" />
          </div>
          <div className="tabs2">
            <div className="content1">
              <b className="tab-title">Wraps</b>
            </div>
            <div className="spacer10" />
          </div>
          <div className="tabs2">
            <div className="content1">
              <b className="tab-title">Beverages</b>
            </div>
            <div className="spacer10" />
          </div>
          <div className="tabs2">
            <div className="content1">
              <b className="tab-title">Sandwiches</b>
            </div>
            <div className="spacer10" />
          </div>
        </div>
        <div className="row">
          <div className="ratings">
            <img className="star-icon" alt="" src="/star.svg" />
            <div className="min">4.8</div>
          </div>
          <div className="ratings">
            <img className="star-icon" alt="" src="/clock.svg" />
            <div className="min">40min</div>
          </div>
          <div className="ratings">
            <img className="star-icon" alt="" src="/mappin.svg" />
            <div className="min">1.4km</div>
          </div>
        </div>
        <button className="arrowleft1" onClick={onArrowleftClick}>
          <img className="arrowleft-icon3" alt="" src="/arrowleft1.svg" />
        </button>
      </div>
      <div className="frame-68container">
        <div className="content6">
          <div className="popular">
            <div className="title5">
              <b className="popular1">Popular</b>
            </div>
            <div className="list2">
              <div className="list-food">
                <button className="container5" onClick={onContainerClick}>
                  <div className="image">
                    <img className="img-icon" alt="" src="/img@2x.png" />
                  </div>
                  <div className="content7">
                    <div className="title-descp">
                      <div className="chicken-fajita-pizza1">
                        Chicken Fajita Pizza
                      </div>
                      <div className="pizza-with-regular">
                        8” pizza with regular soft drink
                      </div>
                    </div>
                    <b className="b1">$10</b>
                  </div>
                </button>
                <img className="divider-icon5" alt="" src="/divider.svg" />
              </div>
              <div className="list-food1">
                <div className="container6">
                  <div className="image">
                    <img className="img-icon" alt="" src="/img1@2x.png" />
                    <div className="badge">
                      <div className="div12">1</div>
                    </div>
                  </div>
                  <div className="content8">
                    <div className="title-descp">
                      <div className="chicken-fajita-pizza2">
                        Chicken Fajita Pizza
                      </div>
                      <div className="pizza-with-regular1">
                        8” pizza with regular soft drink
                      </div>
                    </div>
                    <b className="b2">$10</b>
                  </div>
                  <img className="xcircle-icon" alt="" src="/xcircle.svg" />
                </div>
                <img className="divider-icon6" alt="" src="/divider.svg" />
              </div>
            </div>
          </div>
          <div className="spacer14">
            <div className="spacer15" />
          </div>
          <div className="popular">
            <div className="title5">
              <b className="popular1">Deals</b>
            </div>
            <div className="list2">
              <div className="list-food1">
                <div className="container6">
                  <div className="image">
                    <img className="img-icon" alt="" src="/img2@2x.png" />
                    <div className="badge">
                      <div className="div12">1</div>
                    </div>
                  </div>
                  <div className="content8">
                    <div className="title-descp">
                      <div className="chicken-fajita-pizza2">Deal 1</div>
                      <div className="pizza-with-regular1">
                        1 regular burger with croquette and hot cocoa
                      </div>
                    </div>
                    <b className="b2">$12</b>
                  </div>
                  <img className="heart-icon2" alt="" src="/xcircle1.svg" />
                </div>
                <img className="divider-icon6" alt="" src="/divider.svg" />
              </div>
              <div className="list-food1">
                <div className="container6">
                  <div className="image">
                    <img className="img-icon" alt="" src="/img3@2x.png" />
                    <div className="badge">
                      <div className="div12">1</div>
                    </div>
                  </div>
                  <div className="content8">
                    <div className="title-descp">
                      <div className="chicken-fajita-pizza2">Deal 2</div>
                      <div className="pizza-with-regular1">
                        1 regular burger with small fries
                      </div>
                    </div>
                    <b className="b2">$6</b>
                  </div>
                  <img className="heart-icon2" alt="" src="/xcircle1.svg" />
                </div>
                <img className="divider-icon6" alt="" src="/divider.svg" />
              </div>
              <div className="list-food1">
                <div className="container6">
                  <div className="image">
                    <img className="img-icon" alt="" src="/img4@2x.png" />
                    <div className="badge">
                      <div className="div12">1</div>
                    </div>
                  </div>
                  <div className="content8">
                    <div className="title-descp">
                      <div className="chicken-fajita-pizza2">Deal 3</div>
                      <div className="pizza-with-regular1">
                        2 pieces of beef stew with homemade sauce
                      </div>
                    </div>
                    <b className="b2">$23</b>
                  </div>
                  <img className="heart-icon2" alt="" src="/xcircle1.svg" />
                </div>
                <img className="divider-icon9" alt="" src="/divider.svg" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="home-indicator2">
        <div className="home-indicator3" />
      </div>
    </div>
  );
};

export default CustomerOrderMain;
