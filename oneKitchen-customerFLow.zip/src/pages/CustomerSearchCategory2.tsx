import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./CustomerSearchCategory2.css";

const CustomerSearchCategory2: FunctionComponent = () => {
  const navigate = useNavigate();

  const onArrowDownSignToNavigate5Click = useCallback(() => {
    navigate("/customersearch");
  }, [navigate]);

  const onSearchButtonClick = useCallback(() => {
    // Please sync "search1" to the project
  }, []);

  const onAccountButtonClick = useCallback(() => {
    navigate("/customerprofile");
  }, [navigate]);

  return (
    <div className="customer-search-category-2">
      <div className="top">
        <div className="rectangle-4428" />
        <div className="pizza">Pizza</div>
        <button
          className="arrow-down-sign-to-navigate-5"
          onClick={onArrowDownSignToNavigate5Click}
        />
      </div>
      <div className="didnt-find-what">
        Didn’t find what you’re looking for?
      </div>
      <div className="options">
        <div className="group-37427">
          <div className="rectangle-4429" />
          <img
            className="mcdonalds-logo-1-icon"
            alt=""
            src="/mcdonaldslogo1@2x.png"
          />
          <div className="pizza-hut">Pizza Hut</div>
          <div className="international-fast">International | Fast Food</div>
          <div className="div">$ - $$</div>
        </div>
        <div className="group-37426">
          <div className="rectangle-4429" />
          <div className="pizza-hut">Domino’s</div>
          <div className="international-fast">International | Fast Food</div>
          <div className="div">$$ - $$$</div>
          <img
            className="burgerking-1-icon"
            alt=""
            src="/310burgerking1@2x.png"
          />
        </div>
        <div className="group-37425">
          <div className="rectangle-4429" />
          <div className="pizza-hut">Little Caesars</div>
          <div className="international-fast">Burgers | Fast Food</div>
          <div className="div">{`$ `}</div>
          <img
            className="burger-bangor-logo-min-1-icon"
            alt=""
            src="/burgerbangorlogomin1@2x.png"
          />
        </div>
        <div className="group-37424">
          <div className="rectangle-4429" />
          <div className="pizza-hut">Papa Murphy’s</div>
          <div className="international-fast">Burgers | Fast Food</div>
          <div className="div">$ - $$</div>
          <img
            className="bjzosq7a-400x400-1-icon"
            alt=""
            src="/bjzosq7a400x4001@2x.png"
          />
        </div>
        <div className="group-37423">
          <div className="rectangle-4429" />
          <div className="pizza-hut">Papa Johns</div>
          <div className="international-fast">International | Fast Food</div>
          <div className="div">$$ - $$$</div>
          <img
            className="wendys-logo-1-icon"
            alt=""
            src="/wendyslogo1@2x.png"
          />
        </div>
      </div>
      <footer className="frame-85">
        <footer className="footer">
          <button className="home-button">
            <img className="vector-home-icon" alt="" src="/vectorhome.svg" />
            <div className="home">Home</div>
          </button>
          <button className="search-button" onClick={onSearchButtonClick}>
            <div className="frame-82">
              <img
                className="searchvector-icon"
                alt=""
                src="/searchvector.svg"
              />
              <div className="explore">Explore</div>
            </div>
          </button>
          <div className="orders-button">
            <img className="vector-clock-icon" alt="" src="/vectorclock.svg" />
            <div className="orders1">Orders</div>
          </div>
          <button className="account-button" onClick={onAccountButtonClick}>
            <img className="vector-user-icon" alt="" src="/vectoruser.svg" />
            <div className="account">Account</div>
          </button>
        </footer>
      </footer>
    </div>
  );
};

export default CustomerSearchCategory2;
