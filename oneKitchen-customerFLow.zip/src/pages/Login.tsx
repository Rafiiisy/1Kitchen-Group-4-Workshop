import { FunctionComponent, useCallback } from "react";
import { Input } from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";
import "./Login.css";

const Login: FunctionComponent = () => {
  const navigate = useNavigate();

  const onSignUpClick = useCallback(() => {
    navigate("/sign-up");
  }, [navigate]);

  const onFrame37454Click = useCallback(() => {
    navigate("/success-log-in");
  }, [navigate]);

  return (
    <div className="login">
      <header className="frame-37450">
        <img className="k-colour-1-icon" alt="" src="/1kcolour1@2x.png" />
        <b className="welcome-back">Welcome Back!</b>
        <b className="log-in-to">Log in to your account</b>
      </header>
      <div className="frame-37453-parent">
        <Input
          className="frame-37453"
          variant="filled"
          width="304px"
          focusBorderColor="#226a20"
          size="md"
          type="password"
          placeholder="Enter your password"
          w="304px"
        />
        <b className="password-componentinput-pass">Password</b>
        <div className="frame-37451">
          <b className="email-or-phone">{`Email `}</b>
          <Input
            className="frame-37452"
            variant="filled"
            width="304px"
            focusBorderColor="#2a8431"
            type="email"
            placeholder="Enter your Email address"
            w="304px"
          />
        </div>
        <button className="frame-37455">
          <div className="rectangle-44001" />
          <b className="log-in-with">Log in with your Google Account</b>
          <img className="image-1-icon" alt="" src="/image11@2x.png" />
        </button>
        <b className="or">OR</b>
        <b className="dont-have-an">{`Don’t have an account? `}</b>
        <button className="sign-up" onClick={onSignUpClick}>
          Sign up
        </button>
        <button className="frame-37454" onClick={onFrame37454Click}>
          <div className="rectangle-44002" />
          <b className="log-in1">Log In</b>
        </button>
      </div>
    </div>
  );
};

export default Login;
