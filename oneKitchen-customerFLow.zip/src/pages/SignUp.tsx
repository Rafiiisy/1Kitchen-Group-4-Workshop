import { FunctionComponent, useCallback } from "react";
import { Input, Stack, Select } from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";
import "./SignUp.css";

const SignUp: FunctionComponent = () => {
  const navigate = useNavigate();

  const onEMailComponentinputEmailText1Click = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='rectangle4400']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onFrame37461Click = useCallback(() => {
    navigate("/sign-up-2");
  }, [navigate]);

  return (
    <div className="sign-up1">
      <div className="frame-23-container-top-bar">
        <b className="welcome">Welcome!</b>
        <div className="we-want-to">We want to know about you</div>
      </div>
      <div className="name-componentinput-name-parent">
        <b className="name-componentinput-name">Name</b>
        <Input
          className="frame-37456"
          variant="flushed"
          width="304px"
          focusBorderColor="#2c7e35"
          placeholder="Enter your Full Name"
          w="304px"
        />
        <b className="e-mail-componentinput-email">E-mail</b>
        <Input
          className="frame-37457"
          variant="flushed"
          width="304px"
          focusBorderColor="#2c7e35"
          type="email"
          placeholder="Enter your Email address"
          w="304px"
        />
        <b
          className="e-mail-componentinput-email1"
          onClick={onEMailComponentinputEmailText1Click}
        >
          Roles
        </b>
        <Stack className="frame-37458" w="304px">
          <Select
            variant="flushed"
            placeholder="Select  your roles"
            textColor="#868986"
            focusBorderColor="#2c7e35"
          >
            <option value="Customer">Customer</option>
            <option value="Merchant">Merchant</option>
            <option value="Driver">Driver</option>
          </Select>
        </Stack>
        <b className="e-mail-componentinput-email2">Password</b>
        <Input
          className="frame-37459"
          variant="flushed"
          width="304px"
          focusBorderColor="#2c7e35"
          type="password"
          placeholder="Enter your Password"
          w="304px"
        />
        <b className="e-mail-componentinput-email3">Password Confirmation</b>
        <Input
          className="frame-37460"
          variant="flushed"
          width="304px"
          focusBorderColor="#2c7e35"
          type="password"
          placeholder="Enter your Password"
          w="304px"
        />
        <button className="frame-37461" onClick={onFrame37461Click}>
          <div className="rectangle-44003" />
          <b className="next">Next</b>
        </button>
      </div>
    </div>
  );
};

export default SignUp;
