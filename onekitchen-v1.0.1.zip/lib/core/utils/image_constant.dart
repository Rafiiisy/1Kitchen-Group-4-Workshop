class ImageConstant {
  static String img2631421 = 'assets/images/img_2631421.png';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgPexelsphoto2871757 =
      'assets/images/img_pexelsphoto2871757.png';

  static String imgClose = 'assets/images/img_close.svg';

  static String imgCheckmarkIndigo700 =
      'assets/images/img_checkmark_indigo_700.svg';

  static String imgShare = 'assets/images/img_share.svg';

  static String imgPexelsphoto10360196 =
      'assets/images/img_pexelsphoto10360196.png';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgIconedit = 'assets/images/img_iconedit.svg';

  static String imgFavoriteRed600 = 'assets/images/img_favorite_red_600.svg';

  static String imgCheckmarkTeal700 =
      'assets/images/img_checkmark_teal_700.svg';

  static String imgPexelsphoto357756 =
      'assets/images/img_pexelsphoto357756.png';

  static String imgLightbulb = 'assets/images/img_lightbulb.svg';

  static String imgPexelsphotoby = 'assets/images/img_pexelsphotoby.png';

  static String imgLifesaversavatar = 'assets/images/img_lifesaversavatar.png';

  static String imgPexelsphoto7248797 =
      'assets/images/img_pexelsphoto7248797.png';

  static String imgLogowithoutbackground615x321 =
      'assets/images/img_logowithoutbackground_615x321.png';

  static String imgImage1 = 'assets/images/img_image1.png';

  static String img611221 = 'assets/images/img_611221.png';

  static String imgAvd437689ef3a02914ac1 =
      'assets/images/img_avd437689ef3a02914ac1.png';

  static String imgEdit = 'assets/images/img_edit.svg';

  static String img45672181 = 'assets/images/img_45672181.png';

  static String imgLocation = 'assets/images/img_location.svg';

  static String imgFavorite = 'assets/images/img_favorite.svg';

  static String imgStar = 'assets/images/img_star.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgLogowithoutbackground =
      'assets/images/img_logowithoutbackground.png';

  static String imgLightbulbWhiteA700 =
      'assets/images/img_lightbulb_white_a700.svg';

  static String imgEb10a983262c4 = 'assets/images/img_eb10a983262c4.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
