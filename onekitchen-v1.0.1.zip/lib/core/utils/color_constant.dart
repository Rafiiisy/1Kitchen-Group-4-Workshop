import 'dart:ui';
import 'package:flutter/material.dart';

class ColorConstant {
  static Color green300 = fromHex('#76b886');

  static Color blueGray90019 = fromHex('#192b2b2b');

  static Color lightGreen5001 = fromHex('#eeffeb');

  static Color blueGray900A2 = fromHex('#a22b2b2b');

  static Color green900 = fromHex('#1a6733');

  static Color green700 = fromHex('#2d8e48');

  static Color black9003f = fromHex('#3f000000');

  static Color green500 = fromHex('#45c269');

  static Color gray90019 = fromHex('#19161616');

  static Color gray50 = fromHex('#fcfcfc');

  static Color green400 = fromHex('#46c669');

  static Color black900 = fromHex('#000000');

  static Color teal700 = fromHex('#109952');

  static Color green70000 = fromHex('#002d8e48');

  static Color gray900A2 = fromHex('#a2161616');

  static Color blueGray90001 = fromHex('#363535');

  static Color blueGray900 = fromHex('#2b2b2b');

  static Color gray600 = fromHex('#6b6b6b');

  static Color gray700 = fromHex('#676767');

  static Color whiteA700A2 = fromHex('#a2ffffff');

  static Color gray800 = fromHex('#424242');

  static Color gray900 = fromHex('#202823');

  static Color bluegray400 = fromHex('#888888');

  static Color lightGreen50 = fromHex('#efffec');

  static Color green90001 = fromHex('#1b4930');

  static Color whiteA700 = fromHex('#ffffff');

  static Color fromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}
