import 'package:rifki_s_application3/core/app_export.dart';

class ApiClient extends GetConnect {}
