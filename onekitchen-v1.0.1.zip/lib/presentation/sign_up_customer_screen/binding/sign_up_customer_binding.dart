import '../controller/sign_up_customer_controller.dart';
import 'package:get/get.dart';

class SignUpCustomerBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => SignUpCustomerController());
  }
}
