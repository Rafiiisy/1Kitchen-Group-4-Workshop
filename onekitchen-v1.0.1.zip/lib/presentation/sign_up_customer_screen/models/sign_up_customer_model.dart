class SignUpCustomerModel {}
