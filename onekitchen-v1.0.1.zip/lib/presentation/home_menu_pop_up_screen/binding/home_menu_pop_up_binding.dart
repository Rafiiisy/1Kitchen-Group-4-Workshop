import '../controller/home_menu_pop_up_controller.dart';
import 'package:get/get.dart';

class HomeMenuPopUpBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => HomeMenuPopUpController());
  }
}
