import 'controller/home_menu_pop_up_controller.dart';
import 'package:flutter/material.dart';
import 'package:rifki_s_application3/core/app_export.dart';

class HomeMenuPopUpScreen extends GetWidget<HomeMenuPopUpController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.lightGreen50,
            body: Container(
                width: double.maxFinite,
                padding: getPadding(left: 38, top: 54, right: 38, bottom: 54),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomImageView(
                          svgPath: ImageConstant.imgArrowleft,
                          height: getVerticalSize(19),
                          width: getHorizontalSize(12),
                          alignment: Alignment.centerLeft,
                          onTap: () {
                            onTapImgArrowleft();
                          }),
                      GestureDetector(
                          onTap: () {
                            onTapTxtAccount();
                          },
                          child: Padding(
                              padding: getPadding(top: 48),
                              child: Text("lbl_account".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular32))),
                      GestureDetector(
                          onTap: () {
                            onTapTxtOrders();
                          },
                          child: Padding(
                              padding: getPadding(top: 132),
                              child: Text("lbl_orders".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular32))),
                      Spacer(),
                      GestureDetector(
                          onTap: () {
                            onTapTxtSettings();
                          },
                          child: Text("lbl_settings".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterRegular32)),
                      GestureDetector(
                          onTap: () {
                            onTapTxtFeedback();
                          },
                          child: Padding(
                              padding: getPadding(top: 131, bottom: 68),
                              child: Text("lbl_feedback".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular32)))
                    ]))));
  }

  onTapImgArrowleft() {
    Get.back();
  }

  onTapTxtAccount() {
    Get.toNamed(AppRoutes.accountPageOneScreen);
  }

  onTapTxtOrders() {
    Get.toNamed(AppRoutes.ordersPageScreen);
  }

  onTapTxtSettings() {
    Get.toNamed(AppRoutes.settingsPageScreen);
  }

  onTapTxtFeedback() {
    Get.toNamed(AppRoutes.feedbackScreen);
  }
}
