import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/presentation/home_menu_pop_up_screen/models/home_menu_pop_up_model.dart';

class HomeMenuPopUpController extends GetxController {
  Rx<HomeMenuPopUpModel> homeMenuPopUpModelObj = HomeMenuPopUpModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
