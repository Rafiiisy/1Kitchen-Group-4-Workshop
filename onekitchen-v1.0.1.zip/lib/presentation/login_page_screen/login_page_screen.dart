import 'controller/login_page_controller.dart';
import 'package:flutter/material.dart';
import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/core/utils/validation_functions.dart';
import 'package:rifki_s_application3/widgets/custom_button.dart';
import 'package:rifki_s_application3/widgets/custom_checkbox.dart';
import 'package:rifki_s_application3/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class LoginPageScreen extends GetWidget<LoginPageController> {
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            backgroundColor: ColorConstant.lightGreen5001,
            body: Form(
                key: _formKey,
                child: Container(
                    width: double.maxFinite,
                    padding: getPadding(left: 33, top: 94, right: 33),
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text("lbl_welcome_back".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterRegular24),
                          Padding(
                              padding: getPadding(top: 40),
                              child: Text("msg_log_in_to_your_account".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular18)),
                          Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                  padding: getPadding(left: 7, top: 20),
                                  child: Text("lbl_username".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterBold12))),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: controller.rectangleOneController,
                              hintText: "msg_enter_your_username".tr,
                              margin: getMargin(left: 9, top: 1, right: 3),
                              textInputType: TextInputType.phone,
                              validator: (value) {
                                if (!isValidPhone(value)) {
                                  return "Please enter valid phone number";
                                }
                                return null;
                              }),
                          Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                  padding: getPadding(left: 9, top: 21),
                                  child: Text("lbl_password".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterBold12))),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: controller.rectangleTwoController,
                              hintText: "msg_enter_your_password".tr,
                              margin: getMargin(left: 9, top: 1, right: 3),
                              textInputAction: TextInputAction.done,
                              textInputType: TextInputType.visiblePassword,
                              validator: (value) {
                                if (value == null ||
                                    (!isValidPassword(value,
                                        isRequired: true))) {
                                  return "Please enter valid password";
                                }
                                return null;
                              },
                              isObscureText: true),
                          Padding(
                              padding: getPadding(left: 10, top: 20, right: 2),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Obx(() => CustomCheckbox(
                                        text: "lbl_remember_me".tr,
                                        iconSize: getHorizontalSize(11),
                                        value: controller.checkbox.value,
                                        fontStyle:
                                            CheckboxFontStyle.InterRegular10,
                                        onChange: (value) {
                                          controller.checkbox.value = value;
                                        })),
                                    Text("msg_forgot_your_password".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular10)
                                  ])),
                          CustomImageView(
                              svgPath: ImageConstant.imgCheckmark,
                              height: getVerticalSize(15),
                              width: getHorizontalSize(17),
                              alignment: Alignment.centerLeft),
                          CustomButton(
                              height: getVerticalSize(45),
                              width: getHorizontalSize(161),
                              text: "lbl_log_in".tr,
                              margin: getMargin(top: 29),
                              variant: ButtonVariant.FillTeal700,
                              shape: ButtonShape.RoundedBorder10,
                              padding: ButtonPadding.PaddingAll7,
                              fontStyle: ButtonFontStyle.InterSemiBold20,
                              onTap: onTapLogin),
                          Padding(
                              padding: getPadding(top: 29),
                              child: Text("lbl_or".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular14)),
                          Container(
                              margin: getMargin(left: 9, top: 25, right: 3),
                              padding: getPadding(top: 10, bottom: 10),
                              decoration: AppDecoration.fillWhiteA700.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder5),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    CustomImageView(
                                        imagePath: ImageConstant.imgImage1,
                                        height: getVerticalSize(21),
                                        width: getHorizontalSize(24),
                                        margin: getMargin(bottom: 2)),
                                    Padding(
                                        padding: getPadding(top: 4, bottom: 1),
                                        child: Text("msg_log_in_with_your".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtInterRegular14Black900))
                                  ])),
                          Align(
                              alignment: Alignment.centerRight,
                              child: GestureDetector(
                                  onTap: () {
                                    onTapTxtDontthaveanaccount();
                                  },
                                  child: Container(
                                      width: getHorizontalSize(227),
                                      margin: getMargin(
                                          left: 51,
                                          top: 16,
                                          right: 12,
                                          bottom: 5),
                                      child: RichText(
                                          text: TextSpan(children: [
                                            TextSpan(
                                                text:
                                                    "msg_dont_t_have_an_account2"
                                                        .tr,
                                                style: TextStyle(
                                                    color: ColorConstant
                                                        .blueGray90001,
                                                    fontSize: getFontSize(13),
                                                    fontFamily: 'Inter',
                                                    fontWeight:
                                                        FontWeight.w400)),
                                            TextSpan(
                                                text: "lbl_sign_up".tr,
                                                style: TextStyle(
                                                    color: ColorConstant
                                                        .blueGray90001,
                                                    fontSize: getFontSize(13),
                                                    fontFamily: 'Inter',
                                                    fontWeight:
                                                        FontWeight.w400)),
                                            TextSpan(
                                                text: "lbl_sign".tr,
                                                style: TextStyle(
                                                    color: ColorConstant
                                                        .lightGreen5001,
                                                    fontSize: getFontSize(13),
                                                    fontFamily: 'Inter',
                                                    fontWeight:
                                                        FontWeight.w600)),
                                            TextSpan(
                                                text: " ",
                                                style: TextStyle(
                                                    color: ColorConstant
                                                        .blueGray90001,
                                                    fontSize: getFontSize(13),
                                                    fontFamily: 'Inter',
                                                    fontWeight:
                                                        FontWeight.w600)),
                                            TextSpan(
                                                text: "lbl_up".tr,
                                                style: TextStyle(
                                                    color: ColorConstant
                                                        .lightGreen5001,
                                                    fontSize: getFontSize(13),
                                                    fontFamily: 'Inter',
                                                    fontWeight:
                                                        FontWeight.w600))
                                          ]),
                                          textAlign: TextAlign.center))))
                        ])))));
  }

  onTapLogin() {
    Get.toNamed(AppRoutes.loginSuccessfulScreen);
  }

  onTapTxtDontthaveanaccount() {
    Get.toNamed(AppRoutes.signUpPageScreen);
  }
}
