import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/presentation/login_page_screen/models/login_page_model.dart';
import 'package:flutter/material.dart';

class LoginPageController extends GetxController {
  TextEditingController rectangleOneController = TextEditingController();

  TextEditingController rectangleTwoController = TextEditingController();

  Rx<LoginPageModel> loginPageModelObj = LoginPageModel().obs;

  RxBool checkbox = false.obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
    rectangleOneController.dispose();
    rectangleTwoController.dispose();
  }
}
