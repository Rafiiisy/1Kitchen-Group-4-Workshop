import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/presentation/signup_successful_screen/models/signup_successful_model.dart';

class SignupSuccessfulController extends GetxController {
  Rx<SignupSuccessfulModel> signupSuccessfulModelObj =
      SignupSuccessfulModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
