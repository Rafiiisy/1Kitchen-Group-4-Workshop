class SignupSuccessfulModel {}
