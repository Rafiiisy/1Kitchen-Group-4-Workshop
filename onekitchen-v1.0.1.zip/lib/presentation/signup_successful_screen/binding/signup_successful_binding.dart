import '../controller/signup_successful_controller.dart';
import 'package:get/get.dart';

class SignupSuccessfulBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => SignupSuccessfulController());
  }
}
