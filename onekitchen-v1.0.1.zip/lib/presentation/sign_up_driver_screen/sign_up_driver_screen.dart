import 'controller/sign_up_driver_controller.dart';
import 'package:flutter/material.dart';
import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/core/utils/validation_functions.dart';
import 'package:rifki_s_application3/widgets/custom_button.dart';
import 'package:rifki_s_application3/widgets/custom_checkbox.dart';
import 'package:rifki_s_application3/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class SignUpDriverScreen extends GetWidget<SignUpDriverController> {
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            backgroundColor: ColorConstant.lightGreen5001,
            body: Form(
                key: _formKey,
                child: Container(
                    width: double.maxFinite,
                    padding:
                        getPadding(left: 26, top: 18, right: 26, bottom: 18),
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text("lbl_welcome".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterRegular24),
                          Padding(
                              padding: getPadding(top: 34),
                              child: Text("msg_sign_up_for_the".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular18)),
                          Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                  padding: getPadding(left: 13, top: 30),
                                  child: Text("lbl_username".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterBold12))),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: controller.rectangleOneController,
                              hintText: "msg_enter_your_username2".tr,
                              margin: getMargin(left: 13, top: 1, right: 13),
                              validator: (value) {
                                if (!isText(value)) {
                                  return "Please enter valid text";
                                }
                                return null;
                              }),
                          Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                  padding: getPadding(left: 13, top: 23),
                                  child: Text("lbl_name".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterBold12))),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: controller.rectangleTwoController,
                              hintText: "msg_enter_your_full".tr,
                              margin: getMargin(left: 13, top: 1, right: 13),
                              validator: (value) {
                                if (!isText(value)) {
                                  return "Please enter valid text";
                                }
                                return null;
                              }),
                          Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                  padding: getPadding(left: 13, top: 22),
                                  child: Text("msg_email_or_phone_number".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterBold12))),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: controller.rectangleThreeController,
                              hintText: "msg_enter_your_email_phone".tr,
                              margin: getMargin(left: 13, top: 2, right: 13),
                              textInputType: TextInputType.emailAddress,
                              validator: (value) {
                                if (value == null ||
                                    (!isValidEmail(value, isRequired: true))) {
                                  return "Please enter valid email";
                                }
                                return null;
                              }),
                          Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                  padding: getPadding(left: 13, top: 23),
                                  child: Text("lbl_password".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterBold12))),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: controller.rectangleFourController,
                              hintText: "msg_enter_your_password".tr,
                              margin: getMargin(left: 13, top: 1, right: 13),
                              textInputType: TextInputType.visiblePassword,
                              validator: (value) {
                                if (value == null ||
                                    (!isValidPassword(value,
                                        isRequired: true))) {
                                  return "Please enter valid password";
                                }
                                return null;
                              },
                              isObscureText: true),
                          Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                  padding: getPadding(left: 13, top: 22),
                                  child: Text("msg_password_confirmation".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtInterBold12))),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: controller.rectangleFiveController,
                              hintText: "msg_confirm_password".tr,
                              margin: getMargin(left: 13, top: 3, right: 13),
                              textInputAction: TextInputAction.done,
                              textInputType: TextInputType.visiblePassword,
                              validator: (value) {
                                if (value == null ||
                                    (!isValidPassword(value,
                                        isRequired: true))) {
                                  return "Please enter valid password";
                                }
                                return null;
                              },
                              isObscureText: true),
                          Spacer(),
                          Obx(() => CustomCheckbox(
                              text: "msg_by_clicking_on_sign".tr,
                              value: controller.checkbox.value,
                              margin: getMargin(left: 13, bottom: 8),
                              fontStyle: CheckboxFontStyle.InterRegular10,
                              onChange: (value) {
                                controller.checkbox.value = value;
                              }))
                        ]))),
            bottomNavigationBar: CustomButton(
                height: getVerticalSize(55),
                width: getHorizontalSize(196),
                text: "lbl_sign_up2".tr,
                margin: getMargin(left: 82, right: 82, bottom: 45),
                variant: ButtonVariant.FillTeal700,
                shape: ButtonShape.RoundedBorder10,
                fontStyle: ButtonFontStyle.InterSemiBold20,
                onTap: onTapSignup)));
  }

  onTapSignup() {
    Get.toNamed(AppRoutes.signupSuccessfulScreen);
  }
}
