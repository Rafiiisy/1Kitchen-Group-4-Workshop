import 'controller/login_successful_controller.dart';
import 'package:flutter/material.dart';
import 'package:rifki_s_application3/core/app_export.dart';

class LoginSuccessfulScreen extends GetWidget<LoginSuccessfulController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.lightGreen5001,
            body: Container(
                width: double.maxFinite,
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomImageView(
                          svgPath: ImageConstant.imgCheckmarkTeal700,
                          height: getVerticalSize(59),
                          width: getHorizontalSize(76)),
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                              padding: getPadding(top: 61),
                              child: Text("msg_your_log_in_was".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterMedium16))),
                      GestureDetector(
                          onTap: () {
                            onTapTxtContinuetoHome();
                          },
                          child: Padding(
                              padding: getPadding(top: 65, bottom: 5),
                              child: Text("msg_continue_to_home".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterMedium20Teal700
                                      .copyWith(
                                          decoration:
                                              TextDecoration.underline))))
                    ]))));
  }

  onTapTxtContinuetoHome() {
    Get.toNamed(AppRoutes.homeMenuCustomerScreen);
  }
}
