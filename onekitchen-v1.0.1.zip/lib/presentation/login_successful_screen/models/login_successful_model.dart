class LoginSuccessfulModel {}
