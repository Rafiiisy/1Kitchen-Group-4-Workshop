import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/presentation/login_successful_screen/models/login_successful_model.dart';

class LoginSuccessfulController extends GetxController {
  Rx<LoginSuccessfulModel> loginSuccessfulModelObj = LoginSuccessfulModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
