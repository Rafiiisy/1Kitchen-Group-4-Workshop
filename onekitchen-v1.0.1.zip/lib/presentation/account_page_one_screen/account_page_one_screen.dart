import 'controller/account_page_one_controller.dart';
import 'package:flutter/material.dart';
import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/widgets/app_bar/appbar_image.dart';
import 'package:rifki_s_application3/widgets/app_bar/appbar_subtitle.dart';
import 'package:rifki_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:rifki_s_application3/widgets/custom_button.dart';

class AccountPageOneScreen extends GetWidget<AccountPageOneController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            appBar: CustomAppBar(
                height: getVerticalSize(71),
                leadingWidth: 50,
                leading: AppbarImage(
                    height: getSize(26),
                    width: getSize(26),
                    svgPath: ImageConstant.imgClose,
                    margin: getMargin(left: 24, top: 15, bottom: 14),
                    onTap: onTapClose),
                centerTitle: true,
                title: AppbarSubtitle(text: "lbl_account".tr),
                actions: [
                  AppbarImage(
                      height: getVerticalSize(27),
                      width: getHorizontalSize(24),
                      svgPath: ImageConstant.imgShare,
                      margin:
                          getMargin(left: 32, top: 16, right: 32, bottom: 12))
                ]),
            body: Container(
                width: size.width,
                height: size.height,
                padding: getPadding(top: 56),
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment(0.5, 0),
                        end: Alignment(0.5, 1),
                        colors: [
                      ColorConstant.green500,
                      ColorConstant.green90001
                    ])),
                child: Container(
                    width: double.maxFinite,
                    padding: getPadding(left: 42, right: 42),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                              padding: getPadding(left: 8, top: 9),
                              child: Text("lbl_your_profile".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterRegular26)),
                          Container(
                              margin: getMargin(left: 8, top: 14),
                              padding: getPadding(top: 21, bottom: 21),
                              decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    CustomImageView(
                                        imagePath:
                                            ImageConstant.imgLifesaversavatar,
                                        height: getVerticalSize(81),
                                        width: getHorizontalSize(70),
                                        margin: getMargin(bottom: 8)),
                                    Padding(
                                        padding: getPadding(bottom: 3),
                                        child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text("lbl_rm_makmur".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtInterSemiBold18),
                                              Container(
                                                  width: getHorizontalSize(163),
                                                  margin: getMargin(
                                                      left: 1, top: 6),
                                                  child: RichText(
                                                      text: TextSpan(children: [
                                                        TextSpan(
                                                            text: "msg_jl_hahahaha_no_02"
                                                                .tr,
                                                            style: TextStyle(
                                                                color:
                                                                    ColorConstant
                                                                        .gray800,
                                                                fontSize:
                                                                    getFontSize(
                                                                        16),
                                                                fontFamily:
                                                                    'Inter',
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w300)),
                                                        TextSpan(
                                                            text: " ".tr,
                                                            style: TextStyle(
                                                                color:
                                                                    ColorConstant
                                                                        .black900,
                                                                fontSize:
                                                                    getFontSize(
                                                                        16),
                                                                fontFamily:
                                                                    'Inter',
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w300)),
                                                        TextSpan(
                                                            text: "msg_bobiscool_gmail_com"
                                                                .tr,
                                                            style: TextStyle(
                                                                color:
                                                                    ColorConstant
                                                                        .gray800,
                                                                fontSize:
                                                                    getFontSize(
                                                                        16),
                                                                fontFamily:
                                                                    'Inter',
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w300)),
                                                        TextSpan(
                                                            text: " ".tr,
                                                            style: TextStyle(
                                                                color:
                                                                    ColorConstant
                                                                        .black900,
                                                                fontSize:
                                                                    getFontSize(
                                                                        16),
                                                                fontFamily:
                                                                    'Inter',
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w300)),
                                                        TextSpan(
                                                            text: "lbl_23_645_9870"
                                                                .tr,
                                                            style: TextStyle(
                                                                color:
                                                                    ColorConstant
                                                                        .gray800,
                                                                fontSize:
                                                                    getFontSize(
                                                                        16),
                                                                fontFamily:
                                                                    'Inter',
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w300))
                                                      ]),
                                                      textAlign:
                                                          TextAlign.left))
                                            ]))
                                  ])),
                          Container(
                              margin: getMargin(left: 8, top: 15),
                              padding: getPadding(top: 11, bottom: 11),
                              decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: [
                                    Padding(
                                        padding: getPadding(top: 7),
                                        child: Text("lbl_payment_methods".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular20)),
                                    CustomImageView(
                                        svgPath: ImageConstant.imgArrowright,
                                        height: getVerticalSize(14),
                                        width: getHorizontalSize(6),
                                        margin: getMargin(top: 8, bottom: 9))
                                  ])),
                          Container(
                              margin: getMargin(left: 8, top: 15),
                              padding: getPadding(
                                  left: 21, top: 12, right: 21, bottom: 12),
                              decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                        padding: getPadding(left: 8, top: 7),
                                        child: Text("msg_privacy_safety".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular20)),
                                    CustomImageView(
                                        svgPath: ImageConstant.imgArrowright,
                                        height: getVerticalSize(14),
                                        width: getHorizontalSize(6),
                                        margin: getMargin(top: 8, bottom: 9))
                                  ])),
                          Container(
                              margin: getMargin(left: 8, top: 15),
                              padding: getPadding(
                                  left: 21, top: 11, right: 21, bottom: 11),
                              decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                        padding: getPadding(left: 9, top: 7),
                                        child: Text("lbl_support".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular20)),
                                    CustomImageView(
                                        svgPath: ImageConstant.imgArrowright,
                                        height: getVerticalSize(14),
                                        width: getHorizontalSize(6),
                                        margin: getMargin(top: 8, bottom: 9))
                                  ])),
                          Container(
                              margin: getMargin(left: 8, top: 15),
                              padding: getPadding(
                                  left: 21, top: 13, right: 21, bottom: 13),
                              decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                        padding: getPadding(left: 9, top: 4),
                                        child: Text("lbl_saved_address".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular20)),
                                    CustomImageView(
                                        svgPath: ImageConstant.imgArrowright,
                                        height: getVerticalSize(14),
                                        width: getHorizontalSize(6),
                                        margin: getMargin(top: 7, bottom: 8))
                                  ])),
                          CustomButton(
                              height: getVerticalSize(43),
                              text: "lbl_log_out".tr,
                              margin: getMargin(left: 42, top: 31, right: 34),
                              variant: ButtonVariant.FillGreen400,
                              shape: ButtonShape.RoundedBorder21,
                              fontStyle: ButtonFontStyle.InterRegular16,
                              onTap: onTapLogout,
                              alignment: Alignment.center)
                        ])))));
  }

  onTapLogout() {
    Get.toNamed(AppRoutes.onboardingPageScreen);
  }

  onTapClose() {
    Get.back();
  }
}
