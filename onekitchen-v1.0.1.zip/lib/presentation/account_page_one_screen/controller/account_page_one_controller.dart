import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/presentation/account_page_one_screen/models/account_page_one_model.dart';

class AccountPageOneController extends GetxController {
  Rx<AccountPageOneModel> accountPageOneModelObj = AccountPageOneModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
