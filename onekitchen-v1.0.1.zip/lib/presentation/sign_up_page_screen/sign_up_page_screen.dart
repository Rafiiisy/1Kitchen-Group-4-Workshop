import 'controller/sign_up_page_controller.dart';
import 'package:flutter/material.dart';
import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/widgets/custom_checkbox.dart';

class SignUpPageScreen extends GetWidget<SignUpPageController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.lightGreen5001,
            body: Container(
                width: double.maxFinite,
                padding: getPadding(all: 26),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text("lbl_welcome".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtInterRegular24),
                      Padding(
                          padding: getPadding(top: 26),
                          child: Text("msg_sign_up_for_the".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterRegular18)),
                      Padding(
                          padding: getPadding(top: 63),
                          child: Text("lbl_who_are_you".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterBold16Black900)),
                      CustomImageView(
                          imagePath: ImageConstant.img2631421,
                          height: getVerticalSize(53),
                          width: getHorizontalSize(54),
                          alignment: Alignment.centerLeft,
                          margin: getMargin(left: 119, top: 28),
                          onTap: () {
                            onTapImgtf();
                          }),
                      GestureDetector(
                          onTap: () {
                            onTapTxtCustomer();
                          },
                          child: Padding(
                              padding: getPadding(top: 8),
                              child: Text("lbl_customer".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterLight12))),
                      Container(
                          height: getVerticalSize(88),
                          width: getHorizontalSize(84),
                          margin: getMargin(top: 40),
                          child:
                              Stack(alignment: Alignment.topCenter, children: [
                            Align(
                                alignment: Alignment.bottomCenter,
                                child: Text("lbl_merchant".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterLight12)),
                            CustomImageView(
                                imagePath:
                                    ImageConstant.imgAvd437689ef3a02914ac1,
                                height: getVerticalSize(81),
                                width: getHorizontalSize(84),
                                alignment: Alignment.topCenter,
                                onTap: () {
                                  onTapImgAvd437689ef3a02914acOne();
                                })
                          ])),
                      CustomImageView(
                          imagePath: ImageConstant.img45672181,
                          height: getVerticalSize(56),
                          width: getHorizontalSize(55),
                          margin: getMargin(top: 65),
                          onTap: () {
                            onTapImgtf1();
                          }),
                      GestureDetector(
                          onTap: () {
                            onTapTxtDriver();
                          },
                          child: Padding(
                              padding: getPadding(top: 8),
                              child: Text("lbl_driver".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterLight12))),
                      Obx(() => CustomCheckbox(
                          text: "msg_by_clicking_on_sign".tr,
                          value: controller.checkbox.value,
                          margin: getMargin(left: 13, top: 78, bottom: 5),
                          fontStyle: CheckboxFontStyle.InterRegular10,
                          onChange: (value) {
                            controller.checkbox.value = value;
                          }))
                    ]))));
  }

  onTapImgtf() {
    Get.toNamed(AppRoutes.signUpCustomerScreen);
  }

  onTapTxtCustomer() {
    Get.toNamed(AppRoutes.signUpCustomerScreen);
  }

  onTapImgAvd437689ef3a02914acOne() {
    Get.toNamed(AppRoutes.signUpMerchantScreen);
  }

  onTapImgtf1() {
    Get.toNamed(AppRoutes.signUpDriverScreen);
  }

  onTapTxtDriver() {
    Get.toNamed(AppRoutes.signUpDriverScreen);
  }
}
