import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/presentation/sign_up_page_screen/models/sign_up_page_model.dart';

class SignUpPageController extends GetxController {
  Rx<SignUpPageModel> signUpPageModelObj = SignUpPageModel().obs;

  RxBool checkbox = false.obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
