import 'controller/onboarding_page_controller.dart';
import 'package:flutter/material.dart';
import 'package:rifki_s_application3/core/app_export.dart';

class OnboardingPageScreen extends GetWidget<OnboardingPageController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.lightGreen5001,
            body: Container(
                height: size.height,
                width: double.maxFinite,
                padding: getPadding(left: 9, top: 7, right: 9, bottom: 7),
                child: Stack(alignment: Alignment.bottomCenter, children: [
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: Padding(
                          padding: getPadding(left: 63, right: 61, bottom: 211),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                RichText(
                                    text: TextSpan(children: [
                                      TextSpan(
                                          text: "lbl_1k".tr,
                                          style: TextStyle(
                                              color: ColorConstant.green700,
                                              fontSize: getFontSize(20),
                                              fontFamily: 'Inter',
                                              fontWeight: FontWeight.w500)),
                                      TextSpan(
                                          text: "lbl_but_with".tr,
                                          style: TextStyle(
                                              color: ColorConstant.black900,
                                              fontSize: getFontSize(20),
                                              fontFamily: 'Inter',
                                              fontWeight: FontWeight.w500)),
                                      TextSpan(
                                          text: "lbl_4k".tr,
                                          style: TextStyle(
                                              color: ColorConstant.green700,
                                              fontSize: getFontSize(20),
                                              fontFamily: 'Inter',
                                              fontWeight: FontWeight.w500)),
                                      TextSpan(
                                          text: "lbl_quality".tr,
                                          style: TextStyle(
                                              color: ColorConstant.black900,
                                              fontSize: getFontSize(20),
                                              fontFamily: 'Inter',
                                              fontWeight: FontWeight.w500))
                                    ]),
                                    textAlign: TextAlign.left),
                                Card(
                                    clipBehavior: Clip.antiAlias,
                                    elevation: 0,
                                    margin: getMargin(top: 120),
                                    color: ColorConstant.teal700,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadiusStyle.roundedBorder10),
                                    child: Container(
                                        height: getVerticalSize(47),
                                        width: getHorizontalSize(217),
                                        decoration: AppDecoration.fillTeal700
                                            .copyWith(
                                                borderRadius: BorderRadiusStyle
                                                    .roundedBorder10),
                                        child: Stack(
                                            alignment: Alignment.center,
                                            children: [
                                              Align(
                                                  alignment:
                                                      Alignment.bottomLeft,
                                                  child: Padding(
                                                      padding: getPadding(
                                                          left: 70, bottom: 4),
                                                      child: Text(
                                                          "lbl_log_in".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtInterMedium24))),
                                              Align(
                                                  alignment: Alignment.center,
                                                  child: GestureDetector(
                                                      onTap: () {
                                                        onTapLoginbutton2();
                                                      },
                                                      child: Container(
                                                          padding: getPadding(
                                                              left: 70,
                                                              top: 4,
                                                              right: 70,
                                                              bottom: 4),
                                                          decoration: AppDecoration
                                                              .fillTeal700
                                                              .copyWith(
                                                                  borderRadius:
                                                                      BorderRadiusStyle
                                                                          .roundedBorder10),
                                                          child: Column(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .min,
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .end,
                                                              children: [
                                                                Padding(
                                                                    padding:
                                                                        getPadding(
                                                                            top:
                                                                                7),
                                                                    child: Text(
                                                                        "lbl_log_in"
                                                                            .tr,
                                                                        overflow:
                                                                            TextOverflow
                                                                                .ellipsis,
                                                                        textAlign:
                                                                            TextAlign
                                                                                .left,
                                                                        style: AppStyle
                                                                            .txtInterMedium24))
                                                              ]))))
                                            ])))
                              ]))),
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: Card(
                          clipBehavior: Clip.antiAlias,
                          elevation: 0,
                          margin: getMargin(bottom: 5),
                          shape: RoundedRectangleBorder(
                              side: BorderSide(
                                  color: ColorConstant.teal700,
                                  width: getHorizontalSize(2)),
                              borderRadius: BorderRadiusStyle.roundedBorder10),
                          child: Container(
                              height: getVerticalSize(47),
                              width: getHorizontalSize(217),
                              decoration: AppDecoration.outlineTeal700.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder10),
                              child: Stack(
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    Align(
                                        alignment: Alignment.center,
                                        child: GestureDetector(
                                            onTap: () {
                                              onTapRectangleEight();
                                            },
                                            child: Container(
                                                height: getVerticalSize(47),
                                                width: getHorizontalSize(217),
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            getHorizontalSize(
                                                                10)),
                                                    border: Border.all(
                                                        color: ColorConstant
                                                            .teal700,
                                                        width:
                                                            getHorizontalSize(
                                                                2)))))),
                                    Align(
                                        alignment: Alignment.bottomCenter,
                                        child: Padding(
                                            padding: getPadding(bottom: 5),
                                            child: Text("lbl_sign_up2".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style: AppStyle
                                                    .txtInterMedium24Teal700)))
                                  ])))),
                  CustomImageView(
                      imagePath: ImageConstant.imgLogowithoutbackground615x321,
                      height: getVerticalSize(615),
                      width: getHorizontalSize(321),
                      alignment: Alignment.topLeft)
                ]))));
  }

  onTapLoginbutton2() {
    Get.toNamed(AppRoutes.loginPageScreen);
  }

  onTapRectangleEight() {
    Get.toNamed(AppRoutes.signUpPageScreen);
  }
}
