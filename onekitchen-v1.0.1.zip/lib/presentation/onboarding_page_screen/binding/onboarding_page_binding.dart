import '../controller/onboarding_page_controller.dart';
import 'package:get/get.dart';

class OnboardingPageBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => OnboardingPageController());
  }
}
