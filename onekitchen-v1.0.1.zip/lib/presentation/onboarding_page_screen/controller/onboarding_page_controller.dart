import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/presentation/onboarding_page_screen/models/onboarding_page_model.dart';

class OnboardingPageController extends GetxController {
  Rx<OnboardingPageModel> onboardingPageModelObj = OnboardingPageModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
