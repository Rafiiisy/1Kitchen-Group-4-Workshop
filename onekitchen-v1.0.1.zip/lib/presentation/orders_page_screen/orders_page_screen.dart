import 'controller/orders_page_controller.dart';
import 'package:flutter/material.dart';
import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/widgets/app_bar/appbar_image.dart';
import 'package:rifki_s_application3/widgets/app_bar/appbar_subtitle.dart';
import 'package:rifki_s_application3/widgets/app_bar/custom_app_bar.dart';

class OrdersPageScreen extends GetWidget<OrdersPageController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            appBar: CustomAppBar(
                height: getVerticalSize(71),
                leadingWidth: 50,
                leading: AppbarImage(
                    height: getSize(26),
                    width: getSize(26),
                    svgPath: ImageConstant.imgClose,
                    margin: getMargin(left: 24, top: 15, bottom: 14),
                    onTap: onTapClose1),
                centerTitle: true,
                title: AppbarSubtitle(text: "lbl_orders".tr)),
            body: Container(
                width: size.width,
                height: size.height,
                padding: getPadding(top: 56),
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment(0.5, 0),
                        end: Alignment(0.5, 1),
                        colors: [
                      ColorConstant.green500,
                      ColorConstant.green90001
                    ])),
                child: Container(
                    width: double.maxFinite,
                    padding: getPadding(left: 43, top: 117, right: 43),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                              padding: getPadding(left: 10, right: 71),
                              child: Row(children: [
                                CustomImageView(
                                    imagePath: ImageConstant.img611221,
                                    height: getSize(19),
                                    width: getSize(19),
                                    margin: getMargin(top: 6, bottom: 6)),
                                Padding(
                                    padding: getPadding(left: 7),
                                    child: Text("lbl_order_history".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular26))
                              ])),
                          Container(
                              margin: getMargin(top: 7, right: 6),
                              padding: getPadding(
                                  left: 20, top: 12, right: 20, bottom: 12),
                              decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    CustomImageView(
                                        imagePath:
                                            ImageConstant.imgLifesaversavatar,
                                        height: getVerticalSize(81),
                                        width: getHorizontalSize(70),
                                        margin: getMargin(top: 9, bottom: 16)),
                                    Padding(
                                        padding: getPadding(left: 5, top: 6),
                                        child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text("lbl_rafi".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style:
                                                      AppStyle.txtInterBold18),
                                              Container(
                                                  width: getHorizontalSize(132),
                                                  margin: getMargin(
                                                      left: 2, top: 6),
                                                  child: Text(
                                                      "msg_12_french_fries".tr,
                                                      maxLines: null,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterLight16)),
                                              Padding(
                                                  padding: getPadding(left: 2),
                                                  child: Text(
                                                      "msg_03_02_2023_02_03".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterLight11))
                                            ]))
                                  ])),
                          Container(
                              margin: getMargin(top: 13, right: 6),
                              padding: getPadding(
                                  left: 21, top: 4, right: 21, bottom: 4),
                              decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Padding(
                                        padding: getPadding(left: 9),
                                        child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                  padding:
                                                      getPadding(bottom: 4),
                                                  child: Text("lbl_naufal".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterBold20Black900)),
                                              CustomImageView(
                                                  svgPath: ImageConstant
                                                      .imgArrowright,
                                                  height: getVerticalSize(14),
                                                  width: getHorizontalSize(6),
                                                  margin: getMargin(
                                                      left: 145, top: 15))
                                            ])),
                                    Container(
                                        height: getVerticalSize(14),
                                        width: getHorizontalSize(124),
                                        margin: getMargin(left: 9, bottom: 2),
                                        child: Stack(
                                            alignment: Alignment.center,
                                            children: [
                                              Align(
                                                  alignment: Alignment.center,
                                                  child: Text(
                                                      "msg_03_02_2023_02_03".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterLight11)),
                                              Align(
                                                  alignment: Alignment.center,
                                                  child: Text(
                                                      "msg_03_02_2023_02_03".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterLight11))
                                            ]))
                                  ])),
                          Container(
                              margin: getMargin(top: 15, right: 6),
                              padding: getPadding(
                                  left: 21, top: 6, right: 21, bottom: 6),
                              decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Padding(
                                        padding: getPadding(left: 9),
                                        child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                  padding:
                                                      getPadding(bottom: 2),
                                                  child: Text("lbl_rifki".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterBold20Black900)),
                                              CustomImageView(
                                                  svgPath: ImageConstant
                                                      .imgArrowright,
                                                  height: getVerticalSize(14),
                                                  width: getHorizontalSize(6),
                                                  margin: getMargin(
                                                      left: 165, top: 13))
                                            ])),
                                    Padding(
                                        padding: getPadding(left: 9),
                                        child: Text("msg_13_01_2023_02_02".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterLight11))
                                  ])),
                          Container(
                              margin: getMargin(top: 15, right: 6, bottom: 5),
                              padding: getPadding(
                                  left: 21, top: 5, right: 21, bottom: 5),
                              decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Padding(
                                        padding: getPadding(left: 9),
                                        child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                  padding:
                                                      getPadding(bottom: 4),
                                                  child: Text("lbl_nash".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtInterBold20Black900)),
                                              CustomImageView(
                                                  svgPath: ImageConstant
                                                      .imgArrowright,
                                                  height: getVerticalSize(14),
                                                  width: getHorizontalSize(6),
                                                  margin: getMargin(
                                                      left: 159, top: 15))
                                            ])),
                                    Padding(
                                        padding: getPadding(left: 9, bottom: 2),
                                        child: Text("msg_03_01_2023_02_01".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterLight11))
                                  ]))
                        ])))));
  }

  onTapClose1() {
    Get.back();
  }
}
