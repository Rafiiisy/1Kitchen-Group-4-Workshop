import 'controller/feedback_controller.dart';
import 'package:flutter/material.dart';
import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/widgets/app_bar/appbar_image.dart';
import 'package:rifki_s_application3/widgets/app_bar/appbar_subtitle.dart';
import 'package:rifki_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:rifki_s_application3/widgets/custom_button.dart';
import 'package:rifki_s_application3/widgets/custom_text_form_field.dart';

class FeedbackScreen extends GetWidget<FeedbackController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            resizeToAvoidBottomInset: false,
            appBar: CustomAppBar(
                height: getVerticalSize(71),
                leadingWidth: 50,
                leading: AppbarImage(
                    height: getSize(26),
                    width: getSize(26),
                    svgPath: ImageConstant.imgClose,
                    margin: getMargin(left: 24, top: 15, bottom: 14),
                    onTap: onTapClose3),
                centerTitle: true,
                title: AppbarSubtitle(text: "lbl_feedback".tr)),
            body: Container(
                width: size.width,
                height: size.height,
                padding: getPadding(top: 56),
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment(0.5, 0),
                        end: Alignment(0.5, 1),
                        colors: [
                      ColorConstant.green500,
                      ColorConstant.green90001
                    ])),
                child: Container(
                    width: double.maxFinite,
                    padding: getPadding(left: 39, right: 39),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                              padding: getPadding(left: 2),
                              child: Text("msg_how_do_you_feel".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterBold14WhiteA700)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: controller.rectangleOneController,
                              hintText: "lbl_select_options".tr,
                              margin: getMargin(left: 2, top: 4)),
                          Padding(
                              padding: getPadding(left: 2, top: 32),
                              child: Text("msg_tell_us_about_your".tr,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: AppStyle.txtInterBold14WhiteA700)),
                          CustomTextFormField(
                              focusNode: FocusNode(),
                              controller: controller.groupFourController,
                              hintText: "msg_write_your_experience".tr,
                              margin: getMargin(left: 2, top: 5),
                              padding: TextFormFieldPadding.PaddingAll9,
                              textInputAction: TextInputAction.done,
                              maxLines: 16),
                          CustomButton(
                              height: getVerticalSize(43),
                              text: "lbl_submit".tr,
                              margin: getMargin(
                                  left: 41, top: 43, right: 41, bottom: 1),
                              variant: ButtonVariant.OutlineBlack9003f,
                              shape: ButtonShape.RoundedBorder21,
                              fontStyle: ButtonFontStyle.InterRegular16,
                              alignment: Alignment.center)
                        ])))));
  }

  onTapClose3() {
    Get.back();
  }
}
