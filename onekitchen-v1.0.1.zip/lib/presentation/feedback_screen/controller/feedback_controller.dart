import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/presentation/feedback_screen/models/feedback_model.dart';
import 'package:flutter/material.dart';

class FeedbackController extends GetxController {
  TextEditingController rectangleOneController = TextEditingController();

  TextEditingController groupFourController = TextEditingController();

  Rx<FeedbackModel> feedbackModelObj = FeedbackModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
    rectangleOneController.dispose();
    groupFourController.dispose();
  }
}
