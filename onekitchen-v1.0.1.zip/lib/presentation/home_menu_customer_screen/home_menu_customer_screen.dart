import '../home_menu_customer_screen/widgets/gridpexelsphoto7248797_item_widget.dart';
import 'controller/home_menu_customer_controller.dart';
import 'models/gridpexelsphoto7248797_item_model.dart';
import 'package:flutter/material.dart';
import 'package:rifki_s_application3/core/app_export.dart';

class HomeMenuCustomerScreen extends GetWidget<HomeMenuCustomerController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.lightGreen5001,
            body: Container(
                width: getHorizontalSize(375),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Expanded(
                          child: SingleChildScrollView(
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                            Container(
                                height: getVerticalSize(326),
                                width: getHorizontalSize(375),
                                child: Stack(
                                    alignment: Alignment.topLeft,
                                    children: [
                                      Align(
                                          alignment: Alignment.center,
                                          child: Container(
                                              height: getVerticalSize(326),
                                              width: getHorizontalSize(375),
                                              child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    CustomImageView(
                                                        imagePath: ImageConstant
                                                            .imgPexelsphotoby,
                                                        height: getVerticalSize(
                                                            326),
                                                        width:
                                                            getHorizontalSize(
                                                                375),
                                                        alignment:
                                                            Alignment.center),
                                                    Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Container(
                                                            padding: getPadding(
                                                                all: 23),
                                                            decoration:
                                                                AppDecoration
                                                                    .gradientGray900a2Gray900a2,
                                                            child: Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .end,
                                                                children: [
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgLightbulb,
                                                                      height:
                                                                          getSize(
                                                                              31),
                                                                      width:
                                                                          getSize(
                                                                              31),
                                                                      alignment:
                                                                          Alignment
                                                                              .centerRight,
                                                                      margin: getMargin(
                                                                          top:
                                                                              31)),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          top:
                                                                              102),
                                                                      child: Text(
                                                                          "lbl_tanoshimi_sushi"
                                                                              .tr,
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtInterBold20)),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          top:
                                                                              7),
                                                                      child: Text(
                                                                          "msg_6391_elgin_st_celina"
                                                                              .tr,
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtInterRegular12)),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          left:
                                                                              1,
                                                                          top:
                                                                              22,
                                                                          right:
                                                                              1),
                                                                      child: Row(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.spaceBetween,
                                                                          children: [
                                                                            Column(mainAxisAlignment: MainAxisAlignment.start, children: [
                                                                              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                                                                CustomImageView(svgPath: ImageConstant.imgStar, height: getSize(20), width: getSize(20)),
                                                                                Padding(padding: getPadding(left: 2, top: 2), child: Text("lbl_4_5".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtInterMedium14))
                                                                              ]),
                                                                              Padding(padding: getPadding(top: 8), child: Text("lbl_560_rating".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtInterRegular12))
                                                                            ]),
                                                                            Padding(
                                                                                padding: getPadding(top: 2, bottom: 1),
                                                                                child: Column(mainAxisAlignment: MainAxisAlignment.start, children: [
                                                                                  Text("lbl".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtInterMedium14),
                                                                                  Padding(padding: getPadding(top: 7), child: Text("lbl_12_45".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtInterRegular12))
                                                                                ])),
                                                                            Padding(
                                                                                padding: getPadding(bottom: 1),
                                                                                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                                                                  Column(mainAxisAlignment: MainAxisAlignment.start, children: [
                                                                                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                                                                      CustomImageView(svgPath: ImageConstant.imgLocation, height: getSize(20), width: getSize(20)),
                                                                                      Padding(padding: getPadding(top: 3), child: Text("lbl_range".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtInterMedium14))
                                                                                    ]),
                                                                                    Padding(padding: getPadding(top: 6), child: Text("lbl_2_3_km".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtInterRegular12))
                                                                                  ]),
                                                                                  Padding(
                                                                                      padding: getPadding(left: 31),
                                                                                      child: Column(mainAxisAlignment: MainAxisAlignment.start, children: [
                                                                                        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                                                                          CustomImageView(svgPath: ImageConstant.imgLightbulbWhiteA700, height: getSize(20), width: getSize(20)),
                                                                                          Padding(padding: getPadding(left: 2, top: 2), child: Text("lbl_like".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtInterMedium14))
                                                                                        ]),
                                                                                        Padding(padding: getPadding(top: 7), child: Text("lbl_435k".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.txtInterRegular12))
                                                                                      ]))
                                                                                ]))
                                                                          ]))
                                                                ])))
                                                  ]))),
                                      CustomImageView(
                                          imagePath: ImageConstant
                                              .imgLogowithoutbackground,
                                          height: getVerticalSize(141),
                                          width: getHorizontalSize(88),
                                          alignment: Alignment.topLeft,
                                          margin: getMargin(top: 1),
                                          onTap: () {
                                            onTapImgLogowithoutbackground();
                                          })
                                    ])),
                            Padding(
                                padding: getPadding(left: 24, top: 17),
                                child: Text("lbl_your_menu".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterBold16)),
                            Align(
                                alignment: Alignment.center,
                                child: Padding(
                                    padding: getPadding(
                                        left: 24, top: 18, right: 24),
                                    child: Obx(() => GridView.builder(
                                        shrinkWrap: true,
                                        gridDelegate:
                                            SliverGridDelegateWithFixedCrossAxisCount(
                                                mainAxisExtent:
                                                    getVerticalSize(218),
                                                crossAxisCount: 2,
                                                mainAxisSpacing:
                                                    getHorizontalSize(16),
                                                crossAxisSpacing:
                                                    getHorizontalSize(16)),
                                        physics: NeverScrollableScrollPhysics(),
                                        itemCount: controller
                                            .homeMenuCustomerModelObj
                                            .value
                                            .gridpexelsphoto7248797ItemList
                                            .length,
                                        itemBuilder: (context, index) {
                                          Gridpexelsphoto7248797ItemModel
                                              model = controller
                                                      .homeMenuCustomerModelObj
                                                      .value
                                                      .gridpexelsphoto7248797ItemList[
                                                  index];
                                          return Gridpexelsphoto7248797ItemWidget(
                                              model);
                                        }))))
                          ])))
                    ]))));
  }

  onTapImgLogowithoutbackground() {
    Get.toNamed(AppRoutes.homeMenuPopUpScreen);
  }
}
