import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/presentation/home_menu_customer_screen/models/home_menu_customer_model.dart';

class HomeMenuCustomerController extends GetxController {
  Rx<HomeMenuCustomerModel> homeMenuCustomerModelObj =
      HomeMenuCustomerModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
