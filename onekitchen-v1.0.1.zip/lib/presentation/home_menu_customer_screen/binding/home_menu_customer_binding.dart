import '../controller/home_menu_customer_controller.dart';
import 'package:get/get.dart';

class HomeMenuCustomerBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => HomeMenuCustomerController());
  }
}
