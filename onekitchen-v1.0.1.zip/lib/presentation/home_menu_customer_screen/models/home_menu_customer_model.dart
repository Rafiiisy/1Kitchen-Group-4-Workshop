import 'package:get/get.dart';
import 'gridpexelsphoto7248797_item_model.dart';

class HomeMenuCustomerModel {
  RxList<Gridpexelsphoto7248797ItemModel> gridpexelsphoto7248797ItemList =
      RxList.generate(4, (index) => Gridpexelsphoto7248797ItemModel());
}
