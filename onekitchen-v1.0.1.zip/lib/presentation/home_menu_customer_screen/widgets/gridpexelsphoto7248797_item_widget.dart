import '../controller/home_menu_customer_controller.dart';
import '../models/gridpexelsphoto7248797_item_model.dart';
import 'package:flutter/material.dart';
import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/widgets/custom_button.dart';
import 'package:rifki_s_application3/widgets/custom_icon_button.dart';

// ignore: must_be_immutable
class Gridpexelsphoto7248797ItemWidget extends StatelessWidget {
  Gridpexelsphoto7248797ItemWidget(this.gridpexelsphoto7248797ItemModelObj);

  Gridpexelsphoto7248797ItemModel gridpexelsphoto7248797ItemModelObj;

  var controller = Get.find<HomeMenuCustomerController>();

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Container(
        decoration: AppDecoration.outlineGray90019.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder10,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            CustomImageView(
              imagePath: ImageConstant.imgPexelsphoto7248797,
              height: getVerticalSize(
                115,
              ),
              width: getHorizontalSize(
                155,
              ),
              radius: BorderRadius.only(
                topLeft: Radius.circular(
                  getHorizontalSize(
                    10,
                  ),
                ),
                topRight: Radius.circular(
                  getHorizontalSize(
                    10,
                  ),
                ),
              ),
            ),
            Padding(
              padding: getPadding(
                left: 9,
                top: 9,
              ),
              child: Text(
                "lbl_uramaki_sushi".tr,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.left,
                style: AppStyle.txtInterBold14,
              ),
            ),
            Padding(
              padding: getPadding(
                left: 9,
                top: 6,
              ),
              child: Text(
                "lbl_23".tr,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.left,
                style: AppStyle.txtInterMedium12,
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: Padding(
                padding: getPadding(
                  top: 16,
                  bottom: 8,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomButton(
                      height: getVerticalSize(
                        30,
                      ),
                      width: getHorizontalSize(
                        97,
                      ),
                      text: "lbl_order_now".tr,
                      padding: ButtonPadding.PaddingAll7,
                    ),
                    CustomIconButton(
                      height: 30,
                      width: 30,
                      margin: getMargin(
                        left: 8,
                      ),
                      child: CustomImageView(
                        svgPath: ImageConstant.imgFavorite,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
