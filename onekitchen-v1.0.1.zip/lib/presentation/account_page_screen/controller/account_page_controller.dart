import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/presentation/account_page_screen/models/account_page_model.dart';

class AccountPageController extends GetxController {
  Rx<AccountPageModel> accountPageModelObj = AccountPageModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
