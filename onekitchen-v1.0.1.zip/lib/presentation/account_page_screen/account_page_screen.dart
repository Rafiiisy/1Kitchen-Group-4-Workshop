import 'controller/account_page_controller.dart';
import 'package:flutter/material.dart';
import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/widgets/app_bar/appbar_image.dart';
import 'package:rifki_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:rifki_s_application3/widgets/custom_button.dart';

class AccountPageScreen extends GetWidget<AccountPageController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            appBar: CustomAppBar(
                height: getVerticalSize(68),
                leadingWidth: 50,
                leading: AppbarImage(
                    height: getSize(26),
                    width: getSize(26),
                    svgPath: ImageConstant.imgClose,
                    margin: getMargin(left: 24, top: 18, bottom: 11),
                    onTap: onTapClose4),
                centerTitle: true,
                title: Text("msg_outlet_information".tr,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: AppStyle.txtInterRegular30Green500)),
            body: Container(
                width: double.maxFinite,
                padding: getPadding(left: 21, top: 38, right: 21, bottom: 38),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                              padding: getPadding(right: 36),
                              child: Row(children: [
                                CustomImageView(
                                    imagePath:
                                        ImageConstant.imgLifesaversavatar,
                                    height: getVerticalSize(134),
                                    width: getHorizontalSize(116)),
                                Padding(
                                    padding: getPadding(
                                        left: 20, top: 73, bottom: 33),
                                    child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Row(children: [
                                            Text("lbl_name".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.left,
                                                style:
                                                    AppStyle.txtInterRegular20),
                                            CustomImageView(
                                                svgPath: ImageConstant.imgEdit,
                                                height: getSize(19),
                                                width: getSize(19),
                                                margin: getMargin(
                                                    left: 66,
                                                    top: 2,
                                                    bottom: 3))
                                          ]),
                                          Align(
                                              alignment: Alignment.center,
                                              child: Padding(
                                                  padding: getPadding(top: 1),
                                                  child: SizedBox(
                                                      width: getHorizontalSize(
                                                          145),
                                                      child: Divider(
                                                          color: ColorConstant
                                                              .black900))))
                                        ]))
                              ]))),
                      Container(
                          height: getVerticalSize(276),
                          width: getHorizontalSize(261),
                          margin: getMargin(top: 54),
                          child:
                              Stack(alignment: Alignment.centerLeft, children: [
                            Align(
                                alignment: Alignment.topLeft,
                                child: Text("lbl_address".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterRegular20)),
                            Align(
                                alignment: Alignment.centerLeft,
                                child: Text("lbl_phone".tr,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.left,
                                    style: AppStyle.txtInterRegular20)),
                            Align(
                                alignment: Alignment.bottomLeft,
                                child: Padding(
                                    padding: getPadding(left: 2),
                                    child: Text("lbl_email_address".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtInterRegular20))),
                            Align(
                                alignment: Alignment.topCenter,
                                child: Padding(
                                    padding: getPadding(top: 24),
                                    child: SizedBox(
                                        width: getHorizontalSize(260),
                                        child: Divider(
                                            color: ColorConstant.black900)))),
                            Align(
                                alignment: Alignment.bottomCenter,
                                child: Padding(
                                    padding: getPadding(bottom: 125),
                                    child: SizedBox(
                                        width: getHorizontalSize(260),
                                        child: Divider(
                                            color: ColorConstant.black900)))),
                            Align(
                                alignment: Alignment.bottomCenter,
                                child: SizedBox(
                                    width: getHorizontalSize(260),
                                    child: Divider(
                                        color: ColorConstant.black900))),
                            CustomImageView(
                                svgPath: ImageConstant.imgIconedit,
                                height: getVerticalSize(270),
                                width: getHorizontalSize(23),
                                alignment: Alignment.centerRight,
                                margin: getMargin(right: 2))
                          ])),
                      CustomButton(
                          height: getVerticalSize(43),
                          width: getHorizontalSize(199),
                          text: "lbl_save".tr,
                          margin: getMargin(top: 95, bottom: 5),
                          variant: ButtonVariant.FillGreen400,
                          shape: ButtonShape.RoundedBorder21,
                          fontStyle: ButtonFontStyle.InterRegular16,
                          onTap: onTapSave)
                    ]))));
  }

  onTapSave() {
    Get.toNamed(AppRoutes.accountPageOneScreen);
  }

  onTapClose4() {
    Get.back();
  }
}
