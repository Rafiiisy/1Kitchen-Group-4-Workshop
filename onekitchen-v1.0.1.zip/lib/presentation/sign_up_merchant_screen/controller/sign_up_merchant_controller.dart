import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/presentation/sign_up_merchant_screen/models/sign_up_merchant_model.dart';
import 'package:flutter/material.dart';

class SignUpMerchantController extends GetxController {
  TextEditingController rectangleOneController = TextEditingController();

  TextEditingController rectangleTwoController = TextEditingController();

  TextEditingController rectangleThreeController = TextEditingController();

  TextEditingController rectangleFourController = TextEditingController();

  TextEditingController rectangleFiveController = TextEditingController();

  Rx<SignUpMerchantModel> signUpMerchantModelObj = SignUpMerchantModel().obs;

  RxBool checkbox = false.obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
    rectangleOneController.dispose();
    rectangleTwoController.dispose();
    rectangleThreeController.dispose();
    rectangleFourController.dispose();
    rectangleFiveController.dispose();
  }
}
