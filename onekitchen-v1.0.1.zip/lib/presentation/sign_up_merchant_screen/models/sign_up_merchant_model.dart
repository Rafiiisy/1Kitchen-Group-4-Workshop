class SignUpMerchantModel {}
