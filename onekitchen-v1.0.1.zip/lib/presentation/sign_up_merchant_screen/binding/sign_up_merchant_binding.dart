import '../controller/sign_up_merchant_controller.dart';
import 'package:get/get.dart';

class SignUpMerchantBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => SignUpMerchantController());
  }
}
