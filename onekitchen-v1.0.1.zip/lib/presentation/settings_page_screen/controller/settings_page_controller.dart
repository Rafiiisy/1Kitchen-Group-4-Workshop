import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/presentation/settings_page_screen/models/settings_page_model.dart';

class SettingsPageController extends GetxController {
  Rx<SettingsPageModel> settingsPageModelObj = SettingsPageModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
