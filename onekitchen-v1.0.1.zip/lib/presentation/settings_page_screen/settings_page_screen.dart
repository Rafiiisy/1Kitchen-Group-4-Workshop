import 'controller/settings_page_controller.dart';
import 'package:flutter/material.dart';
import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/widgets/app_bar/appbar_image.dart';
import 'package:rifki_s_application3/widgets/app_bar/appbar_subtitle.dart';
import 'package:rifki_s_application3/widgets/app_bar/custom_app_bar.dart';

class SettingsPageScreen extends GetWidget<SettingsPageController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            appBar: CustomAppBar(
                height: getVerticalSize(73),
                leadingWidth: 50,
                leading: AppbarImage(
                    height: getSize(26),
                    width: getSize(26),
                    svgPath: ImageConstant.imgClose,
                    margin: getMargin(left: 24, top: 13, bottom: 16),
                    onTap: onTapClose2),
                centerTitle: true,
                title: AppbarSubtitle(text: "lbl_settings".tr)),
            body: Container(
                width: size.width,
                height: size.height,
                padding: getPadding(top: 56),
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment(0.5, 0),
                        end: Alignment(0.5, 1),
                        colors: [
                      ColorConstant.green500,
                      ColorConstant.green90001
                    ])),
                child: Container(
                    width: double.maxFinite,
                    padding: getPadding(left: 45, right: 45),
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                              margin: getMargin(right: 2),
                              padding: getPadding(
                                  left: 21, top: 13, right: 21, bottom: 13),
                              decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                        padding: getPadding(left: 8, top: 3),
                                        child: Text("lbl_menu".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular20)),
                                    CustomImageView(
                                        svgPath: ImageConstant.imgArrowright,
                                        height: getVerticalSize(14),
                                        width: getHorizontalSize(6),
                                        margin: getMargin(top: 7, bottom: 7))
                                  ])),
                          Container(
                              margin: getMargin(top: 15, right: 2),
                              padding: getPadding(top: 11, bottom: 11),
                              decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: [
                                    Padding(
                                        padding: getPadding(top: 7),
                                        child: Text("msg_payment_billing".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular20)),
                                    CustomImageView(
                                        svgPath: ImageConstant.imgArrowright,
                                        height: getVerticalSize(14),
                                        width: getHorizontalSize(6),
                                        margin: getMargin(top: 8, bottom: 9))
                                  ])),
                          Container(
                              margin: getMargin(top: 15, right: 2),
                              padding: getPadding(
                                  left: 21, top: 13, right: 21, bottom: 13),
                              decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                        padding: getPadding(left: 9, top: 3),
                                        child: Text("lbl_chat".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular20)),
                                    CustomImageView(
                                        svgPath: ImageConstant.imgArrowright,
                                        height: getVerticalSize(14),
                                        width: getHorizontalSize(6),
                                        margin: getMargin(top: 6, bottom: 7))
                                  ])),
                          Container(
                              margin: getMargin(top: 15, right: 2),
                              padding: getPadding(
                                  left: 21, top: 12, right: 21, bottom: 12),
                              decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                        padding: getPadding(left: 9, top: 6),
                                        child: Text("lbl_security".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular20)),
                                    CustomImageView(
                                        svgPath: ImageConstant.imgArrowright,
                                        height: getVerticalSize(14),
                                        width: getHorizontalSize(6),
                                        margin: getMargin(top: 8, bottom: 9))
                                  ])),
                          Container(
                              margin: getMargin(top: 15, right: 2),
                              padding: getPadding(
                                  left: 21, top: 11, right: 21, bottom: 11),
                              decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                        padding: getPadding(left: 9, top: 7),
                                        child: Text("lbl_language".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular20)),
                                    CustomImageView(
                                        svgPath: ImageConstant.imgArrowright,
                                        height: getVerticalSize(14),
                                        width: getHorizontalSize(6),
                                        margin: getMargin(top: 8, bottom: 9))
                                  ])),
                          Container(
                              margin: getMargin(top: 15, right: 2, bottom: 5),
                              padding: getPadding(
                                  left: 21, top: 13, right: 21, bottom: 13),
                              decoration: AppDecoration.fillGray50.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder20),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                        padding: getPadding(left: 9, top: 3),
                                        child: Text("lbl_delete_account".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle.txtInterRegular20)),
                                    CustomImageView(
                                        svgPath: ImageConstant.imgArrowright,
                                        height: getVerticalSize(14),
                                        width: getHorizontalSize(6),
                                        margin: getMargin(top: 6, bottom: 7))
                                  ]))
                        ])))));
  }

  onTapClose2() {
    Get.back();
  }
}
