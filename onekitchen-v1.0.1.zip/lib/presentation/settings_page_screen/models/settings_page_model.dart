class SettingsPageModel {}
