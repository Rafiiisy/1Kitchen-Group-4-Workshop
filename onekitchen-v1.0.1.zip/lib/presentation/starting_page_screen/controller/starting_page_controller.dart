import 'package:rifki_s_application3/core/app_export.dart';
import 'package:rifki_s_application3/presentation/starting_page_screen/models/starting_page_model.dart';

class StartingPageController extends GetxController {
  Rx<StartingPageModel> startingPageModelObj = StartingPageModel().obs;

  @override
  void onReady() {
    super.onReady();
    Future.delayed(const Duration(milliseconds: 3000), () {
      Get.toNamed(AppRoutes.onboardingPageScreen);
    });
  }

  @override
  void onClose() {
    super.onClose();
  }
}
