import 'controller/starting_page_controller.dart';
import 'package:flutter/material.dart';
import 'package:rifki_s_application3/core/app_export.dart';

class StartingPageScreen extends GetWidget<StartingPageController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            body: Container(
                width: size.width,
                height: size.height,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment(0.5, 0),
                        end: Alignment(0.5, 1),
                        colors: [
                      ColorConstant.teal700,
                      ColorConstant.green70000
                    ])),
                child: Container(
                    height: size.height,
                    width: double.maxFinite,
                    child: Stack(alignment: Alignment.center, children: [
                      CustomImageView(
                          imagePath: ImageConstant.imgEb10a983262c4,
                          height: getVerticalSize(718),
                          width: getHorizontalSize(254),
                          alignment: Alignment.centerLeft,
                          margin: getMargin(left: 32)),
                      Align(
                          alignment: Alignment.center,
                          child: Text("lbl_one_kitchen".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtInterMedium20))
                    ])))));
  }
}
