import '../controller/starting_page_controller.dart';
import 'package:get/get.dart';

class StartingPageBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => StartingPageController());
  }
}
