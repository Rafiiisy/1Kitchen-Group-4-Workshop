import 'package:rifki_s_application3/presentation/starting_page_screen/starting_page_screen.dart';
import 'package:rifki_s_application3/presentation/starting_page_screen/binding/starting_page_binding.dart';
import 'package:rifki_s_application3/presentation/home_menu_pop_up_screen/home_menu_pop_up_screen.dart';
import 'package:rifki_s_application3/presentation/home_menu_pop_up_screen/binding/home_menu_pop_up_binding.dart';
import 'package:rifki_s_application3/presentation/home_menu_customer_screen/home_menu_customer_screen.dart';
import 'package:rifki_s_application3/presentation/home_menu_customer_screen/binding/home_menu_customer_binding.dart';
import 'package:rifki_s_application3/presentation/login_page_screen/login_page_screen.dart';
import 'package:rifki_s_application3/presentation/login_page_screen/binding/login_page_binding.dart';
import 'package:rifki_s_application3/presentation/login_successful_screen/login_successful_screen.dart';
import 'package:rifki_s_application3/presentation/login_successful_screen/binding/login_successful_binding.dart';
import 'package:rifki_s_application3/presentation/account_page_one_screen/account_page_one_screen.dart';
import 'package:rifki_s_application3/presentation/account_page_one_screen/binding/account_page_one_binding.dart';
import 'package:rifki_s_application3/presentation/orders_page_screen/orders_page_screen.dart';
import 'package:rifki_s_application3/presentation/orders_page_screen/binding/orders_page_binding.dart';
import 'package:rifki_s_application3/presentation/settings_page_screen/settings_page_screen.dart';
import 'package:rifki_s_application3/presentation/settings_page_screen/binding/settings_page_binding.dart';
import 'package:rifki_s_application3/presentation/feedback_screen/feedback_screen.dart';
import 'package:rifki_s_application3/presentation/feedback_screen/binding/feedback_binding.dart';
import 'package:rifki_s_application3/presentation/onboarding_page_screen/onboarding_page_screen.dart';
import 'package:rifki_s_application3/presentation/onboarding_page_screen/binding/onboarding_page_binding.dart';
import 'package:rifki_s_application3/presentation/sign_up_page_screen/sign_up_page_screen.dart';
import 'package:rifki_s_application3/presentation/sign_up_page_screen/binding/sign_up_page_binding.dart';
import 'package:rifki_s_application3/presentation/signup_successful_screen/signup_successful_screen.dart';
import 'package:rifki_s_application3/presentation/signup_successful_screen/binding/signup_successful_binding.dart';
import 'package:rifki_s_application3/presentation/account_page_screen/account_page_screen.dart';
import 'package:rifki_s_application3/presentation/account_page_screen/binding/account_page_binding.dart';
import 'package:rifki_s_application3/presentation/sign_up_customer_screen/sign_up_customer_screen.dart';
import 'package:rifki_s_application3/presentation/sign_up_customer_screen/binding/sign_up_customer_binding.dart';
import 'package:rifki_s_application3/presentation/sign_up_merchant_screen/sign_up_merchant_screen.dart';
import 'package:rifki_s_application3/presentation/sign_up_merchant_screen/binding/sign_up_merchant_binding.dart';
import 'package:rifki_s_application3/presentation/sign_up_driver_screen/sign_up_driver_screen.dart';
import 'package:rifki_s_application3/presentation/sign_up_driver_screen/binding/sign_up_driver_binding.dart';
import 'package:rifki_s_application3/presentation/app_navigation_screen/app_navigation_screen.dart';
import 'package:rifki_s_application3/presentation/app_navigation_screen/binding/app_navigation_binding.dart';
import 'package:get/get.dart';

class AppRoutes {
  static const String startingPageScreen = '/starting_page_screen';

  static const String homeMenuPopUpScreen = '/home_menu_pop_up_screen';

  static const String homeMenuCustomerScreen = '/home_menu_customer_screen';

  static const String loginPageScreen = '/login_page_screen';

  static const String loginSuccessfulScreen = '/login_successful_screen';

  static const String accountPageOneScreen = '/account_page_one_screen';

  static const String ordersPageScreen = '/orders_page_screen';

  static const String settingsPageScreen = '/settings_page_screen';

  static const String feedbackScreen = '/feedback_screen';

  static const String onboardingPageScreen = '/onboarding_page_screen';

  static const String signUpPageScreen = '/sign_up_page_screen';

  static const String signupSuccessfulScreen = '/signup_successful_screen';

  static const String accountPageScreen = '/account_page_screen';

  static const String signUpCustomerScreen = '/sign_up_customer_screen';

  static const String signUpMerchantScreen = '/sign_up_merchant_screen';

  static const String signUpDriverScreen = '/sign_up_driver_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static String initialRoute = '/initialRoute';

  static List<GetPage> pages = [
    GetPage(
      name: startingPageScreen,
      page: () => StartingPageScreen(),
      bindings: [
        StartingPageBinding(),
      ],
    ),
    GetPage(
      name: homeMenuPopUpScreen,
      page: () => HomeMenuPopUpScreen(),
      bindings: [
        HomeMenuPopUpBinding(),
      ],
    ),
    GetPage(
      name: homeMenuCustomerScreen,
      page: () => HomeMenuCustomerScreen(),
      bindings: [
        HomeMenuCustomerBinding(),
      ],
    ),
    GetPage(
      name: loginPageScreen,
      page: () => LoginPageScreen(),
      bindings: [
        LoginPageBinding(),
      ],
    ),
    GetPage(
      name: loginSuccessfulScreen,
      page: () => LoginSuccessfulScreen(),
      bindings: [
        LoginSuccessfulBinding(),
      ],
    ),
    GetPage(
      name: accountPageOneScreen,
      page: () => AccountPageOneScreen(),
      bindings: [
        AccountPageOneBinding(),
      ],
    ),
    GetPage(
      name: ordersPageScreen,
      page: () => OrdersPageScreen(),
      bindings: [
        OrdersPageBinding(),
      ],
    ),
    GetPage(
      name: settingsPageScreen,
      page: () => SettingsPageScreen(),
      bindings: [
        SettingsPageBinding(),
      ],
    ),
    GetPage(
      name: feedbackScreen,
      page: () => FeedbackScreen(),
      bindings: [
        FeedbackBinding(),
      ],
    ),
    GetPage(
      name: onboardingPageScreen,
      page: () => OnboardingPageScreen(),
      bindings: [
        OnboardingPageBinding(),
      ],
    ),
    GetPage(
      name: signUpPageScreen,
      page: () => SignUpPageScreen(),
      bindings: [
        SignUpPageBinding(),
      ],
    ),
    GetPage(
      name: signupSuccessfulScreen,
      page: () => SignupSuccessfulScreen(),
      bindings: [
        SignupSuccessfulBinding(),
      ],
    ),
    GetPage(
      name: accountPageScreen,
      page: () => AccountPageScreen(),
      bindings: [
        AccountPageBinding(),
      ],
    ),
    GetPage(
      name: signUpCustomerScreen,
      page: () => SignUpCustomerScreen(),
      bindings: [
        SignUpCustomerBinding(),
      ],
    ),
    GetPage(
      name: signUpMerchantScreen,
      page: () => SignUpMerchantScreen(),
      bindings: [
        SignUpMerchantBinding(),
      ],
    ),
    GetPage(
      name: signUpDriverScreen,
      page: () => SignUpDriverScreen(),
      bindings: [
        SignUpDriverBinding(),
      ],
    ),
    GetPage(
      name: appNavigationScreen,
      page: () => AppNavigationScreen(),
      bindings: [
        AppNavigationBinding(),
      ],
    ),
    GetPage(
      name: initialRoute,
      page: () => StartingPageScreen(),
      bindings: [
        StartingPageBinding(),
      ],
    )
  ];
}
