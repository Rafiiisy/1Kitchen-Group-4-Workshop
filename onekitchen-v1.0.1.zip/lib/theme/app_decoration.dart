import 'package:flutter/material.dart';
import 'package:rifki_s_application3/core/app_export.dart';

class AppDecoration {
  static BoxDecoration get outlineTeal700 => BoxDecoration(
        border: Border.all(
          color: ColorConstant.teal700,
          width: getHorizontalSize(
            2,
          ),
        ),
      );
  static BoxDecoration get fillLightgreen5001 => BoxDecoration(
        color: ColorConstant.lightGreen5001,
      );
  static BoxDecoration get outlineGray90019 => BoxDecoration(
        color: ColorConstant.green500,
        boxShadow: [
          BoxShadow(
            color: ColorConstant.gray90019,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              3,
            ),
          ),
        ],
      );
  static BoxDecoration get gradientGreen500Green90001 => BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment(
            0.5,
            0,
          ),
          end: Alignment(
            0.5,
            1,
          ),
          colors: [
            ColorConstant.green500,
            ColorConstant.green90001,
          ],
        ),
      );
  static BoxDecoration get fillGray50 => BoxDecoration(
        color: ColorConstant.gray50,
      );
  static BoxDecoration get fillLightgreen50 => BoxDecoration(
        color: ColorConstant.lightGreen50,
      );
  static BoxDecoration get outlineBlack9003f => BoxDecoration(
        color: ColorConstant.lightGreen5001,
        boxShadow: [
          BoxShadow(
            color: ColorConstant.black9003f,
            spreadRadius: getHorizontalSize(
              2,
            ),
            blurRadius: getHorizontalSize(
              2,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ],
      );
  static BoxDecoration get gradientGray900a2Gray900a2 => BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment(
            0.5,
            0.16,
          ),
          end: Alignment(
            0.5,
            1,
          ),
          colors: [
            ColorConstant.gray900A2,
            ColorConstant.gray900A2,
          ],
        ),
      );
  static BoxDecoration get outline => BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment(
            0.5,
            0,
          ),
          end: Alignment(
            0.5,
            1,
          ),
          colors: [
            ColorConstant.teal700,
            ColorConstant.green70000,
          ],
        ),
      );
  static BoxDecoration get fillTeal700 => BoxDecoration(
        color: ColorConstant.teal700,
      );
  static BoxDecoration get fillWhiteA700 => BoxDecoration(
        color: ColorConstant.whiteA700,
      );
}

class BorderRadiusStyle {
  static BorderRadius roundedBorder5 = BorderRadius.circular(
    getHorizontalSize(
      5,
    ),
  );

  static BorderRadius roundedBorder10 = BorderRadius.circular(
    getHorizontalSize(
      10,
    ),
  );

  static BorderRadius customBorderTL10 = BorderRadius.only(
    topLeft: Radius.circular(
      getHorizontalSize(
        10,
      ),
    ),
    topRight: Radius.circular(
      getHorizontalSize(
        10,
      ),
    ),
  );

  static BorderRadius roundedBorder20 = BorderRadius.circular(
    getHorizontalSize(
      20,
    ),
  );
}
