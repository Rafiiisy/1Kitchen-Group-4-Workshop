import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./CustomerRestoSushiTei.css";

const CustomerRestoSushiTei: FunctionComponent = () => {
  const navigate = useNavigate();

  const onSearchButtonClick = useCallback(() => {
    navigate("/customersearch");
  }, [navigate]);

  const onAccountButtonClick = useCallback(() => {
    navigate("/menu-customer");
  }, [navigate]);

  return (
    <div className="customer-resto-sushi-tei">
      <img
        className="pexels-photo-by-pixabay-icon"
        alt=""
        src="/pexelsphotobypixabay@2x.png"
      />
      <div className="rectangle-43941" />
      <img className="k-colour-1-icon1" alt="" src="/1kcolour1@2x.png" />
      <b className="b8">4.5</b>
      <div className="ratings1">560 ratings</div>
      <b className="b9">$$$</b>
      <div className="div1">$15 - $45</div>
      <div className="liked-by1">Liked by</div>
      <b className="k1">435K</b>
      <img className="heart-icon1" alt="" src="/hearticon.svg" />
      <b className="sushi-tei">Sushi Tei</b>
      <div className="menu1">Menu</div>
      <div className="line-11" />
      <div className="frame-div">
        <div className="rectangle-44146" />
        <img className="mask-group-icon6" alt="" src="/maskgroup1@2x.png" />
        <b className="sushi-1">Sushi 1</b>
        <b className="b10">$20</b>
        <div className="rectangle-4415" />
        <img className="mask-group-icon7" alt="" src="/maskgroup2@2x.png" />
        <b className="sushi-2">Sushi 2</b>
        <b className="b11">$20</b>
        <div className="rectangle-44147" />
        <img className="mask-group-icon8" alt="" src="/maskgroup2@2x.png" />
        <b className="sushi-3">Sushi 3</b>
        <b className="b12">$20</b>
        <div className="rectangle-44151" />
        <img className="mask-group-icon9" alt="" src="/maskgroup2@2x.png" />
        <b className="sushi-4">Sushi 4</b>
        <b className="b13">$20</b>
        <div className="rectangle-44148" />
        <img className="mask-group-icon10" alt="" src="/maskgroup2@2x.png" />
        <b className="sushi-11">Sushi 1</b>
        <b className="b14">$20</b>
        <div className="rectangle-44152" />
        <img className="mask-group-icon11" alt="" src="/maskgroup2@2x.png" />
        <b className="sushi-21">Sushi 2</b>
        <b className="b15">$20</b>
      </div>
      <footer className="footer1">
        <button className="home-button1">
          <img className="vector-home-icon1" alt="" src="/vectorhome.svg" />
          <div className="home1">Home</div>
        </button>
        <button className="search-button1" onClick={onSearchButtonClick}>
          <div className="frame-821">
            <img
              className="searchvector-icon1"
              alt=""
              src="/searchvector.svg"
            />
            <div className="explore1">Explore</div>
          </div>
        </button>
        <div className="orders-button1">
          <img className="vector-clock-icon1" alt="" src="/vectorclock.svg" />
          <div className="orders1">Orders</div>
        </div>
        <button className="account-button1" onClick={onAccountButtonClick}>
          <img className="vector-user-icon1" alt="" src="/vectoruser2.svg" />
          <div className="account1">Account</div>
        </button>
      </footer>
    </div>
  );
};

export default CustomerRestoSushiTei;
