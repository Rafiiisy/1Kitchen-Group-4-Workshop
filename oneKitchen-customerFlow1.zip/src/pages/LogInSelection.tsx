import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./LogInSelection.css";

const LogInSelection: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrame37449Click = useCallback(() => {
    navigate("/login");
  }, [navigate]);

  const onFrame37448Click = useCallback(() => {
    // Please sync "log-in" to the project
  }, []);

  const onFrame37447Click = useCallback(() => {
    navigate("/login");
  }, [navigate]);

  return (
    <div className="log-in-selection">
      <div className="frame-37446">
        <b className="welcome2">Welcome!</b>
        <b className="please-choose-accordingly">Please choose accordingly!</b>
      </div>
      <img className="ellipse-6-icon3" alt="" src="/ellipse63.svg" />
      <div className="frame-37449-parent">
        <button className="frame-37449" onClick={onFrame37449Click}>
          <b className="driver">Driver</b>
          <img className="icon" alt="" src="/45672181@2x.png" />
        </button>
        <button className="frame-37448" onClick={onFrame37448Click}>
          <b className="merchant">Merchant</b>
          <img
            className="avd437689ef3a02914ac1-1-icon"
            alt=""
            src="/avd437689ef3a02914ac11@2x.png"
          />
        </button>
        <button className="frame-37447" onClick={onFrame37447Click}>
          <b className="customer">Customer</b>
          <img
            className="icons8-shopping-cart-90-1"
            alt=""
            src="/icons8shoppingcart901@2x.png"
          />
        </button>
      </div>
    </div>
  );
};

export default LogInSelection;
