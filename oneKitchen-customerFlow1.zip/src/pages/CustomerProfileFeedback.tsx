import { FunctionComponent, useCallback } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Form } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import "./CustomerProfileFeedback.css";

const CustomerProfileFeedback: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrame26ActiongobackLayContainerClick = useCallback(() => {
    navigate("/menu-customer");
  }, [navigate]);

  const onGroup37342Click = useCallback(() => {
    navigate("/menu-customer");
  }, [navigate]);

  const onRectangle4400Click = useCallback(() => {
    navigate("/menu-customer");
  }, [navigate]);

  return (
    <div className="customer-profile-feedback">
      <div className="frame-14-container-top-bar">
        <b className="feedback">Feedback</b>
        <div className="line-9" />
        <div
          className="frame-26-actiongoback-lay"
          onClick={onFrame26ActiongobackLayContainerClick}
        >
          <img
            className="arrow-down-sign-to-navigate-5-icon"
            alt=""
            src="/arrowdownsigntonavigate51@2x.png"
          />
        </div>
      </div>
      <div className="frame-15-container">
        <b className="how-do-you">How do you feel about 1Kitchen?</b>
        <Form.Select className="group-37297-formselect">
          <option>select options</option>
          <option value="Happy">Happy</option>
          <option value="Okay">Okay</option>
          <option value="Dissatisfied">Dissatisfied</option>
        </Form.Select>
        <b className="tell-us-about">Tell us about your experience!</b>
        <input
          className="frame-15-container-child"
          type="text"
          placeholder="Write your experience..."
          required
          autoFocus
        />
      </div>
      <button className="group-37342" onClick={onGroup37342Click}>
        <div className="rectangle-44004" onClick={onRectangle4400Click} />
        <b className="submit">Submit</b>
      </button>
    </div>
  );
};

export default CustomerProfileFeedback;
