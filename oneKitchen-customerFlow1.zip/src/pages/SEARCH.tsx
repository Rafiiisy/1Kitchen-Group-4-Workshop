import { FunctionComponent, useCallback } from "react";
import "antd/dist/antd.min.css";
import { Input } from "antd";
import {
  DownOutlined,
  ArrowLeftOutlined,
  ArrowRightOutlined,
  CalendarOutlined,
  CheckOutlined,
  ClockCircleOutlined,
  CloseOutlined,
  DeleteOutlined,
  EditOutlined,
  ExclamationCircleOutlined,
  HeartOutlined,
  LeftOutlined,
  LockOutlined,
  MailOutlined,
  PaperClipOutlined,
  PhoneOutlined,
  QuestionCircleOutlined,
  ReloadOutlined,
  RightOutlined,
  SearchOutlined,
  SendOutlined,
  ShareAltOutlined,
  UserOutlined,
} from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import "./SEARCH.css";

const SEARCH: FunctionComponent = () => {
  const navigate = useNavigate();

  const onPizzaClick = useCallback(() => {
    navigate("/customerhomecategory-2");
  }, [navigate]);

  const onBurger95Click = useCallback(() => {
    navigate("/customerhomecategory-1");
  }, [navigate]);

  const onSearchButtonClick = useCallback(() => {
    // Please sync "search1" to the project
  }, []);

  const onAccountButtonClick = useCallback(() => {
    navigate("/menu-customer");
  }, [navigate]);

  return (
    <div className="customer-search">
      <header className="frame-84">
        <h6 className="search">Search</h6>
        <Input
          className="search-bar"
          type="text"
          style={{ width: "259px" }}
          prefix={<SearchOutlined />}
          size="middle"
          placeholder="What are you craving?"
          allowClear
        />
      </header>
      <div className="frame-37431">
        <div className="frame-83">
          <button className="sushi">
            <div className="sushi1">Sushi</div>
          </button>
          <button className="thai">
            <div className="sushi1">Thai</div>
          </button>
          <button className="pizza1" onClick={onPizzaClick}>
            <div className="sushi1">Pizza</div>
          </button>
          <button className="tortilla">
            <div className="sushi1">Tortilla</div>
          </button>
          <button className="burger-95" onClick={onBurger95Click}>
            <div className="sushi1">Burger</div>
          </button>
        </div>
        <div className="rectangle-160" />
        <div className="mexican">Mexican</div>
        <div className="rectangle-159" />
        <div className="wings">Wings</div>
        <div className="rectangle-158" />
        <div className="chinese">Chinese</div>
        <div className="rectangle-157" />
        <div className="indian">Indian</div>
        <div className="rectangle-165" />
        <div className="vegetarian">Vegetarian</div>
        <div className="rectangle-163" />
        <div className="rectangle-163" />
        <div className="salad">Salad</div>
        <div className="rectangle-162" />
        <div className="padang">Padang</div>
        <div className="rectangle-161" />
        <div className="fast-food">Fast Food</div>
        <div className="rectangle-170" />
        <div className="taco">Taco</div>
        <div className="rectangle-169" />
        <div className="coffee">Coffee</div>
        <div className="rectangle-168" />
        <div className="italian">Italian</div>
        <div className="rectangle-166" />
        <div className="kebab">Kebab</div>
        <div className="rectangle-167" />
        <div className="steak">Steak</div>
        <div className="rectangle-171" />
        <div className="sandwich">Sandwich</div>
        <div className="rectangle-172" />
        <div className="falafel">Falafel</div>
        <div className="rectangle-173" />
        <div className="kosher">Kosher</div>
      </div>
      <h1 className="popular-categories">Popular categories</h1>
      <b className="my-recent-orders">My recent orders</b>
      <div className="frame-37428">
        <img className="intersect-icon" alt="" src="/intersect@2x.png" />
        <div className="km1">3,5 km</div>
        <div className="min6">{`20- 40 min `}</div>
        <button className="green-curry">Green Curry</button>
        <div className="indian-curries">Indian, Curries</div>
        <div className="div19">4.7</div>
        <img className="vector-star-icon" alt="" src="/vector-star.svg" />
      </div>
      <div className="frame-37429">
        <img className="intersect-icon" alt="" src="/intersect1@2x.png" />
        <div className="km1">3,5 km</div>
        <div className="min6">{`20- 40 min `}</div>
        <button className="green-curry">Suhi Tei</button>
        <div className="indian-curries">Japanies, Sushi</div>
        <div className="div19">4.7</div>
        <img className="vector-star-icon" alt="" src="/vector-star1.svg" />
      </div>
      <div className="frame-37430">
        <img className="intersect-icon" alt="" src="/intersect1@2x.png" />
        <div className="km1">3,5 km</div>
        <div className="min6">{`20- 40 min `}</div>
        <button className="green-curry">Pizza Hut</button>
        <div className="indian-curries">Italian, Pizza</div>
        <div className="div19">4.7</div>
        <img className="vector-star-icon" alt="" src="/vector-star1.svg" />
      </div>
      <footer className="frame-852">
        <footer className="footer5">
          <button className="home-button5">
            <img className="vector-home-icon5" alt="" src="/vectorhome3.svg" />
            <div className="home5">Home</div>
          </button>
          <button className="search-button5" onClick={onSearchButtonClick}>
            <div className="frame-825">
              <img
                className="searchvector-icon5"
                alt=""
                src="/searchvector.svg"
              />
              <div className="explore5">Explore</div>
            </div>
          </button>
          <div className="orders-button5">
            <img
              className="vector-clock-icon5"
              alt=""
              src="/vectorclock1.svg"
            />
            <div className="orders5">Orders</div>
          </div>
          <button className="account-button5" onClick={onAccountButtonClick}>
            <img className="vector-user-icon5" alt="" src="/vectoruser3.svg" />
            <div className="account5">Account</div>
          </button>
        </footer>
      </footer>
    </div>
  );
};

export default SEARCH;
