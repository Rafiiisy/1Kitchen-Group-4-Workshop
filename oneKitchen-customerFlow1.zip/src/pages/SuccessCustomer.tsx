import { FunctionComponent } from "react";
import "./SuccessCustomer.css";

const SuccessCustomer: FunctionComponent = () => {
  return (
    <div className="success-customer">
      <img className="asset-1-1-icon2" alt="" src="/asset11.svg" />
      <b className="success2">Success!</b>
      <b className="your-successfully-ordered">
        Your successfully ordered the items!
      </b>
      <div className="continue-to-log-in4">
        <b className="continue-to-log-container">
          <span>{`Continue to `}</span>
          <span className="log-in">Log In</span>
        </b>
      </div>
    </div>
  );
};

export default SuccessCustomer;
