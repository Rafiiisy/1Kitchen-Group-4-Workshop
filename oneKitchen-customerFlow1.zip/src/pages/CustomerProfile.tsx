import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./CustomerProfile.css";

const CustomerProfile: FunctionComponent = () => {
  const navigate = useNavigate();

  const onLogoutActionlogoutfirebaseClick = useCallback(() => {
    // Please sync "log-in" to the project
  }, []);

  const onRectangle4400Click = useCallback(() => {
    // Please sync "log-in" to the project
  }, []);

  const onIconEditClick = useCallback(() => {
    navigate("/customerprofileedit-profile");
  }, [navigate]);

  const onGroup37354Click = useCallback(() => {
    navigate("/customerprofilefeedback");
  }, [navigate]);

  const onArrowDownSignToNavigate8IconClick = useCallback(() => {
    navigate("/customerprofilefeedback");
  }, [navigate]);

  return (
    <div className="customer-profile">
      <div className="frame-9-container-top-bar">
        <div className="frame-25-actiongobacklaye">
          <img
            className="icons8-close-30-1"
            alt=""
            src="/icons8close301@2x.png"
          />
        </div>
      </div>
      <button
        className="logout-actionlogoutfirebase"
        onClick={onLogoutActionlogoutfirebaseClick}
      >
        <div className="group-37294">
          <div className="rectangle-44005" onClick={onRectangle4400Click} />
          <b className="sign-out">Sign Out</b>
        </div>
      </button>
      <div className="frame-11-container">
        <div className="line-5" />
        <button className="icon-edit" onClick={onIconEditClick}>
          <img className="group-icon" alt="" src="/group.svg" />
        </button>
        <div className="line-6" />
        <div className="line-7" />
        <div className="line-8" />
        <div className="line-111" />
        <div className="line-91" />
        <div className="group-37355">
          <img className="privacy-1-icon" alt="" src="/privacy1@2x.png" />
          <div className="group-37332">
            <b className="privacy-security">{`Privacy & Security`}</b>
          </div>
          <img
            className="arrow-down-sign-to-navigate-7-icon"
            alt=""
            src="/arrowdownsigntonavigate7@2x.png"
          />
        </div>
        <button className="group-37354" onClick={onGroup37354Click}>
          <b className="support-and-feedback">Support and Feedback</b>
          <img
            className="arrow-down-sign-to-navigate-8-icon"
            alt=""
            src="/arrowdownsigntonavigate7@2x.png"
            onClick={onArrowDownSignToNavigate8IconClick}
          />
          <div className="support-1">
            <img className="support-1-icon" alt="" src="/support1@2x.png" />
          </div>
        </button>
        <div className="group-37352">
          <img className="privacy-1-icon" alt="" src="/wallet1@2x.png" />
          <b className="payment-methods">Payment Methods</b>
          <img
            className="arrow-down-sign-to-navigate-7-icon"
            alt=""
            src="/arrowdownsigntonavigate7@2x.png"
          />
        </div>
        <div className="group-37357">
          <b className="orders6">Orders</b>
          <img
            className="arrow-down-sign-to-navigate-5-icon1"
            alt=""
            src="/arrowdownsigntonavigate7@2x.png"
          />
          <img className="online-1-icon" alt="" src="/online1@2x.png" />
        </div>
        <div className="group-37353">
          <b className="privacy-security">Invite Friends</b>
          <img
            className="arrow-down-sign-to-navigate-9-icon"
            alt=""
            src="/arrowdownsigntonavigate7@2x.png"
          />
        </div>
        <div className="group-37356">
          <b className="payment-methods">Location</b>
          <img
            className="arrow-down-sign-to-navigate-7-icon"
            alt=""
            src="/arrowdownsigntonavigate7@2x.png"
          />
          <img className="privacy-1-icon" alt="" src="/location1@2x.png" />
        </div>
        <img className="icon-people" alt="" src="/iconpeople.svg" />
        <div className="group-37328">
          <b className="sponge-bob">Sponge Bob</b>
          <div className="block-b-phase1">
            Block B Phase 2 Johar Town, Lahore
          </div>
        </div>
        <img className="avatar-icon1" alt="" src="/avatar.svg" />
      </div>
    </div>
  );
};

export default CustomerProfile;
