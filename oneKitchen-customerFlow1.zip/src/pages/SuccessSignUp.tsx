import { FunctionComponent, useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./SuccessSignUp.css";

const SuccessSignUp: FunctionComponent = () => {
  const navigate = useNavigate();
  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add("animate");
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  const onContinueToLogInClick = useCallback(() => {
    navigate("/login");
  }, [navigate]);

  return (
    <div className="success-sign-up">
      <div className="asset-1-1-group">
        <img
          className="asset-1-1-icon1"
          alt=""
          src="/asset-1-11.svg"
          data-animate-on-scroll
        />
        <div className="continue-to-log-in2">
          <b className="continue-to-log2">Continue to</b>
        </div>
        <button
          className="continue-to-log-in3"
          onClick={onContinueToLogInClick}
        >
          <b className="continue-to-log3">Log In</b>
        </button>
      </div>
      <div className="success-group">
        <b className="success1">Success!</b>
        <b className="your-account-has">Your account has been created!</b>
      </div>
    </div>
  );
};

export default SuccessSignUp;
