import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./CustomerOrderSuccession.css";

const CustomerOrderSuccession: FunctionComponent = () => {
  const navigate = useNavigate();

  const onButtonClick = useCallback(() => {
    navigate("/home-customer");
  }, [navigate]);

  return (
    <div className="customer-order-succession">
      <div className="frame-73container">
        <img className="checkcircle-icon" alt="" src="/checkcircle.svg" />
        <div className="text10">
          <b className="thank-you-for">Thank you for placing the order</b>
          <div className="well-get-to">
            We’ll get to you as soon as possible
          </div>
        </div>
        <img
          className="undraw-on-the-way-re-swjt-1-icon"
          alt=""
          src="/undrawonthewayreswjt1.svg"
        />
        <button className="button4" onClick={onButtonClick}>
          <b className="button5">Go Home</b>
        </button>
      </div>
      <div className="home-indicator4">
        <div className="home-indicator5" />
      </div>
    </div>
  );
};

export default CustomerOrderSuccession;
