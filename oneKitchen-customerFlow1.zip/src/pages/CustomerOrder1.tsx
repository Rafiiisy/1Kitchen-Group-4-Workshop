import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./CustomerOrder1.css";

const CustomerOrder1: FunctionComponent = () => {
  const navigate = useNavigate();

  const onArrowleftClick = useCallback(() => {
    navigate("/customerorder-main");
  }, [navigate]);

  const onButtonClick = useCallback(() => {
    navigate("/customerordercart");
  }, [navigate]);

  return (
    <div className="customer-order-1">
      <div className="imgcontainertop-bar">
        <img className="image-icon" alt="" src="/image@2x.png" />
        <div className="daily-deli-">Daily Deli - Johar Town</div>
        <b className="chicken-fajita-pizza">Chicken Fajita Pizza</b>
      </div>
      <div className="app-bar">
        <div className="bg1" />
        <b className="headline1">Daily Deli</b>
        <button className="arrowleft" onClick={onArrowleftClick}>
          <img className="arrowleft-icon1" alt="" src="/arrowleft1.svg" />
        </button>
        <div className="text-or-buttons1">
          <div className="skip1">Skip</div>
          <div className="buttons2">
            <img className="minus-icon" alt="" src="/heart1.svg" />
            <img className="minus-icon" alt="" src="/sharenetwork1.svg" />
            <img className="minus-icon" alt="" src="/dotsthreevertical1.svg" />
          </div>
        </div>
      </div>
      <div className="frame-70container">
        <div className="content">
          <div className="variation">
            <div className="title">
              <b className="extra-sauce">Variation</b>
              <div className="required">Required</div>
            </div>
            <div className="list">
              <div className="list-general">
                <div className="container">
                  <div className="radio-buttons">
                    <div className="vector" />
                    <img className="vector-icon" alt="" src="/vector.svg" />
                  </div>
                  <div className="label">8”</div>
                  <div className="trailing-content">
                    <div className="label">$10</div>
                  </div>
                </div>
                <img className="divider-icon" alt="" src="/divider.svg" />
              </div>
              <div className="list-general">
                <div className="container">
                  <div className="radio-buttons">
                    <div className="vector" />
                    <img className="vector-icon" alt="" src="/vector1.svg" />
                  </div>
                  <div className="label">10”</div>
                  <div className="trailing-content">
                    <div className="label">$12</div>
                  </div>
                </div>
                <img className="divider-icon" alt="" src="/divider.svg" />
              </div>
              <div className="list-general">
                <div className="container">
                  <div className="radio-buttons">
                    <div className="vector" />
                    <img className="vector-icon" alt="" src="/vector.svg" />
                  </div>
                  <div className="label">12”</div>
                  <div className="trailing-content">
                    <div className="label">$16</div>
                  </div>
                </div>
                <img className="divider-icon" alt="" src="/divider.svg" />
              </div>
            </div>
          </div>
          <div className="spacer2">
            <div className="spacer3" />
          </div>
          <div className="instructions">
            <div className="title1">
              <b className="quanity">Quanity</b>
              <b className="quanity1">Quanity</b>
            </div>
            <div className="text-field">
              <img className="minus-icon" alt="" src="/minus.svg" />
              <div className="label">01</div>
              <img className="minus-icon" alt="" src="/plus.svg" />
            </div>
          </div>
          <div className="spacer2">
            <div className="spacer3" />
          </div>
          <div className="variation">
            <div className="title">
              <b className="extra-sauce">Extra Sauce</b>
              <div className="required1">Required</div>
            </div>
            <div className="list">
              <div className="list-general">
                <div className="container">
                  <img className="minus-icon" alt="" src="/checkbox.svg" />
                  <div className="label">Texas Barbeque</div>
                  <div className="trailing-content">
                    <div className="label">+$6</div>
                  </div>
                </div>
                <img className="divider-icon" alt="" src="/divider.svg" />
              </div>
              <div className="list-general">
                <div className="container">
                  <img className="minus-icon" alt="" src="/checkbox1.svg" />
                  <div className="label">Char Donay</div>
                  <div className="trailing-content">
                    <div className="label">+$8</div>
                  </div>
                </div>
                <img className="divider-icon" alt="" src="/divider.svg" />
              </div>
            </div>
          </div>
          <div className="spacer2">
            <div className="spacer3" />
          </div>
          <div className="instructions">
            <div className="title1">
              <b className="quanity">Instructions</b>
              <div className="let-us-know">
                Let us know if you have specific things in mind
              </div>
            </div>
            <div className="text-field1">
              <div className="label">e.g. less spices, no mayo etc</div>
            </div>
          </div>
          <div className="spacer2">
            <div className="spacer3" />
          </div>
          <div className="instructions3">
            <div className="title1">
              <b className="instructions4">Instructions</b>
              <b className="if-the-product">If the product is not available</b>
            </div>
            <div className="text-field2">
              <div className="label">Remove it from my order</div>
              <img className="minus-icon" alt="" src="/caretdown.svg" />
            </div>
          </div>
        </div>
      </div>
      <div className="frame-69layer">
        <div className="cart-bottom-bar">
          <b className="b16">$20</b>
          <button className="button2" onClick={onButtonClick}>
            <b className="button3">Add to cart</b>
          </button>
        </div>
      </div>
      <div className="home-indicator">
        <div className="home-indicator1" />
      </div>
    </div>
  );
};

export default CustomerOrder1;
