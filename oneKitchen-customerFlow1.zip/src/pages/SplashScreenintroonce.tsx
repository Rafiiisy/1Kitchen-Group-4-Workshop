import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./SplashScreenintroonce.css";

const SplashScreenintroonce: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrame37441Click = useCallback(() => {
    navigate("/login");
  }, [navigate]);

  return (
    <div className="splash-screenintroonce">
      <button className="frame-37441" onClick={onFrame37441Click}>
        <img className="k-white-1-icon" alt="" src="/1kwhite1@2x.png" />
        <b className="one-kitchen">One Kitchen</b>
      </button>
    </div>
  );
};

export default SplashScreenintroonce;
