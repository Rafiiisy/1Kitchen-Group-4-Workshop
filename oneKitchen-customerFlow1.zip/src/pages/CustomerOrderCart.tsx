import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./CustomerOrderCart.css";

const CustomerOrderCart: FunctionComponent = () => {
  const navigate = useNavigate();

  const onGroup37401ContainerClick = useCallback(() => {
    navigate("/customerorder-1");
  }, [navigate]);

  const onOrangeCheckoutButtonClick = useCallback(() => {
    navigate("/customerordersuccession");
  }, [navigate]);

  return (
    <div className="customer-order-cart">
      <div className="frame-72containertop-bar">
        <div className="group-37401" onClick={onGroup37401ContainerClick}>
          <div className="cart">Cart</div>
          <img className="vector-icon4" alt="" src="/vector4.svg" />
          <img className="image-2-icon" alt="" src="/image21@2x.png" />
        </div>
      </div>
      <div className="frame-71container">
        <div className="rp-16850000">Rp. 168.500.00</div>
        <div className="total">Total</div>
        <button
          className="orange-checkout-button"
          onClick={onOrangeCheckoutButtonClick}
        >
          <div className="rectangle-84" />
          <div className="checkout">Checkout</div>
        </button>
      </div>
      <div className="frame-53container">
        <div className="group-37412">
          <div className="rectangle-12" />
          <div className="whopper-combo-m">Whopper Combo M..</div>
          <div className="rp-4750000">Rp. 47.500,00</div>
          <div className="number-of-boogers">
            <button className="rectangle-102" />
            <img className="plus-icon1" alt="" src="/plus1.svg" />
            <div className="div28">1</div>
            <img className="vector-icon5" alt="" src="/vector5.svg" />
          </div>
          <img className="image-4-icon" alt="" src="/image41@2x.png" />
          <img className="icon-trash" alt="" src="/icontrash.svg" />
        </div>
        <div className="group-37411">
          <div className="rectangle-12" />
          <div className="bts-meal">BTS Meal</div>
          <div className="rp-9050000">Rp. 90.500,00</div>
          <div className="number-of-boogers1">
            <div className="rectangle-103" />
            <img className="plus-icon1" alt="" src="/plus1.svg" />
            <div className="div28">2</div>
            <img className="vector-icon5" alt="" src="/vector5.svg" />
          </div>
          <img className="image-3-icon" alt="" src="/image31@2x.png" />
          <img className="icon-trash1" alt="" src="/icontrash.svg" />
        </div>
        <div className="group-37410">
          <div className="rectangle-12" />
          <img className="icon-trash1" alt="" src="/icontrash.svg" />
          <div className="popeyes-chicken-sa">Popeye’s Chicken Sa...</div>
          <div className="rp-47500001">Rp. 47.500,00</div>
          <div className="number-of-boogers2">
            <div className="rectangle-103" />
            <img className="plus-icon1" alt="" src="/plus1.svg" />
            <div className="div28">1</div>
            <img className="vector-icon5" alt="" src="/vector5.svg" />
          </div>
          <img className="image-5-icon" alt="" src="/image41@2x.png" />
        </div>
        <div className="rectangle-15" />
        <div className="whopper-combo-m1">Whopper Combo M..</div>
        <div className="rp-47500002">Rp. 47.500,00</div>
        <div className="number-of-boogers3">
          <div className="rectangle-103" />
          <img className="plus-icon1" alt="" src="/plus1.svg" />
          <div className="div28">1</div>
          <img className="vector-icon5" alt="" src="/vector5.svg" />
        </div>
        <img className="image-4-icon1" alt="" src="/image41@2x.png" />
        <img className="icon-trash3" alt="" src="/icontrash1.svg" />
        <img className="icon-trash4" alt="" src="/icontrash.svg" />
        <div className="group-37414">
          <div className="rectangle-12" />
          <div className="whopper-combo-m2">Whopper Combo M..</div>
          <div className="rp-47500003">Rp. 47.500,00</div>
          <div className="number-of-boogers4">
            <div className="rectangle-103" />
            <img className="plus-icon5" alt="" src="/plus1.svg" />
            <div className="div28">1</div>
            <img className="vector-icon9" alt="" src="/vector5.svg" />
          </div>
          <img className="image-3-icon" alt="" src="/image41@2x.png" />
          <img className="icon-trash1" alt="" src="/icontrash1.svg" />
        </div>
        <div className="group-37413">
          <div className="rectangle-12" />
          <div className="whopper-combo-m2">Whopper Combo M..</div>
          <div className="rp-47500003">Rp. 47.500,00</div>
          <div className="number-of-boogers4">
            <div className="rectangle-103" />
            <img className="plus-icon5" alt="" src="/plus1.svg" />
            <div className="div28">1</div>
            <img className="vector-icon9" alt="" src="/vector5.svg" />
          </div>
          <img className="image-5-icon2" alt="" src="/image41@2x.png" />
          <img className="icon-trash6" alt="" src="/icontrash1.svg" />
        </div>
      </div>
    </div>
  );
};

export default CustomerOrderCart;
