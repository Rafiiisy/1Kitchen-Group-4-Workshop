import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./CustomerRestoBurgerKing.css";

const CustomerRestoBurgerKing: FunctionComponent = () => {
  const navigate = useNavigate();

  const onSearchButtonClick = useCallback(() => {
    navigate("/customersearch");
  }, [navigate]);

  const onAccountButtonClick = useCallback(() => {
    navigate("/menu-customer");
  }, [navigate]);

  return (
    <div className="customer-resto-burger-king">
      <img
        className="pexels-photo-by-valeria-boltne"
        alt=""
        src="/pexels-photo-by-valeria-boltneva@2x.png"
      />
      <div className="rectangle-4394" />
      <img className="k-colour-1-icon" alt="" src="/1kcolour1@2x.png" />
      <b className="b">4.5</b>
      <div className="ratings">560 ratings</div>
      <b className="b1">$$$</b>
      <div className="div">$15 - $45</div>
      <div className="liked-by">Liked by</div>
      <b className="k">435K</b>
      <img className="heart-icon" alt="" src="/hearticon.svg" />
      <b className="burger-king">Burger King</b>
      <div className="menu">Menu</div>
      <div className="line-1" />
      <div className="rectangle-4414-parent">
        <div className="rectangle-4414" />
        <img className="mask-group-icon" alt="" src="/maskgroup@2x.png" />
        <b className="burger-1">Burger 1</b>
        <b className="b2">$20</b>
      </div>
      <div className="rectangle-4414-group">
        <div className="rectangle-4414" />
        <img className="mask-group-icon" alt="" src="/maskgroup@2x.png" />
        <b className="burger-2">Burger 2</b>
        <b className="b2">$20</b>
      </div>
      <div className="rectangle-4414-container">
        <div className="rectangle-4414" />
        <img className="mask-group-icon" alt="" src="/maskgroup@2x.png" />
        <b className="burger-2">Burger 5</b>
        <b className="b2">$20</b>
      </div>
      <div className="group-div">
        <div className="rectangle-4414" />
        <img className="mask-group-icon" alt="" src="/maskgroup@2x.png" />
        <b className="burger-2">Burger 6</b>
        <b className="b2">$20</b>
      </div>
      <div className="rectangle-4414-parent1">
        <div className="rectangle-4414" />
        <img className="mask-group-icon" alt="" src="/maskgroup@2x.png" />
        <b className="burger-2">Burger 3</b>
        <b className="b2">$20</b>
      </div>
      <div className="rectangle-4414-parent2">
        <div className="rectangle-4414" />
        <img className="mask-group-icon" alt="" src="/maskgroup@2x.png" />
        <b className="burger-2">Burger 4</b>
        <b className="b2">$20</b>
      </div>
      <footer className="footer">
        <button className="home-button">
          <img className="vector-home-icon" alt="" src="/vectorhome1.svg" />
          <div className="home">Home</div>
        </button>
        <button className="search-button" onClick={onSearchButtonClick}>
          <div className="frame-82">
            <img className="searchvector-icon" alt="" src="/searchvector.svg" />
            <div className="explore">Explore</div>
          </div>
        </button>
        <div className="orders-button">
          <img className="vector-clock-icon" alt="" src="/vectorclock1.svg" />
          <div className="orders">Orders</div>
        </div>
        <button className="account-button" onClick={onAccountButtonClick}>
          <img className="vector-user-icon" alt="" src="/vectoruser.svg" />
          <div className="account">Account</div>
        </button>
      </footer>
    </div>
  );
};

export default CustomerRestoBurgerKing;
