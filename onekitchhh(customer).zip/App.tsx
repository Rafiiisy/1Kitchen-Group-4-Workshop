const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";

import Splashscreen from "./screens/Splashscreen";
import LoginSuccess from "./screens/LoginSuccess";
import Login from "./screens/Login";
import LoginSelect from "./screens/LoginSelect";
import LogInNope from "./screens/LogInNope";
import CustomerRestoBurgerKing from "./screens/CustomerRestoBurgerKing";
import CustomerRestoSushiTei from "./screens/CustomerRestoSushiTei";
import SuccessLogIn from "./screens/SuccessLogIn";
import CustomerSearchCategory2 from "./screens/CustomerSearchCategory2";
import CustomerSearchCategory1 from "./screens/CustomerSearchCategory1";
import SuccessSignUp from "./screens/SuccessSignUp";
import SuccessCustomer from "./screens/SuccessCustomer";
import CustomerProfileEditProfile from "./screens/CustomerProfileEditProfile";
import CustomerOrder1 from "./screens/CustomerOrder1";
import CustomerOrderMain from "./screens/CustomerOrderMain";
import CustomerHome from "./screens/CustomerHome";
import CustomerSearch from "./screens/CustomerSearch";
import CustomerOrderSuccession from "./screens/CustomerOrderSuccession";
import Login1 from "./screens/Login1";
import SignUp from "./screens/SignUp";
import SignUp2 from "./screens/SignUp2";
import SplashScreenintroonce from "./screens/SplashScreenintroonce";
import CustomerProfileFeedback from "./screens/CustomerProfileFeedback";
import CustomerProfile from "./screens/CustomerProfile";
import CustomerHomeCategory2 from "./screens/CustomerHomeCategory2";
import CustomerHomeCategory3 from "./screens/CustomerHomeCategory3";
import CustomerOrderCart from "./screens/CustomerOrderCart";
import CustomerHomeCategory1 from "./screens/CustomerHomeCategory1";
import LogInSelection from "./screens/LogInSelection";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen
              name="Splashscreen"
              component={Splashscreen}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="LoginSuccess"
              component={LoginSuccess}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Login"
              component={Login}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="LoginSelect"
              component={LoginSelect}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="LogInNope"
              component={LogInNope}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerRestoBurgerKing"
              component={CustomerRestoBurgerKing}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerRestoSushiTei"
              component={CustomerRestoSushiTei}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SuccessLogIn"
              component={SuccessLogIn}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerSearchCategory2"
              component={CustomerSearchCategory2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerSearchCategory1"
              component={CustomerSearchCategory1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SuccessSignUp"
              component={SuccessSignUp}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SuccessCustomer"
              component={SuccessCustomer}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerProfileEditProfile"
              component={CustomerProfileEditProfile}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerOrder1"
              component={CustomerOrder1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerOrderMain"
              component={CustomerOrderMain}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerHome"
              component={CustomerHome}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerSearch"
              component={CustomerSearch}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerOrderSuccession"
              component={CustomerOrderSuccession}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Login1"
              component={Login1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SignUp"
              component={SignUp}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SignUp2"
              component={SignUp2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SplashScreenintroonce"
              component={SplashScreenintroonce}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerProfileFeedback"
              component={CustomerProfileFeedback}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerProfile"
              component={CustomerProfile}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerHomeCategory2"
              component={CustomerHomeCategory2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerHomeCategory3"
              component={CustomerHomeCategory3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerOrderCart"
              component={CustomerOrderCart}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CustomerHomeCategory1"
              component={CustomerHomeCategory1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="LogInSelection"
              component={LogInSelection}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;
