import * as React from "react";
import { Image, StyleSheet, Text, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Border } from "../GlobalStyles";

const Login1 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.login}>
      <View style={styles.frame37450}>
        <Image
          style={styles.kColour1Icon}
          resizeMode="cover"
          source={require("../assets/1kcolour1.png")}
        />
        <Text style={[styles.welcomeBack, styles.logTypo]}>Welcome Back!</Text>
        <Text style={[styles.logInTo, styles.logTypo]}>
          Log in to your account
        </Text>
      </View>
      <View style={styles.frame37453Parent}>
        <View style={[styles.frame37453, styles.frameLayout1]}>
          <View style={[styles.rectangle4401, styles.rectangleBorder]} />
          <Text style={[styles.enterYourPassword, styles.enterTypo]}>
            Enter your password
          </Text>
        </View>
        <Text style={[styles.passwordComponentinputPass, styles.orTypo]}>
          Password
        </Text>
        <View style={styles.frame37451}>
          <Text style={[styles.emailOrPhone, styles.orTypo]}>{`Email `}</Text>
          <View style={[styles.frame37452, styles.frameLayout1]}>
            <View style={[styles.rectangle4401, styles.rectangleBorder]} />
            <Text style={[styles.enterYourEmail, styles.enterTypo]}>
              Enter your Email address
            </Text>
          </View>
        </View>
        <View style={[styles.frame37455, styles.frameLayout]}>
          <View style={[styles.rectangle44001, styles.rectangleLayout]} />
          <Text style={[styles.logInWith, styles.signUp1Typo]}>
            Log in with your Google Account
          </Text>
          <Image
            style={styles.image1Icon}
            resizeMode="cover"
            source={require("../assets/image11.png")}
          />
        </View>
        <Text style={[styles.or, styles.orTypo]}>OR</Text>
        <Text
          style={[styles.dontHaveAn, styles.signUpPosition]}
        >{`Don’t have an account? `}</Text>
        <Pressable
          style={[styles.signUp, styles.signUpPosition]}
          onPress={() => navigation.navigate("SignUp")}
        >
          <Text style={[styles.signUp1, styles.signUp1Typo]}>Sign up</Text>
        </Pressable>
        <Pressable
          style={[styles.frame37454, styles.frameLayout]}
          onPress={() => navigation.navigate("SuccessLogIn")}
        >
          <View style={[styles.rectangle44002, styles.rectangleLayout]} />
          <Text style={[styles.logIn, styles.logTypo]}>Log In</Text>
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  logTypo: {
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  frameLayout1: {
    height: 48,
    width: 304,
    position: "absolute",
  },
  rectangleBorder: {
    borderWidth: 2,
    borderStyle: "solid",
    backgroundColor: Color.gray_200,
  },
  enterTypo: {
    color: Color.gray_400,
    fontFamily: FontFamily.nunitoRegular,
    fontSize: FontSize.size_sm,
    textAlign: "center",
    position: "absolute",
  },
  orTypo: {
    color: Color.kLightGreen,
    fontSize: FontSize.size_base,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  frameLayout: {
    height: 44,
    width: 280,
    left: 23,
    position: "absolute",
  },
  rectangleLayout: {
    borderRadius: Border.br_3xs,
    height: 44,
    width: 280,
    left: 0,
    top: 0,
    position: "absolute",
  },
  signUp1Typo: {
    fontSize: FontSize.size_sm,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
  },
  signUpPosition: {
    top: 377,
    position: "absolute",
  },
  kColour1Icon: {
    left: 85,
    width: 75,
    height: 67,
    top: 0,
    position: "absolute",
  },
  welcomeBack: {
    top: 109,
    left: 22,
    fontSize: FontSize.title1Bold28_size,
    color: Color.globalBlack,
  },
  logInTo: {
    top: 147,
    fontSize: FontSize.size_5xl,
    left: 0,
    color: Color.globalBlack,
  },
  frame37450: {
    top: 44,
    left: 57,
    width: 247,
    height: 180,
    position: "absolute",
  },
  rectangle4401: {
    borderRadius: Border.br_8xs,
    borderColor: "#0d7a42",
    height: 48,
    width: 304,
    position: "absolute",
    left: 0,
    top: 0,
  },
  enterYourPassword: {
    top: 15,
    left: 11,
  },
  frame37453: {
    top: 135,
    left: 11,
  },
  passwordComponentinputPass: {
    top: 113,
    left: 11,
  },
  emailOrPhone: {
    left: 1,
    top: 0,
  },
  enterYourEmail: {
    top: 16,
    left: 10,
  },
  frame37452: {
    top: 22,
    left: 0,
  },
  frame37451: {
    top: 19,
    height: 70,
    width: 304,
    left: 11,
    position: "absolute",
  },
  rectangle44001: {
    borderColor: "#1a6733",
    borderWidth: 2,
    borderStyle: "solid",
    backgroundColor: Color.gray_200,
  },
  logInWith: {
    top: 3,
    left: 35,
    color: Color.gray_500,
    width: 209,
    height: 19,
    position: "absolute",
  },
  image1Icon: {
    top: 8,
    left: 8,
    width: 30,
    height: 29,
    position: "absolute",
  },
  frame37455: {
    top: 313,
  },
  or: {
    top: 283,
    left: 151,
  },
  dontHaveAn: {
    left: 54,
    fontSize: FontSize.size_sm,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    color: Color.globalBlack,
  },
  signUp1: {
    color: Color.kDarkGreen,
  },
  signUp: {
    left: 211,
  },
  rectangle44002: {
    backgroundColor: Color.kDarkGreen,
  },
  logIn: {
    top: 7,
    left: 106,
    fontSize: FontSize.size_xl,
    color: Color.kitchenBG,
    width: 69,
    height: 30,
  },
  frame37454: {
    top: 231,
  },
  frame37453Parent: {
    top: 240,
    left: 17,
    width: 327,
    height: 413,
    position: "absolute",
    overflow: "hidden",
  },
  login: {
    backgroundColor: Color.kitchenBG,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default Login1;
