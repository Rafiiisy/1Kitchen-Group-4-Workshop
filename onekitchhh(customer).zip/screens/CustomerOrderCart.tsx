import * as React from "react";
import { Text, StyleSheet, Image, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Border, Color } from "../GlobalStyles";

const CustomerOrderCart = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.customerOrderCart}>
      <View style={[styles.frame72containertopBar, styles.group37401Layout]}>
        <Pressable
          style={[styles.group37401, styles.group37401Layout]}
          onPress={() => navigation.navigate("CustomerOrder1")}
        >
          <Text style={styles.cart}>Cart</Text>
          <Image
            style={styles.vectorIcon}
            resizeMode="cover"
            source={require("../assets/vector4.png")}
          />
          <Image
            style={[styles.image2Icon, styles.group37401Layout]}
            resizeMode="cover"
            source={require("../assets/image21.png")}
          />
        </Pressable>
      </View>
      <View style={styles.frame71container}>
        <Text style={[styles.rp16850000, styles.totalTypo]}>
          Rp. 168.500.00
        </Text>
        <Text style={[styles.total, styles.totalTypo]}>Total</Text>
        <Pressable
          style={styles.orangeCheckoutButton}
          onPress={() => navigation.navigate("CustomerOrderSuccession")}
        >
          <View style={styles.rectangle8} />
          <Text style={styles.checkout}>Checkout</Text>
        </Pressable>
      </View>
      <View style={styles.frame53container}>
        <View style={[styles.group37412, styles.groupLayout]}>
          <View style={[styles.rectangle12, styles.rectangleLayout]} />
          <Text style={styles.whopperComboM}>Whopper Combo M..</Text>
          <Text style={styles.rp4750000}>Rp. 47.500,00</Text>
          <View style={styles.numberOfBoogers}>
            <View style={styles.rectangle10} />
            <Image
              style={[styles.plusIcon, styles.iconLayout4]}
              resizeMode="cover"
              source={require("../assets/plus1.png")}
            />
            <Text style={styles.text}>1</Text>
            <Image
              style={[styles.vectorIcon1, styles.iconLayout4]}
              resizeMode="cover"
              source={require("../assets/vector5.png")}
            />
          </View>
          <Image
            style={styles.image4Icon}
            resizeMode="cover"
            source={require("../assets/image41.png")}
          />
          <Image
            style={styles.iconTrash}
            resizeMode="cover"
            source={require("../assets/icontrash.png")}
          />
        </View>
        <View style={[styles.group37411, styles.groupLayout]}>
          <View style={[styles.rectangle12, styles.rectangleLayout]} />
          <Text style={[styles.btsMeal, styles.whopperTypo]}>BTS Meal</Text>
          <Text style={[styles.rp9050000, styles.rp9050000Typo]}>
            Rp. 90.500,00
          </Text>
          <View style={[styles.numberOfBoogers1, styles.numberPosition]}>
            <View style={styles.rectangle10} />
            <Image
              style={[styles.plusIcon, styles.iconLayout4]}
              resizeMode="cover"
              source={require("../assets/plus1.png")}
            />
            <Text style={styles.text}>2</Text>
            <Image
              style={[styles.vectorIcon1, styles.iconLayout4]}
              resizeMode="cover"
              source={require("../assets/vector5.png")}
            />
          </View>
          <Image
            style={[styles.image3Icon, styles.iconLayout3]}
            resizeMode="cover"
            source={require("../assets/image31.png")}
          />
          <Image
            style={[styles.iconTrash1, styles.iconLayout2]}
            resizeMode="cover"
            source={require("../assets/icontrash.png")}
          />
        </View>
        <View style={[styles.group37410, styles.groupLayout]}>
          <View style={[styles.rectangle12, styles.rectangleLayout]} />
          <Image
            style={[styles.iconTrash1, styles.iconLayout2]}
            resizeMode="cover"
            source={require("../assets/icontrash.png")}
          />
          <Text style={[styles.popeyesChickenSa, styles.whopperTypo]}>
            Popeye’s Chicken Sa...
          </Text>
          <Text style={[styles.rp47500001, styles.rp9050000Typo]}>
            Rp. 47.500,00
          </Text>
          <View style={[styles.numberOfBoogers2, styles.numberPosition]}>
            <View style={styles.rectangle10} />
            <Image
              style={[styles.plusIcon, styles.iconLayout4]}
              resizeMode="cover"
              source={require("../assets/plus1.png")}
            />
            <Text style={styles.text}>1</Text>
            <Image
              style={[styles.vectorIcon1, styles.iconLayout4]}
              resizeMode="cover"
              source={require("../assets/vector5.png")}
            />
          </View>
          <Image
            style={[styles.image5Icon, styles.iconLayout3]}
            resizeMode="cover"
            source={require("../assets/image41.png")}
          />
        </View>
        <View style={[styles.rectangle15, styles.rectangleLayout]} />
        <Text style={[styles.whopperComboM1, styles.whopperTypo]}>
          Whopper Combo M..
        </Text>
        <Text style={[styles.rp47500002, styles.rp9050000Typo]}>
          Rp. 47.500,00
        </Text>
        <View style={[styles.numberOfBoogers3, styles.numberPosition]}>
          <View style={styles.rectangle10} />
          <Image
            style={[styles.plusIcon, styles.iconLayout4]}
            resizeMode="cover"
            source={require("../assets/plus1.png")}
          />
          <Text style={styles.text}>1</Text>
          <Image
            style={[styles.vectorIcon1, styles.iconLayout4]}
            resizeMode="cover"
            source={require("../assets/vector5.png")}
          />
        </View>
        <Image
          style={[styles.image4Icon1, styles.iconLayout3]}
          resizeMode="cover"
          source={require("../assets/image41.png")}
        />
        <Image
          style={[styles.iconTrash3, styles.iconLayout1]}
          resizeMode="cover"
          source={require("../assets/icontrash1.png")}
        />
        <Image
          style={[styles.iconTrash4, styles.iconLayout1]}
          resizeMode="cover"
          source={require("../assets/icontrash.png")}
        />
        <View style={[styles.group37414, styles.groupLayout]}>
          <View style={[styles.rectangle12, styles.rectangleLayout]} />
          <Text style={[styles.whopperComboM2, styles.whopperTypo]}>
            Whopper Combo M..
          </Text>
          <Text style={[styles.rp47500003, styles.rp9050000Typo]}>
            Rp. 47.500,00
          </Text>
          <View style={[styles.numberOfBoogers4, styles.numberPosition]}>
            <View style={styles.rectangle10} />
            <Image
              style={[styles.plusIcon4, styles.iconLayout]}
              resizeMode="cover"
              source={require("../assets/plus1.png")}
            />
            <Text style={styles.text}>1</Text>
            <Image
              style={[styles.vectorIcon5, styles.iconLayout]}
              resizeMode="cover"
              source={require("../assets/vector5.png")}
            />
          </View>
          <Image
            style={[styles.image3Icon, styles.iconLayout3]}
            resizeMode="cover"
            source={require("../assets/image41.png")}
          />
          <Image
            style={[styles.iconTrash1, styles.iconLayout2]}
            resizeMode="cover"
            source={require("../assets/icontrash1.png")}
          />
        </View>
        <View style={[styles.group37413, styles.groupLayout]}>
          <View style={[styles.rectangle12, styles.rectangleLayout]} />
          <Text style={[styles.whopperComboM2, styles.whopperTypo]}>
            Whopper Combo M..
          </Text>
          <Text style={[styles.rp47500003, styles.rp9050000Typo]}>
            Rp. 47.500,00
          </Text>
          <View style={[styles.numberOfBoogers4, styles.numberPosition]}>
            <View style={styles.rectangle10} />
            <Image
              style={[styles.plusIcon4, styles.iconLayout]}
              resizeMode="cover"
              source={require("../assets/plus1.png")}
            />
            <Text style={styles.text}>1</Text>
            <Image
              style={[styles.vectorIcon5, styles.iconLayout]}
              resizeMode="cover"
              source={require("../assets/vector5.png")}
            />
          </View>
          <Image
            style={[styles.image5Icon2, styles.iconLayout3]}
            resizeMode="cover"
            source={require("../assets/image41.png")}
          />
          <Image
            style={[styles.iconTrash6, styles.iconLayout2]}
            resizeMode="cover"
            source={require("../assets/icontrash1.png")}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  group37401Layout: {
    height: 60,
    position: "absolute",
  },
  totalTypo: {
    fontSize: FontSize.size_xl,
    textAlign: "left",
    fontFamily: FontFamily.nunitoSemibold,
    fontWeight: "600",
    top: 0,
    position: "absolute",
  },
  groupLayout: {
    height: 111,
    width: 303,
    left: 0,
    position: "absolute",
  },
  rectangleLayout: {
    borderRadius: Border.br_8xl,
    height: 111,
    width: 303,
    backgroundColor: Color.gray_100,
    left: 0,
    position: "absolute",
  },
  iconLayout4: {
    width: "12.52%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  whopperTypo: {
    left: "34.32%",
    color: Color.globalBlack,
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.nunitoMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  rp9050000Typo: {
    left: 104,
    fontSize: FontSize.caption1Regular12_size,
    textAlign: "center",
    color: Color.seagreen_100,
    fontFamily: FontFamily.nunitoMedium,
    fontWeight: "500",
    position: "absolute",
  },
  numberPosition: {
    left: "66.34%",
    right: "17.15%",
    width: "16.52%",
    position: "absolute",
  },
  iconLayout3: {
    left: 18,
    height: 75,
    width: 75,
    borderRadius: Border.br_980xl,
    position: "absolute",
  },
  iconLayout2: {
    left: "88.12%",
    right: "6.19%",
    width: "5.69%",
    height: "17.12%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  iconLayout1: {
    height: "3.74%",
    left: "88.12%",
    right: "6.19%",
    width: "5.69%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  iconLayout: {
    width: "10.53%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  cart: {
    top: 8,
    left: 41,
    fontSize: FontSize.size_13xl,
    textAlign: "left",
    fontFamily: FontFamily.nunitoSemibold,
    fontWeight: "600",
    color: Color.globalWhite,
    position: "absolute",
  },
  vectorIcon: {
    height: "27.14%",
    width: "3.43%",
    top: "36.67%",
    right: "96.89%",
    bottom: "36.19%",
    left: "-0.32%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  image2Icon: {
    left: 252,
    borderRadius: 1000000000,
    width: 60,
    top: 0,
  },
  group37401: {
    left: 0,
    top: 0,
    width: 312,
    height: 60,
  },
  frame72containertopBar: {
    top: 16,
    left: 24,
    width: 312,
    height: 60,
  },
  rp16850000: {
    left: 151,
    color: Color.globalWhite,
    fontSize: FontSize.size_xl,
  },
  total: {
    color: Color.gray_100,
    left: 0,
  },
  rectangle8: {
    borderRadius: 22,
    backgroundColor: Color.gray_100,
    height: 47,
    width: 214,
    left: 0,
    top: 0,
    position: "absolute",
  },
  checkout: {
    top: 10,
    left: 64,
    width: 85,
    textAlign: "center",
    color: Color.seagreen_100,
    fontFamily: FontFamily.nunitoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  orangeCheckoutButton: {
    top: 57,
    left: 33,
    height: 47,
    width: 214,
    position: "absolute",
  },
  frame71container: {
    top: 634,
    left: 40,
    width: 292,
    height: 104,
    position: "absolute",
  },
  rectangle12: {
    top: 0,
  },
  whopperComboM: {
    top: "28.83%",
    left: "33.66%",
    color: Color.globalBlack,
    fontSize: FontSize.size_base,
    width: "52.15%",
    height: "18.02%",
    fontFamily: FontFamily.nunitoMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  rp4750000: {
    top: 59,
    left: 102,
    fontSize: FontSize.caption1Regular12_size,
    textAlign: "center",
    color: Color.seagreen_100,
    fontFamily: FontFamily.nunitoMedium,
    fontWeight: "500",
    position: "absolute",
  },
  rectangle10: {
    height: "90.91%",
    top: "4.55%",
    right: "0%",
    bottom: "4.55%",
    left: "0%",
    backgroundColor: Color.seagreen_100,
    borderRadius: Border.br_980xl,
    position: "absolute",
    width: "100%",
  },
  plusIcon: {
    height: "26.36%",
    top: "38.64%",
    right: "13.04%",
    bottom: "35%",
    left: "74.44%",
  },
  text: {
    left: 20,
    fontFamily: FontFamily.nunitoRegular,
    fontSize: FontSize.size_base,
    textAlign: "center",
    color: Color.globalWhite,
    top: 0,
    position: "absolute",
  },
  vectorIcon1: {
    height: "4.55%",
    top: "47.73%",
    right: "76.19%",
    bottom: "47.73%",
    left: "11.28%",
  },
  numberOfBoogers: {
    top: "50.45%",
    right: "17.81%",
    bottom: "29.73%",
    left: "65.68%",
    width: "16.52%",
    height: "19.82%",
    position: "absolute",
  },
  image4Icon: {
    left: 16,
    height: 75,
    width: 75,
    top: 18,
    borderRadius: Border.br_980xl,
    position: "absolute",
  },
  iconTrash: {
    top: "11.71%",
    right: "6.85%",
    bottom: "71.17%",
    left: "87.46%",
    width: "5.69%",
    height: "17.12%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  group37412: {
    top: 0,
  },
  btsMeal: {
    top: "32.43%",
    width: "52.15%",
    left: "34.32%",
    height: "18.02%",
  },
  rp9050000: {
    top: 63,
  },
  numberOfBoogers1: {
    top: "54.05%",
    bottom: "26.13%",
    height: "19.82%",
    left: "66.34%",
    right: "17.15%",
  },
  image3Icon: {
    top: 21,
  },
  iconTrash1: {
    top: "14.41%",
    bottom: "68.47%",
  },
  group37411: {
    top: 127,
  },
  popeyesChickenSa: {
    width: "53.8%",
    top: "29.73%",
    height: "18.02%",
  },
  rp47500001: {
    top: 60,
  },
  numberOfBoogers2: {
    top: "51.35%",
    bottom: "28.83%",
    height: "19.82%",
    left: "66.34%",
    right: "17.15%",
  },
  image5Icon: {
    top: 18,
    left: 18,
  },
  group37410: {
    top: 254,
  },
  rectangle15: {
    top: 381,
  },
  whopperComboM1: {
    height: "3.94%",
    top: "81.89%",
    width: "52.15%",
    left: "34.32%",
  },
  rp47500002: {
    top: 443,
  },
  numberOfBoogers3: {
    height: "4.33%",
    top: "86.61%",
    bottom: "9.06%",
  },
  image4Icon1: {
    top: 402,
  },
  iconTrash3: {
    top: "78.15%",
    bottom: "18.11%",
  },
  iconTrash4: {
    top: "28.15%",
    bottom: "68.11%",
  },
  whopperComboM2: {
    top: "31.53%",
    width: "52.15%",
    left: "34.32%",
    height: "18.02%",
  },
  rp47500003: {
    top: 62,
  },
  plusIcon4: {
    height: "21.82%",
    top: "40.91%",
    right: "14.04%",
    bottom: "37.27%",
    left: "75.44%",
    maxHeight: "100%",
  },
  vectorIcon5: {
    top: "50%",
    right: "77.19%",
    left: "12.28%",
    height: 0,
  },
  numberOfBoogers4: {
    top: "53.15%",
    bottom: "27.03%",
    height: "19.82%",
    left: "66.34%",
    right: "17.15%",
  },
  group37414: {
    top: 635,
  },
  image5Icon2: {
    top: 529,
  },
  iconTrash6: {
    top: "472.07%",
    bottom: "-389.19%",
  },
  group37413: {
    top: 508,
  },
  frame53container: {
    top: 108,
    left: 28,
    height: 508,
    width: 303,
    position: "absolute",
  },
  customerOrderCart: {
    backgroundColor: Color.mediumseagreen_200,
    flex: 1,
    height: 800,
    width: "100%",
  },
});

export default CustomerOrderCart;
