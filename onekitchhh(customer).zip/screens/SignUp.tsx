import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const SignUp = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.signUp}>
      <View style={[styles.frame23ContainerTopBar, styles.rectanglePosition]}>
        <Text style={[styles.welcome, styles.mailFlexBox]}>Welcome!</Text>
        <Text style={styles.weWantTo}>We want to know about you</Text>
      </View>
      <View style={[styles.nameComponentinputNameParent, styles.namePosition1]}>
        <Text style={[styles.nameComponentinputName, styles.nameTypo]}>
          Name
        </Text>
        <View style={[styles.frame37456, styles.frameLayout]}>
          <View style={[styles.rectangle4400, styles.frameLayout]} />
          <Text style={[styles.enterYourFull, styles.enterTypo]}>
            Enter your Full Name
          </Text>
        </View>
        <Text style={[styles.eMailComponentinputEmail, styles.nameTypo]}>
          E-mail
        </Text>
        <View style={[styles.frame37457, styles.frameLayout]}>
          <View style={[styles.rectangle4400, styles.frameLayout]} />
          <Text style={[styles.enterYourFull, styles.enterTypo]}>
            Enter your Email address
          </Text>
        </View>
        <Text style={[styles.eMailComponentinputEmail1, styles.emailPosition]}>
          Roles
        </Text>
        <View style={[styles.frame37458, styles.frameLayout]}>
          <View style={[styles.rectangle4400, styles.frameLayout]} />
          <Text style={[styles.enterYourEmail1, styles.emailPosition]}>
            Select your roles
          </Text>
        </View>
        <Text style={[styles.eMailComponentinputEmail2, styles.nameTypo]}>
          Password
        </Text>
        <View style={[styles.frame37459, styles.frameLayout]}>
          <View style={[styles.group37302, styles.frameLayout]}>
            <View style={[styles.rectangle4400, styles.frameLayout]} />
            <Text style={[styles.enterYourFull, styles.enterTypo]}>
              Enter your Password
            </Text>
          </View>
        </View>
        <Text style={[styles.eMailComponentinputEmail3, styles.nameTypo]}>
          Password Confirmation
        </Text>
        <View style={[styles.frame37460, styles.frameLayout]}>
          <View style={[styles.group37302, styles.frameLayout]}>
            <View style={[styles.rectangle4400, styles.frameLayout]} />
            <Text style={[styles.enterYourFull, styles.enterTypo]}>
              Enter your Password
            </Text>
          </View>
        </View>
        <Pressable
          style={[styles.frame37461, styles.frame37461Layout]}
          onPress={() => navigation.navigate("SignUp2")}
        >
          <View style={[styles.rectangle44005, styles.frame37461Layout]} />
          <Text style={[styles.next, styles.mailFlexBox]}>Next</Text>
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  rectanglePosition: {
    left: 0,
    top: 0,
  },
  mailFlexBox: {
    textAlign: "center",
    position: "absolute",
  },
  namePosition1: {
    position: "absolute",
    overflow: "hidden",
  },
  nameTypo: {
    color: Color.kLightGreen,
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
  },
  frameLayout: {
    height: 44,
    width: 304,
    position: "absolute",
  },
  enterTypo: {
    color: Color.gray_400,
    fontFamily: FontFamily.nunitoRegular,
    fontSize: FontSize.size_sm,
  },
  emailPosition: {
    left: 9,
    textAlign: "center",
    position: "absolute",
  },
  frame37461Layout: {
    width: 280,
    height: 44,
    position: "absolute",
  },
  welcome: {
    top: 64,
    left: 96,
    fontSize: FontSize.size_17xl,
    color: Color.globalBlack,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
  },
  weWantTo: {
    top: 117,
    left: 78,
    fontWeight: "500",
    fontFamily: FontFamily.nunitoMedium,
    fontSize: FontSize.size_base,
    textAlign: "center",
    color: Color.globalBlack,
    position: "absolute",
  },
  frame23ContainerTopBar: {
    width: 360,
    height: 139,
    position: "absolute",
    overflow: "hidden",
  },
  nameComponentinputName: {
    top: 5,
    left: 6,
    textAlign: "center",
    position: "absolute",
  },
  rectangle4400: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.gray_200,
    borderStyle: "solid",
    borderColor: "#0d7a42",
    borderWidth: 2,
    left: 0,
    top: 0,
  },
  enterYourFull: {
    top: 12,
    left: 6,
    textAlign: "center",
    position: "absolute",
  },
  frame37456: {
    top: 27,
    left: 5,
  },
  eMailComponentinputEmail: {
    top: 78,
    left: 6,
    textAlign: "center",
    position: "absolute",
  },
  frame37457: {
    top: 100,
    left: 5,
  },
  eMailComponentinputEmail1: {
    top: 151,
    color: Color.kLightGreen,
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
  },
  enterYourEmail1: {
    top: 14,
    color: Color.gray_400,
    fontFamily: FontFamily.nunitoRegular,
    fontSize: FontSize.size_sm,
  },
  frame37458: {
    top: 173,
    left: 5,
  },
  eMailComponentinputEmail2: {
    top: 224,
    left: 5,
    textAlign: "center",
    position: "absolute",
  },
  group37302: {
    left: 0,
    top: 0,
  },
  frame37459: {
    top: 246,
    left: 5,
  },
  eMailComponentinputEmail3: {
    top: 304,
    left: 5,
    textAlign: "center",
    position: "absolute",
  },
  frame37460: {
    top: 326,
    left: 5,
  },
  rectangle44005: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.kDarkGreen,
    left: 0,
    top: 0,
  },
  next: {
    top: 7,
    left: 100,
    fontSize: FontSize.size_xl,
    color: Color.kitchenBG,
    width: 79,
    height: 30,
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    textAlign: "center",
  },
  frame37461: {
    top: 389,
    left: 18,
  },
  nameComponentinputNameParent: {
    top: 160,
    left: 22,
    width: 321,
    height: 449,
  },
  signUp: {
    backgroundColor: Color.kitchenBG,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default SignUp;
