import * as React from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import { FontFamily, FontSize, Color } from "../GlobalStyles";

const LoginSuccess = () => {
  return (
    <View style={styles.loginSuccess}>
      <Image
        style={styles.asset11Icon}
        resizeMode="cover"
        source={require("../assets/asset11.png")}
      />
      <Text style={[styles.success, styles.successTypo]}>Success!</Text>
      <Text
        style={[styles.youSuccessfullyLogged, styles.successTypo]}
      >{`You successfully logged in to your account! `}</Text>
      <View style={styles.frame37466}>
        <Text style={[styles.continueToLog, styles.continueTypo]}>
          Continue to
        </Text>
        <Text style={[styles.continueToLog1, styles.continueTypo]}>Home</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  successTypo: {
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  continueTypo: {
    textAlign: "left",
    fontSize: FontSize.size_xl,
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
  },
  asset11Icon: {
    top: 231,
    left: 92,
    width: 175,
    height: 175,
    position: "absolute",
    overflow: "hidden",
  },
  success: {
    top: 64,
    left: 109,
    fontSize: FontSize.size_17xl,
    color: Color.globalBlack,
  },
  youSuccessfullyLogged: {
    top: 117,
    left: 21,
    fontSize: FontSize.size_base,
    color: Color.kDarkGreen,
  },
  continueToLog: {
    color: Color.globalBlack,
  },
  continueToLog1: {
    color: Color.seagreen_100,
    marginLeft: 8,
  },
  frame37466: {
    top: 450,
    left: 94,
    flexDirection: "row",
    position: "absolute",
  },
  loginSuccess: {
    backgroundColor: Color.gray_300,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default LoginSuccess;
