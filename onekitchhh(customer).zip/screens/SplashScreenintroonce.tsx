import * as React from "react";
import { Image, StyleSheet, Text, View, Pressable } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const SplashScreenintroonce = () => {
  const navigation = useNavigation();

  return (
    <LinearGradient
      style={styles.splashScreenintroonce}
      locations={[0.4, 1]}
      colors={["#229c57", "#efffec"]}
      useAngle={true}
      angle={180}
    >
      <Pressable
        style={styles.frame37441}
        onPress={() => navigation.navigate("Login1")}
      >
        <Image
          style={styles.kWhite1Icon}
          resizeMode="cover"
          source={require("../assets/1kwhite1.png")}
        />
        <Text style={styles.oneKitchen}>One Kitchen</Text>
      </Pressable>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  kWhite1Icon: {
    width: 250,
    height: 222,
  },
  oneKitchen: {
    fontSize: FontSize.size_21xl,
    fontWeight: "700",
    fontFamily: FontFamily.nunitoBold,
    color: Color.globalWhite,
    textAlign: "left",
    marginTop: 33,
  },
  frame37441: {
    position: "absolute",
    top: 245,
    left: 55,
    alignItems: "center",
  },
  splashScreenintroonce: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
    backgroundColor: "transparent",
  },
});

export default SplashScreenintroonce;
