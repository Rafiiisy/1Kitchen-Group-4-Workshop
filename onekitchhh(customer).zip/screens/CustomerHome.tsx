import * as React from "react";
import { Image, StyleSheet, View, Text, Pressable } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import FooterContainer from "../components/FooterContainer";
import { FontSize, Border, Color, FontFamily, Padding } from "../GlobalStyles";

const CustomerHome = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.customerHome}>
      <View style={[styles.bannersParent, styles.bannersParentLayout]}>
        <View style={[styles.banners, styles.bannersPosition]}>
          <View style={styles.carouselDots}>
            <Image
              style={styles.carouselIconLayout}
              resizeMode="cover"
              source={require("../assets/carouseldot.png")}
            />
            <Image
              style={[styles.carouselDotIcon1, styles.carouselIconLayout]}
              resizeMode="cover"
              source={require("../assets/carouseldot1.png")}
            />
            <Image
              style={[styles.carouselDotIcon1, styles.carouselIconLayout]}
              resizeMode="cover"
              source={require("../assets/carouseldot.png")}
            />
          </View>
        </View>
        <View
          style={[styles.frame61container, styles.frame61containerPosition]}
        >
          <Pressable
            style={styles.cardsImage}
            onPress={() => navigation.navigate("CustomerHomeCategory1")}
          >
            <Image
              style={styles.imgBlurIcon}
              resizeMode="cover"
              source={require("../assets/imgblur.png")}
            />
            <Image
              style={[styles.imgIcon, styles.iconPosition]}
              resizeMode="cover"
              source={require("../assets/img5.png")}
            />
            <View style={[styles.text, styles.tagPosition]}>
              <Text style={[styles.title, styles.titleTypo]}>Food</Text>
              <Text style={[styles.subtitle, styles.minLayout]}>
                Order food you love
              </Text>
            </View>
          </Pressable>
          <View style={[styles.cardsImage1, styles.cardsLayout]}>
            <Image
              style={[styles.imgBlurIcon1, styles.imgIconLayout]}
              resizeMode="cover"
              source={require("../assets/imgblur1.png")}
            />
            <Image
              style={[styles.imgIcon, styles.iconPosition]}
              resizeMode="cover"
              source={require("../assets/img6.png")}
            />
            <View style={[styles.text, styles.tagPosition]}>
              <Text style={[styles.title, styles.titleTypo]}>Drinks</Text>
              <Text style={[styles.subtitle, styles.minLayout]}>
                To quench your thirst
              </Text>
            </View>
          </View>
          <View style={[styles.cardsImage2, styles.cardsLayout]}>
            <Image
              style={[styles.imgBlurIcon2, styles.imgIconLayout]}
              resizeMode="cover"
              source={require("../assets/imgblur2.png")}
            />
            <Image
              style={[styles.imgIcon, styles.iconPosition]}
              resizeMode="cover"
              source={require("../assets/img7.png")}
            />
            <View style={[styles.text, styles.tagPosition]}>
              <Text style={[styles.title, styles.titleTypo]}>Deserts</Text>
              <Text style={[styles.subtitle, styles.minLayout]}>
                Something Sweet
              </Text>
            </View>
          </View>
        </View>
        <View
          style={[
            styles.frame54containersliderdefa,
            styles.bannersParentLayout,
          ]}
        >
          <View style={styles.content}>
            <View style={styles.cardsFood}>
              <Pressable
                style={styles.img}
                onPress={() => navigation.navigate("CustomerOrderMain")}
              >
                <Image
                  style={styles.iconPosition}
                  resizeMode="cover"
                  source={require("../assets/image2.png")}
                />
                <View style={[styles.tag, styles.tagFlexBox]}>
                  <Text style={[styles.min, styles.textTypo]}>40 min</Text>
                </View>
                <Image
                  style={styles.buttonIcon}
                  resizeMode="cover"
                  source={require("../assets/buttonicon.png")}
                />
              </Pressable>
              <View style={styles.content1}>
                <View style={styles.cardsFood}>
                  <Text style={[styles.popperoniPizza, styles.textTypo]}>
                    Daily Deli
                  </Text>
                  <Text style={[styles.dailyDeli, styles.fromFlexBox]}>
                    Johar Town
                  </Text>
                </View>
                <View style={styles.ratings}>
                  <Image
                    style={styles.starIcon}
                    resizeMode="cover"
                    source={require("../assets/star1.png")}
                  />
                  <Text style={[styles.text4, styles.textTypo]}>4.8</Text>
                </View>
              </View>
            </View>
            <View style={styles.cardsFood1}>
              <View style={styles.img}>
                <Image
                  style={styles.iconPosition}
                  resizeMode="cover"
                  source={require("../assets/image3.png")}
                />
                <View style={[styles.tag, styles.tagFlexBox]}>
                  <Text style={[styles.min, styles.textTypo]}>12 min</Text>
                </View>
                <Image
                  style={styles.buttonIcon}
                  resizeMode="cover"
                  source={require("../assets/buttonicon.png")}
                />
              </View>
              <View style={styles.content1}>
                <View style={styles.cardsFood}>
                  <Text style={[styles.popperoniPizza, styles.textTypo]}>
                    Rice Bowl
                  </Text>
                  <Text style={[styles.dailyDeli, styles.fromFlexBox]}>
                    Wapda Town
                  </Text>
                </View>
                <View style={styles.ratings}>
                  <Image
                    style={styles.starIcon}
                    resizeMode="cover"
                    source={require("../assets/star1.png")}
                  />
                  <Text style={[styles.text4, styles.textTypo]}>4.8</Text>
                </View>
              </View>
            </View>
          </View>
        </View>
        <View
          style={[styles.frame59container, styles.frame61containerPosition]}
        >
          <View style={styles.title3}>
            <Text style={[styles.deals, styles.textTypo]}>Deals</Text>
            <Image
              style={styles.arrowrightIcon}
              resizeMode="cover"
              source={require("../assets/arrowright.png")}
            />
          </View>
        </View>
        <View
          style={[styles.frame62container, styles.frame61containerPosition]}
        >
          <LinearGradient
            style={styles.banners1}
            locations={[0, 1]}
            colors={["#f2f2f7", "#d4d4e0"]}
            useAngle={true}
            angle={97.19}
          >
            <Image
              style={[styles.saucesIcon, styles.badgePosition]}
              resizeMode="cover"
              source={require("../assets/sauces.png")}
            />
            <Image
              style={styles.pizzaIcon}
              resizeMode="cover"
              source={require("../assets/pizza.png")}
            />
            <Image
              style={[styles.pizzaHutIcon, styles.bannersPosition]}
              resizeMode="cover"
              source={require("../assets/pizzahut.png")}
            />
            <View style={[styles.content3, styles.content3Position]}>
              <View style={styles.text7}>
                <Text style={[styles.pizzaParty, styles.text9Layout]}>
                  Pizza Party
                </Text>
                <Text style={[styles.enjoyPizzaFrom, styles.fromFlexBox]}>
                  Enjoy pizza from Johnny and get upto 30% off
                </Text>
              </View>
              <View style={styles.text8}>
                <Text style={[styles.startingFrom, styles.fromFlexBox]}>
                  Starting from
                </Text>
                <Text style={[styles.text9, styles.text9Layout]}>$10</Text>
              </View>
            </View>
          </LinearGradient>
        </View>
        <View
          style={[styles.frame60container, styles.frame61containerPosition]}
        >
          <View style={styles.exploreMore}>
            <Text style={[styles.popperoniPizza, styles.textTypo]}>
              Explore More
            </Text>
            <View style={styles.frame1}>
              <View style={styles.text7}>
                <View style={styles.img}>
                  <Image
                    style={styles.iconPosition}
                    resizeMode="cover"
                    source={require("../assets/image4.png")}
                  />
                  <View style={[styles.tag, styles.tagFlexBox]}>
                    <Text style={[styles.min, styles.textTypo]}>40 min</Text>
                  </View>
                  <Image
                    style={styles.buttonIcon}
                    resizeMode="cover"
                    source={require("../assets/buttonicon.png")}
                  />
                </View>
                <View style={styles.content1}>
                  <View style={styles.cardsFood}>
                    <Text style={[styles.popperoniPizza, styles.textTypo]}>
                      Jean’s Cakes
                    </Text>
                    <Text style={[styles.dailyDeli, styles.fromFlexBox]}>
                      Johar Town
                    </Text>
                  </View>
                  <View style={styles.ratings}>
                    <Image
                      style={styles.starIcon}
                      resizeMode="cover"
                      source={require("../assets/star1.png")}
                    />
                    <Text style={[styles.text4, styles.textTypo]}>4.8</Text>
                  </View>
                </View>
              </View>
              <View style={styles.text8}>
                <View style={styles.img}>
                  <Image
                    style={styles.iconPosition}
                    resizeMode="cover"
                    source={require("../assets/image5.png")}
                  />
                  <View style={[styles.tag, styles.tagFlexBox]}>
                    <Text style={[styles.min, styles.textTypo]}>20 min</Text>
                  </View>
                  <Image
                    style={styles.buttonIcon}
                    resizeMode="cover"
                    source={require("../assets/buttonicon.png")}
                  />
                </View>
                <View style={styles.content1}>
                  <View style={styles.cardsFood}>
                    <Text style={[styles.popperoniPizza, styles.textTypo]}>
                      Thicc Shakes
                    </Text>
                    <Text style={[styles.dailyDeli, styles.fromFlexBox]}>
                      Wapda Town
                    </Text>
                  </View>
                  <View style={styles.ratings}>
                    <Image
                      style={styles.starIcon}
                      resizeMode="cover"
                      source={require("../assets/star1.png")}
                    />
                    <Text style={[styles.text4, styles.textTypo]}>4.5</Text>
                  </View>
                </View>
              </View>
              <View style={styles.text8}>
                <View style={styles.img}>
                  <Image
                    style={styles.iconPosition}
                    resizeMode="cover"
                    source={require("../assets/image6.png")}
                  />
                  <View style={[styles.tag, styles.tagFlexBox]}>
                    <Text style={[styles.min, styles.textTypo]}>30 min</Text>
                  </View>
                  <Image
                    style={styles.buttonIcon}
                    resizeMode="cover"
                    source={require("../assets/buttonicon.png")}
                  />
                </View>
                <View style={styles.content1}>
                  <View style={styles.cardsFood}>
                    <Text style={[styles.popperoniPizza, styles.textTypo]}>
                      Daily Deli
                    </Text>
                    <Text style={[styles.dailyDeli, styles.fromFlexBox]}>
                      Garden Town
                    </Text>
                  </View>
                  <View style={styles.ratings}>
                    <Image
                      style={styles.starIcon}
                      resizeMode="cover"
                      source={require("../assets/star1.png")}
                    />
                    <Text style={[styles.text4, styles.textTypo]}>4.8</Text>
                  </View>
                </View>
              </View>
            </View>
          </View>
        </View>
      </View>
      <FooterContainer
        propTop={1903}
        onSearchButtonPress={() => navigation.navigate("CustomerSearch")}
      />
      <View style={[styles.homeBarcontainertopBarhid, styles.badgePosition]}>
        <Image
          style={[styles.patternIcon, styles.iconPosition]}
          resizeMode="cover"
          source={require("../assets/pattern.png")}
        />
        <Pressable
          style={[styles.textField, styles.content3Position]}
          onPress={() => navigation.navigate("CustomerSearch")}
        >
          <Image
            style={styles.magnifyingglassIcon}
            resizeMode="cover"
            source={require("../assets/magnifyingglass.png")}
          />
          <Pressable
            style={styles.writeTextHerecomponentiContainer}
            onPress={() => navigation.navigate("CustomerSearch")}
          >
            <Text style={[styles.search, styles.searchTypo]}>Search...</Text>
          </Pressable>
        </Pressable>
        <View style={[styles.location, styles.content3Position]}>
          <Image
            style={styles.magnifyingglassIcon}
            resizeMode="cover"
            source={require("../assets/mappin1.png")}
          />
          <Text style={[styles.blockBPhase, styles.searchTypo]}>
            Block B Phase 2 Johar Town, Lahore
          </Text>
        </View>
      </View>
      <View style={styles.cartButtonLayer}>
        <Image
          style={styles.buttonIcon5}
          resizeMode="cover"
          source={require("../assets/buttonicon1.png")}
        />
        <View style={[styles.badge, styles.badgePosition]}>
          <Text style={[styles.text16, styles.searchTypo]}>4</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  bannersParentLayout: {
    width: 348,
    position: "absolute",
  },
  bannersPosition: {
    left: "50%",
    position: "absolute",
  },
  carouselIconLayout: {
    height: 8,
    width: 8,
  },
  frame61containerPosition: {
    left: 4,
    width: 328,
    position: "absolute",
  },
  iconPosition: {
    left: "0%",
    bottom: "0%",
    right: "0%",
    top: "0%",
    height: "100%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
    width: "100%",
  },
  tagPosition: {
    bottom: 12,
    left: 12,
    position: "absolute",
  },
  titleTypo: {
    lineHeight: 22,
    fontSize: FontSize.bodySemibold17_size,
    textAlign: "left",
    letterSpacing: 0,
  },
  minLayout: {
    lineHeight: 16,
    fontSize: FontSize.caption1Regular12_size,
  },
  cardsLayout: {
    width: 156,
    top: 176,
    height: 160,
    borderRadius: Border.br_base,
    position: "absolute",
  },
  imgIconLayout: {
    width: "125.64%",
    opacity: 0.24,
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    bottom: "-25%",
    top: "-5%",
    height: "130%",
    borderRadius: Border.br_base,
    position: "absolute",
  },
  tagFlexBox: {
    backgroundColor: Color.globalWhite,
    alignItems: "center",
    flexDirection: "row",
  },
  textTypo: {
    fontFamily: FontFamily.bodySemibold17,
    fontWeight: "700",
  },
  fromFlexBox: {
    color: Color.grayGray1,
    textAlign: "left",
    alignSelf: "stretch",
  },
  badgePosition: {
    right: 0,
    position: "absolute",
  },
  content3Position: {
    left: 24,
    position: "absolute",
  },
  text9Layout: {
    lineHeight: 20,
    fontSize: FontSize.subheadlineRegular15_size,
    letterSpacing: 0,
  },
  searchTypo: {
    fontFamily: FontFamily.nunitoRegular,
    lineHeight: 22,
    letterSpacing: 0,
    fontSize: FontSize.bodySemibold17_size,
  },
  carouselDotIcon1: {
    marginLeft: 8,
  },
  carouselDots: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    alignSelf: "stretch",
  },
  banners: {
    marginLeft: -26,
    top: 376,
  },
  imgBlurIcon: {
    width: "109.76%",
    right: "-4.88%",
    left: "-4.88%",
    opacity: 0.24,
    bottom: "-25%",
    top: "-5%",
    height: "130%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    borderRadius: Border.br_base,
    position: "absolute",
  },
  imgIcon: {
    borderRadius: Border.br_base,
  },
  title: {
    fontWeight: "600",
    fontFamily: FontFamily.nunitoSemibold,
    textAlign: "left",
    color: Color.globalWhite,
    alignSelf: "stretch",
  },
  subtitle: {
    marginTop: 4,
    fontFamily: FontFamily.caption2Regular11,
    textAlign: "left",
    color: Color.globalWhite,
    alignSelf: "stretch",
  },
  text: {
    right: 12,
  },
  cardsImage: {
    height: 160,
    borderRadius: Border.br_base,
    left: 0,
    width: 328,
    top: 0,
    position: "absolute",
  },
  imgBlurIcon1: {
    right: "-15.38%",
    left: "-10.26%",
  },
  cardsImage1: {
    left: 0,
  },
  imgBlurIcon2: {
    right: "-10.26%",
    left: "-15.38%",
  },
  cardsImage2: {
    left: 172,
  },
  frame61container: {
    height: 336,
    width: 328,
    top: 0,
  },
  min: {
    color: Color.globalBlack,
    lineHeight: 16,
    fontSize: FontSize.caption1Regular12_size,
    textAlign: "left",
  },
  tag: {
    paddingHorizontal: Padding.p_5xs,
    paddingVertical: Padding.p_9xs,
    borderRadius: Border.br_781xl,
    justifyContent: "center",
    bottom: 12,
    left: 12,
    position: "absolute",
    overflow: "hidden",
  },
  buttonIcon: {
    top: 12,
    width: 24,
    height: 24,
    right: 12,
    position: "absolute",
  },
  img: {
    overflow: "hidden",
    height: 160,
    borderRadius: Border.br_base,
    alignSelf: "stretch",
  },
  popperoniPizza: {
    color: Color.globalBlack,
    textAlign: "left",
    lineHeight: 22,
    fontSize: FontSize.bodySemibold17_size,
    letterSpacing: 0,
    alignSelf: "stretch",
  },
  dailyDeli: {
    lineHeight: 20,
    fontSize: FontSize.subheadlineRegular15_size,
    letterSpacing: 0,
    marginTop: 4,
    fontFamily: FontFamily.caption2Regular11,
  },
  cardsFood: {
    flex: 1,
  },
  starIcon: {
    width: 18,
    height: 18,
  },
  text4: {
    fontSize: FontSize.footnoteRegular13_size,
    lineHeight: 18,
    textAlign: "right",
    marginLeft: 4,
    color: Color.globalBlack,
    letterSpacing: 0,
  },
  ratings: {
    justifyContent: "flex-end",
    marginLeft: 24,
    alignItems: "center",
    flexDirection: "row",
  },
  content1: {
    marginTop: 8,
    flexDirection: "row",
    alignSelf: "stretch",
  },
  cardsFood1: {
    marginLeft: 16,
    flex: 1,
  },
  content: {
    width: 496,
    left: 0,
    top: 0,
    alignItems: "center",
    flexDirection: "row",
    position: "absolute",
  },
  frame54containersliderdefa: {
    top: 634,
    height: 214,
    left: 0,
  },
  deals: {
    color: Color.globalBlack,
    textAlign: "left",
    lineHeight: 22,
    fontSize: FontSize.bodySemibold17_size,
    letterSpacing: 0,
    flex: 1,
  },
  arrowrightIcon: {
    width: 22,
    height: 22,
    marginLeft: 24,
  },
  title3: {
    left: 0,
    width: 328,
    top: 0,
    flexDirection: "row",
    position: "absolute",
  },
  frame59container: {
    top: 600,
    height: 22,
    width: 328,
  },
  saucesIcon: {
    marginTop: 13,
    width: 106,
    height: 87,
    top: "50%",
  },
  pizzaIcon: {
    marginTop: -80,
    right: -20,
    width: 117,
    height: 117,
    top: "50%",
    position: "absolute",
  },
  pizzaHutIcon: {
    marginLeft: -18,
    width: 67,
    height: 67,
    opacity: 0.1,
    overflow: "hidden",
    top: 0,
  },
  pizzaParty: {
    color: Color.globalBlack,
    fontFamily: FontFamily.caption2Regular11,
    textAlign: "left",
    alignSelf: "stretch",
  },
  enjoyPizzaFrom: {
    marginTop: 4,
    fontFamily: FontFamily.caption2Regular11,
    lineHeight: 16,
    fontSize: FontSize.caption1Regular12_size,
  },
  text7: {
    alignSelf: "stretch",
  },
  startingFrom: {
    fontSize: FontSize.caption3Medium10_size,
    lineHeight: 12,
    fontWeight: "500",
    fontFamily: FontFamily.caption3Medium10,
    letterSpacing: 0,
  },
  text9: {
    color: Color.globalPrimary,
    fontFamily: FontFamily.bodySemibold17,
    fontWeight: "700",
    marginTop: 4,
    textAlign: "left",
    alignSelf: "stretch",
  },
  text8: {
    marginTop: 16,
    alignSelf: "stretch",
  },
  content3: {
    marginTop: -54,
    width: 160,
    top: "50%",
  },
  banners1: {
    backgroundColor: "transparent",
    overflow: "hidden",
    height: 160,
    borderRadius: Border.br_base,
    left: 0,
    width: 328,
    top: 0,
    position: "absolute",
  },
  frame62container: {
    height: 160,
    width: 328,
    top: 376,
  },
  frame1: {
    marginTop: 12,
    alignSelf: "stretch",
  },
  exploreMore: {
    left: 0,
    width: 328,
    top: 0,
    position: "absolute",
  },
  frame60container: {
    top: 888,
    height: 708,
    width: 328,
  },
  bannersParent: {
    top: 192,
    height: 1596,
    left: 12,
    width: 348,
  },
  patternIcon: {
    opacity: 0.2,
  },
  magnifyingglassIcon: {
    width: 22,
    height: 22,
  },
  search: {
    color: Color.grayGray2,
    textAlign: "left",
    flex: 1,
  },
  writeTextHerecomponentiContainer: {
    marginLeft: 8,
  },
  textField: {
    top: 98,
    right: 23,
    borderStyle: "solid",
    borderColor: "#f2f2f7",
    borderWidth: 1,
    paddingHorizontal: Padding.p_5xl,
    paddingVertical: Padding.p_base,
    backgroundColor: Color.globalWhite,
    alignItems: "center",
    flexDirection: "row",
    borderRadius: Border.br_base,
  },
  blockBPhase: {
    width: 294,
    marginLeft: 12,
    textAlign: "left",
    color: Color.globalWhite,
    alignSelf: "stretch",
  },
  location: {
    top: 60,
    width: 328,
    alignItems: "center",
    flexDirection: "row",
  },
  homeBarcontainertopBarhid: {
    backgroundColor: Color.mediumseagreen_200,
    height: 168,
    left: 0,
    top: 0,
  },
  buttonIcon5: {
    height: "175.86%",
    width: "162.07%",
    top: "-20.69%",
    right: "-20.69%",
    bottom: "-55.17%",
    left: "-41.38%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  text16: {
    textAlign: "center",
    color: Color.globalWhite,
  },
  badge: {
    backgroundColor: Color.globalBlack,
    width: 22,
    borderRadius: Border.br_781xl,
    justifyContent: "center",
    top: 0,
    alignItems: "center",
  },
  cartButtonLayer: {
    bottom: 108,
    width: 58,
    height: 58,
    right: 12,
    position: "absolute",
  },
  customerHome: {
    backgroundColor: Color.kitchenBG,
    height: 1999,
    width: "100%",
    flex: 1,
  },
});

export default CustomerHome;
