import * as React from "react";
import { Text, StyleSheet, Image, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Padding, Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const CustomerSearch = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.customerSearch}>
      <View style={styles.frame84}>
        <Text style={styles.search}>Search</Text>
        <View style={[styles.searchBar, styles.footerFlexBox]}>
          <Image
            style={styles.vectorSearch2Icon}
            resizeMode="cover"
            source={require("../assets/vectorsearch2.png")}
          />
          <Text style={styles.whatAreYou}>What are you craving?</Text>
        </View>
      </View>
      <View style={styles.frame37431}>
        <View style={styles.sushi}>
          <Text style={styles.sushi1}>Sushi</Text>
        </View>
        <View style={[styles.thai, styles.thaiPosition]}>
          <Text style={styles.sushi1}>Thai</Text>
        </View>
        <Pressable
          style={[styles.pizza, styles.thaiPosition]}
          onPress={() => navigation.navigate("CustomerSearchCategory2")}
        >
          <Text style={styles.sushi1}>Pizza</Text>
        </Pressable>
        <View style={[styles.tortilla, styles.thaiPosition]}>
          <Text style={styles.sushi1}>Tortilla</Text>
        </View>
        <Pressable
          style={[styles.burger95, styles.thaiPosition]}
          onPress={() => navigation.navigate("CustomerSearchCategory1")}
        >
          <Text style={styles.sushi1}>Burger</Text>
        </Pressable>
        <View style={[styles.rectangle160, styles.rectanglePosition3]} />
        <Text style={[styles.mexican, styles.wingsTypo]}>Mexican</Text>
        <View style={[styles.rectangle159, styles.rectanglePosition3]} />
        <Text style={[styles.wings, styles.wingsTypo]}>Wings</Text>
        <View style={[styles.rectangle158, styles.rectanglePosition3]} />
        <Text style={[styles.chinese, styles.wingsTypo]}>Chinese</Text>
        <View style={[styles.rectangle157, styles.rectanglePosition3]} />
        <Text style={[styles.indian, styles.wingsTypo]}>Indian</Text>
        <View style={[styles.rectangle165, styles.rectanglePosition2]} />
        <Text style={[styles.vegetarian, styles.saladTypo]}>Vegetarian</Text>
        <View style={[styles.rectangle163, styles.rectanglePosition2]} />
        <View style={[styles.rectangle163, styles.rectanglePosition2]} />
        <Text style={[styles.salad, styles.saladTypo]}>Salad</Text>
        <View style={[styles.rectangle162, styles.rectanglePosition2]} />
        <Text style={[styles.padang, styles.saladTypo]}>Padang</Text>
        <View style={[styles.rectangle161, styles.rectanglePosition2]} />
        <Text style={[styles.fastFood, styles.saladTypo]}>Fast Food</Text>
        <View style={[styles.rectangle170, styles.rectanglePosition1]} />
        <Text style={[styles.taco, styles.tacoTypo]}>Taco</Text>
        <View style={[styles.rectangle169, styles.rectanglePosition1]} />
        <Text style={[styles.coffee, styles.tacoTypo]}>Coffee</Text>
        <View style={[styles.rectangle168, styles.rectanglePosition1]} />
        <Text style={[styles.italian, styles.tacoTypo]}>Italian</Text>
        <View style={[styles.rectangle166, styles.rectanglePosition1]} />
        <Text style={[styles.kebab, styles.tacoTypo]}>Kebab</Text>
        <View style={[styles.rectangle167, styles.rectanglePosition1]} />
        <Text style={[styles.steak, styles.tacoTypo]}>Steak</Text>
        <View style={[styles.rectangle171, styles.rectanglePosition]} />
        <Text style={[styles.sandwich, styles.kosherTypo]}>Sandwich</Text>
        <View style={[styles.rectangle172, styles.rectanglePosition]} />
        <Text style={[styles.falafel, styles.kosherTypo]}>Falafel</Text>
        <View style={[styles.rectangle173, styles.rectanglePosition]} />
        <Text style={[styles.kosher, styles.kosherTypo]}>Kosher</Text>
      </View>
      <Text style={styles.popularCategories}>Popular categories</Text>
      <Text style={[styles.myRecentOrders, styles.greenCurryTypo]}>
        My recent orders
      </Text>
      <View style={[styles.frame37428, styles.frame37428Layout]}>
        <Image
          style={[styles.intersectIcon, styles.frame37428Layout]}
          resizeMode="cover"
          source={require("../assets/intersect.png")}
        />
        <Text style={[styles.km, styles.kmTypo]}>3,5 km</Text>
        <Text style={[styles.min, styles.kmTypo]}>{`20- 40 min `}</Text>
        <Text style={[styles.greenCurry, styles.greenCurryTypo]}>
          Green Curry
        </Text>
        <Text style={styles.indianCurries}>Indian, Curries</Text>
        <Text style={[styles.text, styles.kmTypo]}>4.7</Text>
        <Image
          style={styles.vectorStarIcon}
          resizeMode="cover"
          source={require("../assets/vectorstar2.png")}
        />
      </View>
      <View style={[styles.frame37429, styles.framePosition]}>
        <Image
          style={[styles.intersectIcon, styles.frame37428Layout]}
          resizeMode="cover"
          source={require("../assets/intersect1.png")}
        />
        <Text style={[styles.km, styles.kmTypo]}>3,5 km</Text>
        <Text style={[styles.min, styles.kmTypo]}>{`20- 40 min `}</Text>
        <Text style={[styles.greenCurry, styles.greenCurryTypo]}>Suhi Tei</Text>
        <Text style={styles.indianCurries}>Japanies, Sushi</Text>
        <Text style={[styles.text, styles.kmTypo]}>4.7</Text>
        <Image
          style={styles.vectorStarIcon}
          resizeMode="cover"
          source={require("../assets/vectorstar3.png")}
        />
      </View>
      <View style={[styles.frame37430, styles.framePosition]}>
        <Image
          style={[styles.intersectIcon, styles.frame37428Layout]}
          resizeMode="cover"
          source={require("../assets/intersect1.png")}
        />
        <Text style={[styles.km, styles.kmTypo]}>3,5 km</Text>
        <Text style={[styles.min, styles.kmTypo]}>{`20- 40 min `}</Text>
        <Text style={[styles.greenCurry, styles.greenCurryTypo]}>
          Pizza Hut
        </Text>
        <Text style={styles.indianCurries}>Italian, Pizza</Text>
        <Text style={[styles.text, styles.kmTypo]}>4.7</Text>
        <Image
          style={styles.vectorStarIcon}
          resizeMode="cover"
          source={require("../assets/vectorstar3.png")}
        />
      </View>
      <View style={styles.frame85}>
        <View style={[styles.footer, styles.footerFlexBox]}>
          <View style={styles.homeButton}>
            <Image
              style={styles.vectorHomeIcon}
              resizeMode="cover"
              source={require("../assets/vectorhome1.png")}
            />
            <Text style={[styles.home, styles.homeTypo]}>Home</Text>
          </View>
          <Pressable
            style={[styles.searchButton, styles.buttonSpaceBlock]}
            onPress={() => {}}
          >
            <View style={styles.frame82}>
              <Image
                style={styles.searchvectorIcon}
                resizeMode="cover"
                source={require("../assets/searchvector.png")}
              />
              <Text style={[styles.explore, styles.homeTypo]}>Explore</Text>
            </View>
          </Pressable>
          <View style={[styles.ordersButton, styles.buttonSpaceBlock]}>
            <Image
              style={styles.vectorClockIcon}
              resizeMode="cover"
              source={require("../assets/vectorclock1.png")}
            />
            <Text style={[styles.orders, styles.ordersTypo]}>Orders</Text>
          </View>
          <Pressable
            style={[styles.ordersButton, styles.buttonSpaceBlock]}
            onPress={() => navigation.navigate("CustomerProfile")}
          >
            <Image
              style={styles.vectorUserIcon}
              resizeMode="cover"
              source={require("../assets/vectoruser.png")}
            />
            <Text style={[styles.account, styles.ordersTypo]}>Account</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  footerFlexBox: {
    flexDirection: "row",
    alignItems: "center",
    overflow: "hidden",
  },
  thaiPosition: {
    paddingVertical: Padding.p_7xs,
    backgroundColor: Color.seagreen_100,
    borderRadius: Border.br_3xs,
    flexDirection: "row",
    top: 0,
    position: "absolute",
    overflow: "hidden",
  },
  rectanglePosition3: {
    bottom: "62.63%",
    top: "21.58%",
    height: "15.79%",
    backgroundColor: Color.seagreen_100,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  wingsTypo: {
    top: "24.74%",
    color: Color.globalWhite,
    fontFamily: FontFamily.nunitoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    textAlign: "left",
    position: "absolute",
  },
  rectanglePosition2: {
    bottom: "42.11%",
    top: "42.11%",
    height: "15.79%",
    backgroundColor: Color.seagreen_100,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  saladTypo: {
    top: "45.26%",
    color: Color.globalWhite,
    fontFamily: FontFamily.nunitoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    textAlign: "left",
    position: "absolute",
  },
  rectanglePosition1: {
    bottom: "21.05%",
    top: "63.16%",
    height: "15.79%",
    backgroundColor: Color.seagreen_100,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  tacoTypo: {
    top: "66.32%",
    color: Color.globalWhite,
    fontFamily: FontFamily.nunitoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    textAlign: "left",
    position: "absolute",
  },
  rectanglePosition: {
    bottom: "0%",
    top: "84.21%",
    height: "15.79%",
    backgroundColor: Color.seagreen_100,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  kosherTypo: {
    top: "87.37%",
    color: Color.globalWhite,
    fontFamily: FontFamily.nunitoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    textAlign: "left",
    position: "absolute",
  },
  greenCurryTypo: {
    color: Color.darkslategray_100,
    fontSize: FontSize.size_sm,
    textAlign: "left",
    position: "absolute",
  },
  frame37428Layout: {
    height: 55,
    position: "absolute",
  },
  kmTypo: {
    color: Color.slategray_100,
    fontFamily: FontFamily.nunitoRegular,
    textAlign: "left",
    position: "absolute",
  },
  framePosition: {
    left: 50,
    height: 55,
    width: 247,
    position: "absolute",
  },
  homeTypo: {
    marginTop: 2,
    textAlign: "center",
    color: Color.darkslategray_200,
    fontFamily: FontFamily.caption2Regular11,
    lineHeight: 13,
    letterSpacing: 0,
    fontSize: FontSize.caption2Regular11_size,
  },
  buttonSpaceBlock: {
    marginLeft: 43,
    flex: 1,
  },
  ordersTypo: {
    textAlign: "center",
    color: Color.darkslategray_200,
    fontFamily: FontFamily.caption2Regular11,
    lineHeight: 13,
    letterSpacing: 0,
    fontSize: FontSize.caption2Regular11_size,
  },
  search: {
    fontSize: 21,
    color: "#302f3d",
    textAlign: "left",
    fontFamily: FontFamily.sFProDisplayBold,
    fontWeight: "700",
    letterSpacing: 0.6,
    left: 0,
    top: 0,
    position: "absolute",
  },
  vectorSearch2Icon: {
    width: 17,
    height: 17,
  },
  whatAreYou: {
    letterSpacing: 0.9,
    fontFamily: FontFamily.sFProDisplayRegular,
    color: "#81808c",
    marginLeft: 17,
    fontSize: FontSize.footnoteRegular13_size,
    textAlign: "left",
  },
  searchBar: {
    top: 40,
    left: 29,
    borderRadius: 4,
    backgroundColor: "#f3f4f6",
    width: 259,
    paddingLeft: Padding.p_base,
    paddingTop: Padding.p_base,
    paddingRight: 123,
    paddingBottom: Padding.p_base,
    alignItems: "center",
    position: "absolute",
  },
  frame84: {
    top: 37,
    left: 21,
    width: 288,
    height: 89,
    position: "absolute",
  },
  sushi1: {
    color: Color.globalWhite,
    fontFamily: FontFamily.nunitoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    textAlign: "left",
  },
  sushi: {
    left: 4,
    paddingVertical: Padding.p_6xs,
    paddingHorizontal: Padding.p_4xs,
    backgroundColor: Color.seagreen_100,
    borderRadius: Border.br_3xs,
    flexDirection: "row",
    top: 0,
    position: "absolute",
    overflow: "hidden",
  },
  thai: {
    left: 62,
    paddingHorizontal: 11,
  },
  pizza: {
    left: 117,
    paddingHorizontal: Padding.p_3xs,
  },
  tortilla: {
    left: 175,
    paddingHorizontal: Padding.p_6xs,
  },
  burger95: {
    left: 240,
    paddingHorizontal: Padding.p_4xs,
  },
  rectangle160: {
    width: "23.61%",
    right: "6.23%",
    left: "70.16%",
  },
  mexican: {
    left: "73.44%",
  },
  rectangle159: {
    width: "18.69%",
    right: "31.15%",
    left: "50.16%",
  },
  wings: {
    left: "52.46%",
  },
  rectangle158: {
    width: "22.62%",
    right: "51.15%",
    left: "26.23%",
  },
  chinese: {
    left: "29.18%",
  },
  rectangle157: {
    right: "75.08%",
    left: "5.9%",
    width: "19.02%",
  },
  indian: {
    left: "8.85%",
  },
  rectangle165: {
    width: "27.87%",
    right: "72.13%",
    left: "0%",
  },
  vegetarian: {
    left: "2.62%",
  },
  rectangle163: {
    width: "17.05%",
    right: "53.77%",
    left: "29.18%",
  },
  salad: {
    left: "31.48%",
  },
  rectangle162: {
    width: "24.59%",
    right: "27.54%",
    left: "47.87%",
  },
  padang: {
    left: "52.13%",
  },
  rectangle161: {
    width: "25.57%",
    right: "0.33%",
    left: "74.1%",
  },
  fastFood: {
    left: "76.72%",
  },
  rectangle170: {
    width: "16.07%",
    right: "0%",
    left: "83.93%",
  },
  taco: {
    left: "87.21%",
  },
  rectangle169: {
    width: "20%",
    right: "17.7%",
    left: "62.3%",
  },
  coffee: {
    left: "65.57%",
  },
  rectangle168: {
    right: "39.34%",
    left: "41.64%",
    width: "19.02%",
  },
  italian: {
    left: "44.59%",
  },
  rectangle166: {
    right: "60%",
    left: "20.98%",
    width: "19.02%",
  },
  kebab: {
    left: "23.61%",
  },
  rectangle167: {
    width: "17.7%",
    right: "80.33%",
    left: "1.97%",
  },
  steak: {
    left: "4.92%",
  },
  rectangle171: {
    width: "25.9%",
    right: "58.03%",
    left: "16.07%",
  },
  sandwich: {
    left: "18.69%",
  },
  rectangle172: {
    right: "37.7%",
    left: "43.28%",
    width: "19.02%",
  },
  falafel: {
    left: "45.57%",
  },
  rectangle173: {
    width: "20.33%",
    right: "16.07%",
    left: "63.61%",
  },
  kosher: {
    left: "66.56%",
  },
  frame37431: {
    top: 200,
    left: 30,
    width: 305,
    height: 190,
    position: "absolute",
  },
  popularCategories: {
    top: 159,
    left: 24,
    color: "#33323a",
    fontSize: FontSize.size_sm,
    textAlign: "left",
    fontFamily: FontFamily.sFProDisplayBold,
    fontWeight: "700",
    letterSpacing: 0.6,
    position: "absolute",
  },
  myRecentOrders: {
    top: 422,
    left: 51,
    color: Color.darkslategray_100,
    fontFamily: FontFamily.sFProDisplayBold,
    fontWeight: "700",
  },
  intersectIcon: {
    width: 65,
    height: 55,
    left: 0,
    top: 0,
  },
  km: {
    width: "16.37%",
    fontSize: FontSize.caption1Regular12_size,
    top: "68.24%",
    height: "24.63%",
    color: Color.slategray_100,
    left: "30.58%",
  },
  min: {
    width: "26.37%",
    left: "52.86%",
    fontSize: FontSize.caption1Regular12_size,
    top: "68.24%",
    height: "24.63%",
    color: Color.slategray_100,
  },
  greenCurry: {
    height: "32.82%",
    width: "62.84%",
    top: "5.47%",
    left: "30.61%",
    color: Color.darkslategray_100,
    fontFamily: FontFamily.nunitoMedium,
    fontWeight: "500",
  },
  indianCurries: {
    width: "41.38%",
    top: "38.34%",
    color: Color.darkslategray_300,
    fontFamily: FontFamily.nunitoRegular,
    fontSize: FontSize.caption1Regular12_size,
    left: "30.58%",
    height: "24.63%",
    textAlign: "left",
    position: "absolute",
  },
  text: {
    height: "28.15%",
    width: "8.18%",
    top: "66.48%",
    left: "91.82%",
    fontSize: FontSize.footnoteRegular13_size,
  },
  vectorStarIcon: {
    height: "19.1%",
    width: "5.62%",
    top: "73.26%",
    right: "9.59%",
    bottom: "7.65%",
    left: "84.78%",
    borderRadius: Border.br_12xs_5,
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  frame37428: {
    top: 459,
    width: 247,
    height: 55,
    left: 51,
  },
  frame37429: {
    top: 534,
  },
  frame37430: {
    top: 612,
  },
  vectorHomeIcon: {
    width: 26,
    height: 21,
  },
  home: {
    width: 32,
  },
  homeButton: {
    alignItems: "center",
    flex: 1,
  },
  searchvectorIcon: {
    width: 22,
    height: 22,
  },
  explore: {
    width: 41,
  },
  frame82: {
    alignItems: "center",
  },
  searchButton: {
    padding: Padding.p_3xs,
  },
  vectorClockIcon: {
    width: 23,
    height: 23,
  },
  orders: {
    width: 43,
    marginTop: 3,
  },
  ordersButton: {
    alignItems: "center",
  },
  vectorUserIcon: {
    width: 24,
    height: 24,
  },
  account: {
    width: 54,
  },
  footer: {
    alignSelf: "stretch",
    backgroundColor: Color.globalWhite,
    borderStyle: "solid",
    borderColor: "#f3f3f3",
    borderWidth: 1,
    paddingHorizontal: Padding.p_10xl,
    paddingVertical: Padding.p_lgi,
    alignItems: "center",
  },
  frame85: {
    top: 705,
    left: -5,
    width: 377,
    justifyContent: "center",
    alignItems: "center",
    position: "absolute",
  },
  customerSearch: {
    backgroundColor: Color.kitchenBG,
    width: "100%",
    height: 800,
    overflow: "hidden",
    flex: 1,
  },
});

export default CustomerSearch;
