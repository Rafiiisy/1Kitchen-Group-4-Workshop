import * as React from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const Splashscreen = () => {
  return (
    <LinearGradient
      style={styles.splashscreen}
      locations={[0.4, 1]}
      colors={["#229c57", "#efffec"]}
      useAngle={true}
      angle={180}
    >
      <View style={styles.frame37465}>
        <Image
          style={styles.kWhite1Icon}
          resizeMode="cover"
          source={require("../assets/1kwhite1.png")}
        />
        <Text style={styles.oneKitchen}>One Kitchen</Text>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  kWhite1Icon: {
    top: 0,
    left: 0,
    height: 222,
    position: "absolute",
    width: 250,
  },
  oneKitchen: {
    top: 247,
    left: 11,
    fontSize: FontSize.size_21xl,
    fontWeight: "700",
    fontFamily: FontFamily.nunitoBold,
    color: Color.globalWhite,
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 228,
    height: 55,
    position: "absolute",
  },
  frame37465: {
    height: 302,
    width: 250,
  },
  splashscreen: {
    flex: 1,
    width: "100%",
    overflow: "hidden",
    flexDirection: "row",
    paddingHorizontal: 55,
    paddingVertical: 188,
    backgroundColor: "transparent",
  },
});

export default Splashscreen;
