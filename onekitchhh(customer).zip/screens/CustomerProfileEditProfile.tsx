import React, { useState, useCallback } from "react";
import { Image, StyleSheet, Text, View, Pressable, Modal } from "react-native";
import ConfirmationCustomer from "../components/ConfirmationCustomer";
import { useNavigation } from "@react-navigation/native";
import { Padding, Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const CustomerProfileEditProfile = () => {
  const [buttonsContainerVisible, setButtonsContainerVisible] = useState(false);
  const navigation = useNavigation();

  const openButtonsContainer = useCallback(() => {
    setButtonsContainerVisible(true);
  }, []);

  const closeButtonsContainer = useCallback(() => {
    setButtonsContainerVisible(false);
  }, []);

  return (
    <>
      <View style={styles.customerProfileEditProfile}>
        <Image
          style={styles.avatarIcon}
          resizeMode="cover"
          source={require("../assets/avatar.png")}
        />
        <View style={[styles.credentials, styles.buttonsPosition]}>
          <View style={styles.textFields}>
            <View style={[styles.textField, styles.textBorder]}>
              <View style={styles.content}>
                <Text style={styles.label}>Name</Text>
                <Text
                  style={[styles.writeTextHerecomponenti, styles.headlineClr]}
                >
                  John Doe
                </Text>
              </View>
            </View>
            <View style={[styles.textField1, styles.textBorder]}>
              <View style={styles.content}>
                <Text style={styles.label}>Email</Text>
                <Text
                  style={[styles.writeTextHerecomponenti, styles.headlineClr]}
                >
                  johndoe123@gmail.com
                </Text>
              </View>
            </View>
            <View style={[styles.textField1, styles.textBorder]}>
              <View style={styles.content}>
                <Text style={styles.label}>Phone No.</Text>
                <Text
                  style={[styles.writeTextHerecomponenti, styles.headlineClr]}
                >
                  +92 3014124781
                </Text>
              </View>
            </View>
            <View style={[styles.textField1, styles.textBorder]}>
              <View style={styles.content}>
                <Text style={styles.label}>Password</Text>
                <Text
                  style={[styles.writeTextHerecomponenti, styles.headlineClr]}
                >
                  ••••••••••••••
                </Text>
              </View>
              <Image
                style={[styles.eyeIcon, styles.iconLayout]}
                resizeMode="cover"
                source={require("../assets/eye.png")}
              />
            </View>
          </View>
        </View>
        <Pressable
          style={[styles.buttons, styles.buttonFlexBox]}
          onPress={openButtonsContainer}
        >
          <View style={[styles.button, styles.buttonFlexBox]}>
            <Text style={[styles.button1, styles.button1Typo]}>Save</Text>
          </View>
        </Pressable>
        <View style={[styles.spacer, styles.spacerPosition]}>
          <View style={[styles.spacer1, styles.bgPosition]} />
        </View>
        <View style={[styles.appBarcontainertopBar, styles.spacerPosition]}>
          <View style={[styles.bg, styles.bgPosition]} />
          <Text style={[styles.headline, styles.headlinePosition]}>
            Edit Account
          </Text>
          <Pressable
            style={[styles.arrowleft, styles.headlinePosition]}
            onPress={() => navigation.navigate("CustomerProfile")}
          >
            <Image
              style={styles.icon}
              resizeMode="cover"
              source={require("../assets/arrowleft.png")}
            />
          </Pressable>
          <View style={[styles.textOrButtons, styles.buttonsFlexBox]}>
            <Text style={styles.skip}>Skip</Text>
            <View style={[styles.buttons1, styles.buttonsFlexBox]}>
              <Image
                style={styles.iconLayout}
                resizeMode="cover"
                source={require("../assets/heart.png")}
              />
              <Image
                style={[styles.sharenetworkIcon, styles.iconLayout]}
                resizeMode="cover"
                source={require("../assets/sharenetwork.png")}
              />
              <Image
                style={[styles.sharenetworkIcon, styles.iconLayout]}
                resizeMode="cover"
                source={require("../assets/dotsthreevertical.png")}
              />
            </View>
          </View>
        </View>
      </View>

      <Modal animationType="fade" transparent visible={buttonsContainerVisible}>
        <View style={styles.buttonsContainerOverlay}>
          <Pressable
            style={styles.buttonsContainerBg}
            onPress={closeButtonsContainer}
          />
          <ConfirmationCustomer onClose={closeButtonsContainer} />
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  buttonsPosition: {
    width: 313,
    left: 23,
    position: "absolute",
  },
  textBorder: {
    paddingVertical: Padding.p_base,
    paddingHorizontal: Padding.p_5xl,
    borderWidth: 1,
    borderColor: "#f2f2f7",
    borderStyle: "solid",
    alignItems: "center",
    flexDirection: "row",
    backgroundColor: Color.globalWhite,
    borderRadius: Border.br_base,
    alignSelf: "stretch",
  },
  headlineClr: {
    color: Color.globalBlack,
    textAlign: "left",
  },
  iconLayout: {
    height: 22,
    width: 22,
  },
  buttonFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  button1Typo: {
    fontWeight: "700",
    lineHeight: 22,
    letterSpacing: 0,
    fontSize: FontSize.bodySemibold17_size,
  },
  spacerPosition: {
    left: 0,
    right: 0,
    position: "absolute",
  },
  bgPosition: {
    left: "0%",
    right: "0%",
    top: "0%",
    position: "absolute",
    width: "100%",
  },
  headlinePosition: {
    top: "50%",
    position: "absolute",
  },
  buttonsFlexBox: {
    display: "none",
    flexDirection: "row",
  },
  avatarIcon: {
    top: 120,
    left: 120,
    width: 120,
    height: 120,
    position: "absolute",
  },
  label: {
    fontSize: FontSize.caption1Regular12_size,
    lineHeight: 16,
    color: Color.grayGray2,
    textAlign: "left",
    fontFamily: FontFamily.caption2Regular11,
    alignSelf: "stretch",
  },
  writeTextHerecomponenti: {
    fontFamily: FontFamily.nunitoRegular,
    marginTop: 4,
    lineHeight: 22,
    fontSize: FontSize.bodySemibold17_size,
    color: Color.globalBlack,
    letterSpacing: 0,
    alignSelf: "stretch",
  },
  content: {
    flex: 1,
  },
  textField: {
    alignItems: "center",
  },
  textField1: {
    marginTop: 16,
    alignItems: "center",
  },
  eyeIcon: {
    marginLeft: 8,
  },
  textFields: {
    alignSelf: "stretch",
  },
  credentials: {
    top: 280,
  },
  buttonsContainerOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  buttonsContainerBg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  button1: {
    fontFamily: FontFamily.bodySemibold17,
    color: Color.globalWhite,
    textAlign: "center",
  },
  button: {
    backgroundColor: Color.mediumseagreen_200,
    paddingHorizontal: Padding.p_13xl,
    paddingVertical: Padding.p_xl,
    flexDirection: "row",
    borderRadius: Border.br_base,
    justifyContent: "center",
    alignSelf: "stretch",
  },
  buttons: {
    top: 664,
    width: 313,
    left: 23,
    position: "absolute",
  },
  spacer1: {
    bottom: "0%",
    backgroundColor: Color.grayGray6,
    height: "100%",
  },
  spacer: {
    top: 88,
    height: 8,
  },
  bg: {
    height: "181.82%",
    bottom: "-81.82%",
  },
  headline: {
    marginLeft: -130,
    left: "50%",
    fontFamily: FontFamily.nunitoBold,
    marginTop: 6,
    fontWeight: "700",
    lineHeight: 22,
    letterSpacing: 0,
    fontSize: FontSize.bodySemibold17_size,
    color: Color.globalBlack,
    textAlign: "left",
  },
  icon: {
    marginTop: 6,
    height: "100%",
    width: "100%",
  },
  arrowleft: {
    left: 24,
    height: 22,
    width: 22,
  },
  skip: {
    fontSize: FontSize.footnoteRegular13_size,
    lineHeight: 18,
    color: Color.grayGray1,
    letterSpacing: 0,
    textAlign: "left",
    fontFamily: FontFamily.caption2Regular11,
  },
  sharenetworkIcon: {
    marginLeft: 16,
  },
  buttons1: {
    justifyContent: "flex-end",
    marginLeft: 8,
    alignItems: "center",
  },
  textOrButtons: {
    right: 23,
    top: "50%",
    position: "absolute",
    marginTop: 6,
  },
  appBarcontainertopBar: {
    top: 0,
    height: 88,
    backgroundColor: Color.globalWhite,
    left: 0,
    right: 0,
  },
  customerProfileEditProfile: {
    backgroundColor: Color.kitchenBG,
    height: 800,
    overflow: "hidden",
    width: "100%",
    flex: 1,
  },
});

export default CustomerProfileEditProfile;
