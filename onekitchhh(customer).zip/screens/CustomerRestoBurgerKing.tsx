import * as React from "react";
import { Image, StyleSheet, View, Text } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import FooterContainer from "../components/FooterContainer";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const CustomerRestoBurgerKing = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.customerRestoBurgerKing}>
      <Image
        style={[
          styles.pexelsPhotoByValeriaBoltne,
          styles.rectangle4414Position1,
        ]}
        resizeMode="cover"
        source={require("../assets/pexels-photo-by-valeria-boltneva.png")}
      />
      <LinearGradient
        style={styles.rectangle4394}
        locations={[0, 0.7]}
        colors={["rgba(22, 22, 22, 0)", "rgba(22, 22, 22, 0.8)"]}
        useAngle={true}
        angle={180.15}
      />
      <Image
        style={[styles.kColour1Icon, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/1kcolour11.png")}
      />
      <Text style={[styles.text, styles.textTypo]}>4.5</Text>
      <Text style={[styles.ratings, styles.text2Typo]}>560 ratings</Text>
      <Text style={[styles.text1, styles.textTypo]}>$$$</Text>
      <Text style={[styles.text2, styles.text2Typo]}>$15 - $45</Text>
      <Text style={[styles.likedBy, styles.text2Typo]}>Liked by</Text>
      <Text style={[styles.k, styles.textTypo]}>435K</Text>
      <Image
        style={[styles.heartIcon, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/hearticon.png")}
      />
      <Text style={styles.burgerKing}>Burger King</Text>
      <Text style={styles.menu}>Menu</Text>
      <View style={styles.line1} />
      <View style={[styles.rectangle4414Parent, styles.rectangle4414Layout]}>
        <View style={[styles.rectangle4414, styles.rectangle4414Layout]} />
        <Image
          style={styles.maskGroupIcon}
          resizeMode="cover"
          source={require("../assets/maskgroup.png")}
        />
        <Text style={styles.burger1}>Burger 1</Text>
        <Text style={[styles.text3, styles.text3Position]}>$20</Text>
      </View>
      <View style={[styles.rectangle4414Group, styles.rectangle4414Layout]}>
        <View style={[styles.rectangle4414, styles.rectangle4414Layout]} />
        <Image
          style={styles.maskGroupIcon}
          resizeMode="cover"
          source={require("../assets/maskgroup.png")}
        />
        <Text style={[styles.burger2, styles.text3Position]}>Burger 2</Text>
        <Text style={[styles.text3, styles.text3Position]}>$20</Text>
      </View>
      <View style={[styles.rectangle4414Container, styles.groupViewPosition]}>
        <View style={[styles.rectangle4414, styles.rectangle4414Layout]} />
        <Image
          style={styles.maskGroupIcon}
          resizeMode="cover"
          source={require("../assets/maskgroup.png")}
        />
        <Text style={[styles.burger2, styles.text3Position]}>Burger 5</Text>
        <Text style={[styles.text3, styles.text3Position]}>$20</Text>
      </View>
      <View style={[styles.groupView, styles.groupViewPosition]}>
        <View style={[styles.rectangle4414, styles.rectangle4414Layout]} />
        <Image
          style={styles.maskGroupIcon}
          resizeMode="cover"
          source={require("../assets/maskgroup.png")}
        />
        <Text style={[styles.burger2, styles.text3Position]}>Burger 6</Text>
        <Text style={[styles.text3, styles.text3Position]}>$20</Text>
      </View>
      <View
        style={[
          styles.rectangle4414Parent1,
          styles.rectangle4414ParentPosition,
        ]}
      >
        <View style={[styles.rectangle4414, styles.rectangle4414Layout]} />
        <Image
          style={styles.maskGroupIcon}
          resizeMode="cover"
          source={require("../assets/maskgroup.png")}
        />
        <Text style={[styles.burger2, styles.text3Position]}>Burger 3</Text>
        <Text style={[styles.text3, styles.text3Position]}>$20</Text>
      </View>
      <View
        style={[
          styles.rectangle4414Parent2,
          styles.rectangle4414ParentPosition,
        ]}
      >
        <View style={[styles.rectangle4414, styles.rectangle4414Layout]} />
        <Image
          style={styles.maskGroupIcon}
          resizeMode="cover"
          source={require("../assets/maskgroup.png")}
        />
        <Text style={[styles.burger2, styles.text3Position]}>Burger 4</Text>
        <Text style={[styles.text3, styles.text3Position]}>$20</Text>
      </View>
      <FooterContainer
        onSearchButtonPress={() => navigation.navigate("CustomerSearch")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  rectangle4414Position1: {
    top: 0,
    left: 0,
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  textTypo: {
    color: Color.globalWhite,
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    lineHeight: 25,
    fontSize: FontSize.size_lg,
    top: 186,
    textAlign: "center",
    position: "absolute",
  },
  text2Typo: {
    fontFamily: FontFamily.sFProDisplayMedium,
    fontWeight: "500",
    lineHeight: 22,
    fontSize: FontSize.size_base,
    top: 211,
    textAlign: "center",
    color: Color.globalWhite,
    position: "absolute",
  },
  rectangle4414Layout: {
    height: 186,
    width: 148,
    position: "absolute",
  },
  text3Position: {
    left: 12,
    color: Color.gray_500,
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  groupViewPosition: {
    top: 772,
    height: 186,
    width: 148,
    position: "absolute",
  },
  rectangle4414ParentPosition: {
    top: 550,
    height: 186,
    width: 148,
    position: "absolute",
  },
  pexelsPhotoByValeriaBoltne: {
    width: 474,
    height: 316,
    left: 0,
    position: "absolute",
  },
  rectangle4394: {
    top: 10,
    width: 360,
    height: 241,
    opacity: 0.8,
    backgroundColor: "transparent",
    left: 0,
    position: "absolute",
  },
  kColour1Icon: {
    height: "2.15%",
    width: "8.33%",
    top: "1.61%",
    right: "86.11%",
    bottom: "96.24%",
    left: "5.56%",
  },
  text: {
    left: 63,
    textAlign: "center",
  },
  ratings: {
    left: 18,
  },
  text1: {
    left: 164,
    textAlign: "center",
  },
  text2: {
    left: 145,
  },
  likedBy: {
    left: 268,
  },
  k: {
    left: 292,
    textAlign: "center",
  },
  heartIcon: {
    height: "1.59%",
    width: "5.79%",
    top: "17.56%",
    right: "21.44%",
    bottom: "80.85%",
    left: "72.78%",
  },
  burgerKing: {
    top: 257,
    fontSize: FontSize.size_5xl,
    lineHeight: 34,
    textAlign: "left",
    color: Color.globalBlack,
    left: 23,
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  menu: {
    top: 290,
    left: 28,
    fontSize: FontSize.size_xl,
    lineHeight: 28,
    fontWeight: "600",
    fontFamily: FontFamily.nunitoSemibold,
    color: Color.globalBlack,
    textAlign: "center",
    position: "absolute",
  },
  line1: {
    right: 118,
    bottom: -14,
    borderStyle: "solid",
    borderColor: "#000",
    borderTopWidth: 4.4,
    width: 137,
    height: 4,
    position: "absolute",
  },
  rectangle4414: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.mediumseagreen_100,
    left: 0,
    top: 0,
  },
  maskGroupIcon: {
    height: 124,
    width: 148,
    left: 0,
    top: 0,
    position: "absolute",
  },
  burger1: {
    left: 13,
    color: Color.gray_500,
    top: 128,
    textAlign: "left",
    lineHeight: 22,
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  text3: {
    top: 150,
    fontSize: FontSize.size_sm,
    lineHeight: 20,
    textAlign: "center",
  },
  rectangle4414Parent: {
    left: 24,
    top: 333,
    height: 186,
  },
  burger2: {
    top: 128,
    left: 12,
    textAlign: "left",
    lineHeight: 22,
    fontSize: FontSize.size_base,
  },
  rectangle4414Group: {
    left: 191,
    top: 333,
    height: 186,
  },
  rectangle4414Container: {
    left: 24,
  },
  groupView: {
    left: 191,
  },
  rectangle4414Parent1: {
    left: 23,
    top: 550,
  },
  rectangle4414Parent2: {
    left: 190,
  },
  customerRestoBurgerKing: {
    backgroundColor: Color.kitchenBG,
    flex: 1,
    width: "100%",
    height: 1082,
    overflow: "hidden",
  },
});

export default CustomerRestoBurgerKing;
