import * as React from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import { TextInput as RNPTextInput } from "react-native-paper";
import { Color, FontFamily, FontSize, Padding } from "../GlobalStyles";

const Login = () => {
  return (
    <View style={styles.login}>
      <Image
        style={styles.kColour1Icon}
        resizeMode="cover"
        source={require("../assets/1kcolour1.png")}
      />
      <Text style={[styles.welcomeBack, styles.logInToTypo]}>
        Welcome Back!
      </Text>
      <Text style={[styles.logInTo, styles.logInToTypo]}>
        Log in to your account
      </Text>
      <RNPTextInput
        style={styles.oneWaySection}
        placeholder="Enter your name"
        label="Name"
        mode="outlined"
        left={
          <RNPTextInput.Icon
            style={{ marginTop: "50%" }}
            name="account-circle"
          />
        }
        placeholderTextColor="#191919"
        theme={{ colors: { text: "#9eaab6", background: "#fff" } }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  logInToTypo: {
    textAlign: "center",
    color: Color.globalBlack,
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    marginTop: 11,
  },
  kColour1Icon: {
    width: 75,
    height: 67,
  },
  welcomeBack: {
    fontSize: FontSize.title1Bold28_size,
    marginTop: 11,
  },
  logInTo: {
    fontSize: FontSize.size_5xl,
    marginTop: 11,
  },
  oneWaySection: {
    width: 319,
    paddingHorizontal: 0,
    paddingVertical: Padding.p_3xs,
    marginTop: 11,
  },
  login: {
    backgroundColor: Color.gray_300,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    paddingHorizontal: Padding.p_xl,
    paddingVertical: Padding.p_17xl,
    alignItems: "center",
  },
});

export default Login;
