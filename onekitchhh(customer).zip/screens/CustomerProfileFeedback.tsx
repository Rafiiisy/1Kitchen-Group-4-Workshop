import * as React from "react";
import { Text, StyleSheet, View, Image, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Border } from "../GlobalStyles";

const CustomerProfileFeedback = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.customerProfileFeedback}>
      <View style={[styles.frame14ContainerTopBar, styles.containerPosition]}>
        <Text style={[styles.feedback, styles.submitTypo]}>Feedback</Text>
        <View style={styles.line9} />
        <Pressable
          style={styles.frame26ActiongobackLay}
          onPress={() => navigation.navigate("CustomerProfile")}
        >
          <Image
            style={styles.arrowDownSignToNavigate5Icon}
            resizeMode="cover"
            source={require("../assets/arrowdownsigntonavigate51.png")}
          />
        </Pressable>
      </View>
      <View style={[styles.frame15Container, styles.containerPosition]}>
        <Text style={[styles.howDoYou, styles.howDoYouTypo]}>
          How do you feel about 1Kitchen?
        </Text>
        <View style={[styles.group37297, styles.group37297Layout]}>
          <View style={[styles.rectangle4400, styles.rectangleBorder]} />
          <Text
            style={[
              styles.selectOptionscomponentinput,
              styles.writeYourExperiencecompoTypo,
            ]}
          >
            select options
          </Text>
          <Image
            style={styles.arrowDownSignToNavigate5Icon1}
            resizeMode="cover"
            source={require("../assets/arrowdownsigntonavigate52.png")}
          />
        </View>
        <Text style={[styles.tellUsAbout, styles.howDoYouTypo]}>
          Tell us about your experience!
        </Text>
        <View style={[styles.rectangle4400Parent, styles.rectangle44001Layout]}>
          <View style={[styles.rectangle44001, styles.rectangle44001Layout]} />
          <Text
            style={[
              styles.writeYourExperiencecompo,
              styles.writeYourExperiencecompoTypo,
            ]}
          >
            Write your experience...
          </Text>
        </View>
      </View>
      <Pressable
        style={[styles.group37342, styles.group37342Layout]}
        onPress={() => navigation.navigate("CustomerProfile")}
      >
        <Pressable
          style={[styles.rectangle44002, styles.group37342Layout]}
          onPress={() => navigation.navigate("CustomerProfile")}
        />
        <Text style={[styles.submit, styles.submitTypo]}>Submit</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  containerPosition: {
    width: 360,
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  submitTypo: {
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    textAlign: "center",
    position: "absolute",
  },
  howDoYouTypo: {
    color: Color.kLightGreen,
    fontSize: FontSize.size_base,
    left: 22,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  group37297Layout: {
    height: 44,
    width: 304,
    position: "absolute",
  },
  rectangleBorder: {
    borderWidth: 2,
    borderColor: "#0d7a42",
    backgroundColor: Color.gray_200,
    borderRadius: Border.br_8xs,
    borderStyle: "solid",
    left: 0,
    top: 0,
  },
  writeYourExperiencecompoTypo: {
    color: Color.gray_400,
    fontFamily: FontFamily.nunitoRegular,
    fontSize: FontSize.size_sm,
    left: 15,
    position: "absolute",
  },
  rectangle44001Layout: {
    height: 388,
    width: 304,
    position: "absolute",
  },
  group37342Layout: {
    width: 280,
    height: 44,
    position: "absolute",
  },
  feedback: {
    top: 22,
    left: 109,
    fontSize: FontSize.size_13xl,
    color: Color.globalBlack,
    textAlign: "center",
  },
  line9: {
    top: 88,
    borderColor: "#8c8c8c",
    borderTopWidth: 1,
    width: 312,
    height: 1,
    borderStyle: "solid",
    left: 24,
    position: "absolute",
  },
  arrowDownSignToNavigate5Icon: {
    top: 9,
    left: 14,
    width: 20,
    height: 20,
    position: "absolute",
  },
  frame26ActiongobackLay: {
    top: 29,
    width: 46,
    height: 31,
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  frame14ContainerTopBar: {
    height: 88,
    top: 0,
  },
  howDoYou: {
    top: 15,
  },
  rectangle4400: {
    height: 44,
    width: 304,
    position: "absolute",
  },
  selectOptionscomponentinput: {
    top: 12,
    textAlign: "center",
  },
  arrowDownSignToNavigate5Icon1: {
    top: 16,
    left: 276,
    width: 12,
    height: 12,
    position: "absolute",
  },
  group37297: {
    top: 37,
    left: 24,
  },
  tellUsAbout: {
    top: 101,
  },
  rectangle44001: {
    borderWidth: 2,
    borderColor: "#0d7a42",
    backgroundColor: Color.gray_200,
    borderRadius: Border.br_8xs,
    borderStyle: "solid",
    left: 0,
    top: 0,
  },
  writeYourExperiencecompo: {
    top: 11,
    textAlign: "left",
    width: 229,
    height: 14,
  },
  rectangle4400Parent: {
    top: 123,
    left: 24,
  },
  frame15Container: {
    top: 97,
    height: 522,
  },
  rectangle44002: {
    borderRadius: Border.br_3xs,
    backgroundColor: "#1f9b55",
    left: 0,
    top: 0,
  },
  submit: {
    top: 7,
    left: 98,
    fontSize: FontSize.size_xl,
    color: Color.kitchenBG,
    width: 83,
    height: 30,
    textAlign: "center",
  },
  group37342: {
    top: 636,
    left: 40,
  },
  customerProfileFeedback: {
    backgroundColor: Color.kitchenBG,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default CustomerProfileFeedback;
