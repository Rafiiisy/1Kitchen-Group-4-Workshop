import * as React from "react";
import { StyleSheet, View, Text, Image, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border, Padding } from "../GlobalStyles";

const CustomerSearchCategory1 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.customerSearchCategory1}>
      <View style={[styles.top, styles.topLayout]}>
        <View style={[styles.rectangle4428, styles.topLayout]} />
        <Text style={styles.burger}>Burger</Text>
        <Pressable
          style={styles.arrowDownSignToNavigate5}
          onPress={() => navigation.navigate("CustomerSearch")}
        >
          <Image
            style={styles.icon}
            resizeMode="cover"
            source={require("../assets/arrowdownsigntonavigate5.png")}
          />
        </Pressable>
      </View>
      <Text style={styles.didntFindWhat}>
        Didn’t find what you’re looking for?
      </Text>
      <View style={styles.options}>
        <View style={[styles.group37427, styles.groupLayout]}>
          <View style={[styles.rectangle4429, styles.groupLayout]} />
          <Image
            style={styles.iconPosition}
            resizeMode="cover"
            source={require("../assets/mcdonaldslogo11.png")}
          />
          <Text style={styles.mcdonalds}>McDonald’s</Text>
          <Text style={[styles.internationalFast, styles.textTypo]}>
            International | Fast Food
          </Text>
          <Text style={[styles.text, styles.textTypo]}>$ - $$</Text>
        </View>
        <Pressable
          style={[styles.group37426, styles.groupLayout]}
          onPress={() => navigation.navigate("CustomerRestoBurgerKing")}
        >
          <View style={[styles.rectangle4429, styles.groupLayout]} />
          <Text style={styles.mcdonalds}>Burger King</Text>
          <Text style={[styles.internationalFast, styles.textTypo]}>
            International | Fast Food
          </Text>
          <Text style={[styles.text, styles.textTypo]}>$$ - $$$</Text>
          <Image
            style={[styles.burgerking1Icon, styles.iconPosition1]}
            resizeMode="cover"
            source={require("../assets/310burgerking11.png")}
          />
        </Pressable>
        <View style={[styles.group37425, styles.groupLayout]}>
          <View style={[styles.rectangle4429, styles.groupLayout]} />
          <Text style={styles.mcdonalds}>Burger Bangor</Text>
          <Text style={[styles.internationalFast, styles.textTypo]}>
            Burgers | Fast Food
          </Text>
          <Text style={[styles.text, styles.textTypo]}>{`$ `}</Text>
          <Image
            style={[styles.burgerBangorLogoMin1Icon, styles.iconPosition1]}
            resizeMode="cover"
            source={require("../assets/burgerbangorlogomin11.png")}
          />
        </View>
        <View style={[styles.group37424, styles.groupLayout]}>
          <View style={[styles.rectangle4429, styles.groupLayout]} />
          <Text style={styles.mcdonalds}>Burger Bros</Text>
          <Text style={[styles.internationalFast, styles.textTypo]}>
            Burgers | Fast Food
          </Text>
          <Text style={[styles.text, styles.textTypo]}>$ - $$</Text>
          <Image
            style={[styles.bjzosq7a400x4001Icon, styles.iconPosition]}
            resizeMode="cover"
            source={require("../assets/bjzosq7a400x40011.png")}
          />
        </View>
        <View style={[styles.group37423, styles.groupLayout]}>
          <View style={[styles.rectangle4429, styles.groupLayout]} />
          <Text style={styles.mcdonalds}>Wendy’s</Text>
          <Text style={[styles.internationalFast, styles.textTypo]}>
            International | Fast Food
          </Text>
          <Text style={[styles.text, styles.textTypo]}>$$ - $$$</Text>
          <Image
            style={[styles.wendysLogo1Icon, styles.iconPosition1]}
            resizeMode="cover"
            source={require("../assets/wendyslogo11.png")}
          />
        </View>
      </View>
      <View style={styles.frame85}>
        <View style={styles.footer}>
          <View style={styles.homeButton}>
            <Image
              style={styles.vectorHomeIcon}
              resizeMode="cover"
              source={require("../assets/vectorhome1.png")}
            />
            <Text style={[styles.home, styles.homeTypo]}>Home</Text>
          </View>
          <Pressable
            style={[styles.searchButton, styles.buttonSpaceBlock]}
            onPress={() => {}}
          >
            <View style={styles.frame82}>
              <Image
                style={styles.searchvectorIcon}
                resizeMode="cover"
                source={require("../assets/searchvector.png")}
              />
              <Text style={[styles.explore, styles.homeTypo]}>Explore</Text>
            </View>
          </Pressable>
          <View style={[styles.ordersButton, styles.buttonSpaceBlock]}>
            <Image
              style={styles.vectorClockIcon}
              resizeMode="cover"
              source={require("../assets/vectorclock1.png")}
            />
            <Text style={[styles.orders, styles.ordersTypo]}>Orders</Text>
          </View>
          <Pressable
            style={[styles.ordersButton, styles.buttonSpaceBlock]}
            onPress={() => navigation.navigate("CustomerProfile")}
          >
            <Image
              style={styles.vectorUserIcon}
              resizeMode="cover"
              source={require("../assets/vectoruser.png")}
            />
            <Text style={[styles.account, styles.ordersTypo]}>Account</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  topLayout: {
    height: 64,
    width: 360,
    left: 0,
    position: "absolute",
  },
  groupLayout: {
    height: 92,
    width: 360,
    left: 0,
    position: "absolute",
  },
  textTypo: {
    color: Color.grayGray1,
    fontSize: FontSize.caption1Regular12_size,
    left: 92,
    fontFamily: FontFamily.nunitoRegular,
    textAlign: "left",
    position: "absolute",
  },
  iconPosition1: {
    width: 60,
    left: 16,
    position: "absolute",
  },
  iconPosition: {
    height: 60,
    top: 16,
    width: 60,
    left: 16,
    position: "absolute",
  },
  homeTypo: {
    marginTop: 2,
    textAlign: "center",
    color: Color.darkslategray_200,
    fontFamily: FontFamily.caption2Regular11,
    lineHeight: 13,
    letterSpacing: 0,
    fontSize: FontSize.caption2Regular11_size,
  },
  buttonSpaceBlock: {
    marginLeft: 43,
    flex: 1,
  },
  ordersTypo: {
    textAlign: "center",
    color: Color.darkslategray_200,
    fontFamily: FontFamily.caption2Regular11,
    lineHeight: 13,
    letterSpacing: 0,
    fontSize: FontSize.caption2Regular11_size,
  },
  rectangle4428: {
    top: 0,
    backgroundColor: Color.kitchenBG,
  },
  burger: {
    top: 28,
    left: 78,
    fontSize: FontSize.size_5xl,
    display: "flex",
    width: 88,
    height: 27,
    alignItems: "center",
    textAlign: "left",
    color: Color.globalBlack,
    fontFamily: FontFamily.nunitoSemibold,
    fontWeight: "600",
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  arrowDownSignToNavigate5: {
    left: 40,
    top: 34,
    width: 15,
    height: 15,
    position: "absolute",
  },
  top: {
    top: 12,
  },
  didntFindWhat: {
    top: 640,
    left: 70,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.nunitoRegular,
    textAlign: "left",
    color: Color.globalBlack,
    position: "absolute",
  },
  rectangle4429: {
    backgroundColor: Color.globalWhite,
    borderRadius: Border.br_3xs,
    top: 0,
  },
  mcdonalds: {
    fontSize: FontSize.size_base,
    left: 92,
    top: 16,
    textAlign: "left",
    color: Color.globalBlack,
    fontFamily: FontFamily.nunitoSemibold,
    fontWeight: "600",
    position: "absolute",
  },
  internationalFast: {
    top: 41,
  },
  text: {
    top: 60,
  },
  group37427: {
    top: 0,
  },
  burgerking1Icon: {
    top: 14,
    height: 62,
    borderRadius: Border.br_3xs,
  },
  group37426: {
    top: 104,
  },
  burgerBangorLogoMin1Icon: {
    top: 32,
    height: 27,
  },
  group37425: {
    top: 208,
  },
  bjzosq7a400x4001Icon: {
    borderRadius: Border.br_3xs,
  },
  group37424: {
    top: 312,
  },
  wendysLogo1Icon: {
    top: 22,
    height: 55,
  },
  group37423: {
    top: 416,
  },
  options: {
    top: 96,
    height: 508,
    width: 360,
    left: 0,
    position: "absolute",
  },
  vectorHomeIcon: {
    width: 26,
    height: 21,
  },
  home: {
    width: 32,
  },
  homeButton: {
    alignItems: "center",
    flex: 1,
  },
  searchvectorIcon: {
    width: 22,
    height: 22,
  },
  explore: {
    width: 41,
  },
  frame82: {
    alignItems: "center",
  },
  searchButton: {
    padding: Padding.p_3xs,
  },
  vectorClockIcon: {
    width: 23,
    height: 23,
  },
  orders: {
    width: 43,
    marginTop: 3,
  },
  ordersButton: {
    alignItems: "center",
  },
  vectorUserIcon: {
    width: 24,
    height: 24,
  },
  account: {
    width: 54,
  },
  footer: {
    alignSelf: "stretch",
    borderStyle: "solid",
    borderColor: "#f3f3f3",
    borderWidth: 1,
    flexDirection: "row",
    paddingHorizontal: Padding.p_10xl,
    paddingVertical: Padding.p_lgi,
    backgroundColor: Color.globalWhite,
    alignItems: "center",
    overflow: "hidden",
  },
  frame85: {
    top: 705,
    left: -5,
    width: 377,
    justifyContent: "center",
    alignItems: "center",
    position: "absolute",
  },
  customerSearchCategory1: {
    height: 800,
    overflow: "hidden",
    width: "100%",
    flex: 1,
    backgroundColor: Color.kitchenBG,
  },
});

export default CustomerSearchCategory1;
