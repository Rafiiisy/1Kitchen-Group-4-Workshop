import * as React from "react";
import { Image, StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const LogInNope = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.logInNope}>
      <View style={[styles.frame37445, styles.frame37445Layout]}>
        <Image
          style={[styles.ellipse6Icon, styles.frame37445Layout]}
          resizeMode="cover"
          source={require("../assets/ellipse6.png")}
        />
        <Image
          style={styles.kWhite1Icon}
          resizeMode="cover"
          source={require("../assets/1kwhite11.png")}
        />
      </View>
      <Pressable
        style={[styles.frame37443, styles.frameLayout]}
        onPress={() => navigation.navigate("LogInSelection")}
      >
        <View style={[styles.rectangle4400, styles.rectanglePosition]} />
        <Text style={[styles.logIn, styles.logInFlexBox]}>Log In</Text>
      </Pressable>
      <Pressable
        style={[styles.frame37444, styles.frameLayout]}
        onPress={() => navigation.navigate("SignUp")}
      >
        <View style={[styles.rectangle4401, styles.rectanglePosition]} />
        <Text style={[styles.signUp, styles.logInFlexBox]}>Sign Up</Text>
      </Pressable>
      <Text style={[styles.byContinuingYouContainer, styles.logInFlexBox]}>
        {`By continuing, you agree to our `}
        <Text style={styles.termsAndConditions}>Terms and Conditions</Text>
        {` and
`}
        <Text style={styles.termsAndConditions}>Privacy Policy.</Text>
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  frame37445Layout: {
    height: 376,
    width: 714,
    position: "absolute",
  },
  frameLayout: {
    height: 44,
    width: 280,
    left: 40,
    position: "absolute",
  },
  rectanglePosition: {
    borderRadius: Border.br_3xs,
    left: "0%",
    bottom: "0%",
    right: "0%",
    top: "0%",
    height: "100%",
    position: "absolute",
    width: "100%",
  },
  logInFlexBox: {
    textAlign: "center",
    position: "absolute",
  },
  ellipse6Icon: {
    top: 74,
    left: 177,
  },
  kWhite1Icon: {
    top: 164,
    left: 296,
    width: 121,
    height: 107,
    position: "absolute",
  },
  frame37445: {
    top: -74,
    left: -177,
  },
  rectangle4400: {
    backgroundColor: Color.kDarkGreen,
  },
  logIn: {
    width: "24.64%",
    left: "37.86%",
    color: Color.kitchenBG,
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    top: "18.94%",
    height: "68.75%",
    textAlign: "center",
  },
  frame37443: {
    top: 352,
  },
  rectangle4401: {
    borderStyle: "solid",
    borderColor: "#1a6733",
    borderWidth: 2,
  },
  signUp: {
    width: "31.79%",
    left: "34.29%",
    color: Color.kDarkGreen,
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    top: "18.94%",
    height: "68.75%",
    textAlign: "center",
  },
  frame37444: {
    top: 416,
  },
  termsAndConditions: {
    textDecoration: "underline",
  },
  byContinuingYouContainer: {
    top: 696,
    left: 41,
    fontSize: FontSize.caption3Medium10_size,
    fontWeight: "500",
    fontFamily: FontFamily.caption3Medium10,
    color: Color.globalBlack,
  },
  logInNope: {
    backgroundColor: Color.kitchenBG,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default LogInNope;
