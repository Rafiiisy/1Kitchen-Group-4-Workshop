import * as React from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const CustomerOrderSuccession = () => {
  return (
    <View style={styles.customerOrderSuccession}>
      <View style={[styles.frame73container, styles.frame73containerPosition]}>
        <Image
          style={styles.checkcircleIcon}
          resizeMode="cover"
          source={require("../assets/checkcircle.png")}
        />
        <View style={styles.text}>
          <Text style={styles.thankYouFor}>
            Thank you for placing the order
          </Text>
          <Text style={[styles.wellGetTo, styles.button1Typo]}>
            We’ll get to you as soon as possible
          </Text>
        </View>
        <Image
          style={[
            styles.undrawOnTheWayReSwjt1Icon,
            styles.frame73containerPosition,
          ]}
          resizeMode="cover"
          source={require("../assets/undrawonthewayreswjt1.png")}
        />
        <View style={[styles.button, styles.buttonPosition]}>
          <Text style={[styles.button1, styles.button1Typo]}>Go Home</Text>
        </View>
      </View>
      <View style={[styles.homeIndicator, styles.buttonPosition]}>
        <View style={styles.homeIndicator1} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frame73containerPosition: {
    width: 375,
    left: 0,
    position: "absolute",
  },
  button1Typo: {
    lineHeight: 22,
    letterSpacing: 0,
    fontSize: FontSize.bodySemibold17_size,
    textAlign: "center",
  },
  buttonPosition: {
    bottom: 0,
    position: "absolute",
  },
  checkcircleIcon: {
    top: 0,
    left: 148,
    width: 80,
    height: 80,
    position: "absolute",
  },
  thankYouFor: {
    fontSize: FontSize.size_xl,
    letterSpacing: 1,
    lineHeight: 24,
    fontFamily: FontFamily.nunitoBold,
    color: Color.globalBlack,
    textAlign: "center",
    fontWeight: "700",
    alignSelf: "stretch",
  },
  wellGetTo: {
    fontFamily: FontFamily.caption2Regular11,
    color: Color.grayGray1,
    marginTop: 8,
    letterSpacing: 0,
    fontSize: FontSize.bodySemibold17_size,
    alignSelf: "stretch",
  },
  text: {
    top: 88,
    left: 24,
    position: "absolute",
  },
  undrawOnTheWayReSwjt1Icon: {
    top: 255,
    height: 165,
    overflow: "hidden",
  },
  button1: {
    fontFamily: FontFamily.bodySemibold17,
    color: Color.globalWhite,
    fontWeight: "700",
    letterSpacing: 0,
    fontSize: FontSize.bodySemibold17_size,
  },
  button: {
    right: 38,
    borderRadius: Border.br_base,
    backgroundColor: "#34c759",
    flexDirection: "row",
    paddingHorizontal: Padding.p_13xl,
    paddingVertical: Padding.p_xl,
    alignItems: "center",
    justifyContent: "center",
    left: 24,
  },
  frame73container: {
    top: 68,
    height: 618,
  },
  homeIndicator1: {
    marginLeft: -67,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.globalBlack,
    width: 134,
    height: 5,
    display: "none",
    position: "absolute",
  },
  homeIndicator: {
    right: 0,
    height: 34,
    left: 0,
    bottom: 0,
  },
  customerOrderSuccession: {
    backgroundColor: Color.kitchenBG,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default CustomerOrderSuccession;
