import * as React from "react";
import { Image, StyleSheet, Text, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Padding, Color, Border } from "../GlobalStyles";

const CustomerOrder1 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.customerOrder1}>
      <View style={[styles.imgcontainertopBar, styles.barPosition]}>
        <Image
          style={[styles.imageIcon, styles.iconLayout1]}
          resizeMode="cover"
          source={require("../assets/image.png")}
        />
        <Text style={[styles.dailyDeli, styles.skipTypo]}>
          Daily Deli - Johar Town
        </Text>
        <Text style={[styles.chickenFajitaPizza, styles.text1Typo]}>
          Chicken Fajita Pizza
        </Text>
      </View>
      <View style={[styles.appBar, styles.barPosition]}>
        <View style={[styles.bg, styles.bgPosition]} />
        <Text style={[styles.headline, styles.writeTypo]}>Daily Deli</Text>
        <Pressable
          style={[styles.arrowleft, styles.iconLayout]}
          onPress={() => navigation.navigate("CustomerOrderMain")}
        >
          <Image
            style={styles.icon}
            resizeMode="cover"
            source={require("../assets/arrowleft1.png")}
          />
        </Pressable>
        <View style={[styles.textOrButtons, styles.headlinePosition]}>
          <Text style={[styles.skip, styles.skipTypo]}>Skip</Text>
          <View style={[styles.buttons, styles.buttonsFlexBox]}>
            <Image
              style={styles.iconLayout}
              resizeMode="cover"
              source={require("../assets/heart1.png")}
            />
            <Image
              style={[styles.sharenetworkIcon, styles.iconLayout]}
              resizeMode="cover"
              source={require("../assets/sharenetwork1.png")}
            />
            <Image
              style={[styles.sharenetworkIcon, styles.iconLayout]}
              resizeMode="cover"
              source={require("../assets/dotsthreevertical1.png")}
            />
          </View>
        </View>
      </View>
      <View style={styles.frame70container}>
        <View style={[styles.content, styles.barPosition1]}>
          <View style={styles.variation}>
            <View style={[styles.title, styles.titleSpaceBlock]}>
              <Text style={[styles.variation1, styles.quanityTypo]}>
                Variation
              </Text>
              <Text style={[styles.required, styles.requiredTypo]}>
                Required
              </Text>
            </View>
            <View style={styles.list}>
              <View style={styles.listGeneral}>
                <View style={[styles.container, styles.containerSpaceBlock]}>
                  <View style={[styles.radioButtons, styles.iconLayout]}>
                    <View style={[styles.vector, styles.bgPosition]} />
                    <Image
                      style={[styles.vectorIcon, styles.iconLayout1]}
                      resizeMode="cover"
                      source={require("../assets/vector.png")}
                    />
                  </View>
                  <Text style={[styles.label, styles.writeTypo]}>8”</Text>
                  <View style={[styles.trailingContent, styles.buttonsFlexBox]}>
                    <Text style={[styles.trailingText, styles.requiredTypo]}>
                      $10
                    </Text>
                  </View>
                </View>
                <Image
                  style={styles.dividerIcon}
                  resizeMode="cover"
                  source={require("../assets/divider.png")}
                />
              </View>
              <View style={styles.listGeneral}>
                <View style={[styles.container, styles.containerSpaceBlock]}>
                  <View style={[styles.radioButtons, styles.iconLayout]}>
                    <View style={[styles.vector, styles.bgPosition]} />
                    <Image
                      style={[styles.vectorIcon, styles.iconLayout1]}
                      resizeMode="cover"
                      source={require("../assets/vector1.png")}
                    />
                  </View>
                  <Text style={[styles.label, styles.writeTypo]}>10”</Text>
                  <View style={[styles.trailingContent, styles.buttonsFlexBox]}>
                    <Text style={[styles.trailingText, styles.requiredTypo]}>
                      $12
                    </Text>
                  </View>
                </View>
                <Image
                  style={styles.dividerIcon}
                  resizeMode="cover"
                  source={require("../assets/divider.png")}
                />
              </View>
              <View style={styles.listGeneral}>
                <View style={[styles.container, styles.containerSpaceBlock]}>
                  <View style={[styles.radioButtons, styles.iconLayout]}>
                    <View style={[styles.vector, styles.bgPosition]} />
                    <Image
                      style={[styles.vectorIcon, styles.iconLayout1]}
                      resizeMode="cover"
                      source={require("../assets/vector.png")}
                    />
                  </View>
                  <Text style={[styles.label, styles.writeTypo]}>12”</Text>
                  <View style={[styles.trailingContent, styles.buttonsFlexBox]}>
                    <Text style={[styles.trailingText, styles.requiredTypo]}>
                      $16
                    </Text>
                  </View>
                </View>
                <Image
                  style={styles.dividerIcon}
                  resizeMode="cover"
                  source={require("../assets/divider.png")}
                />
              </View>
            </View>
          </View>
          <View style={styles.spacer}>
            <View style={[styles.spacer1, styles.bgPosition]} />
          </View>
          <View style={[styles.instructions, styles.titleSpaceBlock]}>
            <View style={styles.title1}>
              <Text style={[styles.quanity, styles.quanityTypo]}>Quanity</Text>
              <Text style={[styles.quanity1, styles.quanity1FlexBox]}>
                Quanity
              </Text>
            </View>
            <View style={[styles.textField, styles.buttonSpaceBlock]}>
              <Image
                style={styles.iconLayout}
                resizeMode="cover"
                source={require("../assets/minus.png")}
              />
              <Text style={[styles.text, styles.textTypo]}>01</Text>
              <Image
                style={[styles.plusIcon, styles.iconLayout]}
                resizeMode="cover"
                source={require("../assets/plus.png")}
              />
            </View>
          </View>
          <View style={styles.spacer}>
            <View style={[styles.spacer1, styles.bgPosition]} />
          </View>
          <View style={styles.variation}>
            <View style={[styles.title, styles.titleSpaceBlock]}>
              <Text style={[styles.variation1, styles.quanityTypo]}>
                Extra Sauce
              </Text>
              <Text style={[styles.required1, styles.requiredTypo]}>
                Required
              </Text>
            </View>
            <View style={styles.list}>
              <View style={styles.listGeneral}>
                <View style={[styles.container, styles.containerSpaceBlock]}>
                  <Image
                    style={styles.iconLayout}
                    resizeMode="cover"
                    source={require("../assets/checkbox.png")}
                  />
                  <Text style={[styles.label, styles.writeTypo]}>
                    Texas Barbeque
                  </Text>
                  <View style={[styles.trailingContent, styles.buttonsFlexBox]}>
                    <Text style={[styles.trailingText, styles.requiredTypo]}>
                      +$6
                    </Text>
                  </View>
                </View>
                <Image
                  style={styles.dividerIcon}
                  resizeMode="cover"
                  source={require("../assets/divider.png")}
                />
              </View>
              <View style={styles.listGeneral}>
                <View style={[styles.container, styles.containerSpaceBlock]}>
                  <Image
                    style={styles.iconLayout}
                    resizeMode="cover"
                    source={require("../assets/checkbox1.png")}
                  />
                  <Text style={[styles.label, styles.writeTypo]}>
                    Char Donay
                  </Text>
                  <View style={[styles.trailingContent, styles.buttonsFlexBox]}>
                    <Text style={[styles.trailingText, styles.requiredTypo]}>
                      +$8
                    </Text>
                  </View>
                </View>
                <Image
                  style={styles.dividerIcon}
                  resizeMode="cover"
                  source={require("../assets/divider.png")}
                />
              </View>
            </View>
          </View>
          <View style={styles.spacer}>
            <View style={[styles.spacer1, styles.bgPosition]} />
          </View>
          <View style={[styles.instructions, styles.titleSpaceBlock]}>
            <View style={styles.title1}>
              <Text style={[styles.quanity, styles.quanityTypo]}>
                Instructions
              </Text>
              <Text style={[styles.letUsKnow, styles.quanity1FlexBox]}>
                Let us know if you have specific things in mind
              </Text>
            </View>
            <View style={[styles.textField, styles.buttonSpaceBlock]}>
              <Text style={[styles.writeTextHere, styles.writeTypo]}>
                e.g. less spices, no mayo etc
              </Text>
            </View>
          </View>
          <View style={styles.spacer}>
            <View style={[styles.spacer1, styles.bgPosition]} />
          </View>
          <View style={[styles.instructions, styles.titleSpaceBlock]}>
            <View style={styles.title1}>
              <Text style={[styles.instructions4, styles.text1Typo]}>
                Instructions
              </Text>
              <Text style={[styles.ifTheProduct, styles.quanity1FlexBox]}>
                If the product is not available
              </Text>
            </View>
            <View style={[styles.textField, styles.buttonSpaceBlock]}>
              <Text style={[styles.writeTextHere1, styles.writeTypo]}>
                Remove it from my order
              </Text>
              <Image
                style={[styles.plusIcon, styles.iconLayout]}
                resizeMode="cover"
                source={require("../assets/caretdown.png")}
              />
            </View>
          </View>
        </View>
      </View>
      <View style={styles.frame69layer}>
        <View style={[styles.cartBottomBar, styles.buttonFlexBox]}>
          <Text style={[styles.text1, styles.text1Typo]}>$20</Text>
          <Pressable
            style={[styles.button, styles.buttonFlexBox]}
            onPress={() => navigation.navigate("CustomerOrderCart")}
          >
            <Text style={[styles.button1, styles.textTypo]}>Add to cart</Text>
          </Pressable>
        </View>
      </View>
      <View style={[styles.homeIndicator, styles.cartBottomBarPosition]}>
        <View style={styles.homeIndicator1} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  barPosition: {
    right: 0,
    left: 0,
  },
  iconLayout1: {
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  skipTypo: {
    textAlign: "left",
    fontFamily: FontFamily.caption2Regular11,
    letterSpacing: 0,
  },
  text1Typo: {
    fontFamily: FontFamily.bodySemibold17,
    fontWeight: "700",
  },
  bgPosition: {
    left: "0%",
    right: "0%",
    top: "0%",
    width: "100%",
  },
  writeTypo: {
    lineHeight: 22,
    fontSize: FontSize.bodySemibold17_size,
    textAlign: "left",
    letterSpacing: 0,
  },
  iconLayout: {
    height: 22,
    width: 22,
  },
  headlinePosition: {
    top: "50%",
    position: "absolute",
  },
  buttonsFlexBox: {
    justifyContent: "flex-end",
    alignItems: "center",
    flexDirection: "row",
  },
  barPosition1: {
    top: 0,
    position: "absolute",
  },
  titleSpaceBlock: {
    paddingRight: Padding.p_4xl,
    paddingLeft: Padding.p_5xl,
    alignSelf: "stretch",
  },
  quanityTypo: {
    fontFamily: FontFamily.nunitoBold,
    lineHeight: 24,
    fontSize: FontSize.size_xl,
    color: Color.globalBlack,
    fontWeight: "700",
    letterSpacing: 1,
    textAlign: "left",
  },
  requiredTypo: {
    textAlign: "right",
    fontFamily: FontFamily.nunitoRegular,
    lineHeight: 22,
    fontSize: FontSize.bodySemibold17_size,
    letterSpacing: 0,
  },
  containerSpaceBlock: {
    paddingTop: Padding.p_base,
    paddingRight: Padding.p_4xl,
    paddingLeft: Padding.p_5xl,
  },
  quanity1FlexBox: {
    marginTop: 4,
    alignSelf: "stretch",
    lineHeight: 22,
    fontSize: FontSize.bodySemibold17_size,
    textAlign: "left",
    letterSpacing: 0,
  },
  buttonSpaceBlock: {
    paddingVertical: Padding.p_base,
    paddingHorizontal: Padding.p_5xl,
    borderRadius: Border.br_base,
  },
  textTypo: {
    textAlign: "center",
    lineHeight: 22,
    fontSize: FontSize.bodySemibold17_size,
    letterSpacing: 0,
  },
  buttonFlexBox: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  cartBottomBarPosition: {
    bottom: 0,
    position: "absolute",
  },
  imageIcon: {
    left: "0%",
    right: "0%",
    top: "0%",
    width: "100%",
    bottom: "0%",
    height: "100%",
  },
  dailyDeli: {
    bottom: 21,
    fontSize: FontSize.subheadlineRegular15_size,
    lineHeight: 20,
    color: Color.globalWhite,
    left: 24,
    position: "absolute",
  },
  chickenFajitaPizza: {
    bottom: 45,
    lineHeight: 28,
    fontSize: FontSize.title2Bold22_size,
    fontWeight: "700",
    letterSpacing: 1,
    textAlign: "left",
    color: Color.globalWhite,
    left: 24,
    position: "absolute",
  },
  imgcontainertopBar: {
    height: 200,
    left: 0,
    top: 0,
    position: "absolute",
    overflow: "hidden",
  },
  bg: {
    height: "181.82%",
    bottom: "-81.82%",
    left: "0%",
    right: "0%",
    top: "0%",
    position: "absolute",
  },
  headline: {
    marginLeft: -130,
    display: "none",
    left: "50%",
    top: "50%",
    position: "absolute",
    marginTop: 6,
    fontFamily: FontFamily.bodySemibold17,
    fontWeight: "700",
    color: Color.globalWhite,
  },
  icon: {
    marginTop: 6,
    height: "100%",
    width: "100%",
  },
  arrowleft: {
    top: "50%",
    position: "absolute",
    left: 24,
  },
  skip: {
    fontSize: FontSize.footnoteRegular13_size,
    lineHeight: 18,
    color: Color.grayGray1,
    display: "none",
  },
  sharenetworkIcon: {
    marginLeft: 16,
  },
  buttons: {
    marginLeft: 8,
  },
  textOrButtons: {
    right: 23,
    flexDirection: "row",
    marginTop: 6,
  },
  appBar: {
    shadowColor: "rgba(0, 0, 0, 0.08)",
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowRadius: 24,
    elevation: 24,
    shadowOpacity: 1,
    height: 88,
    left: 0,
    top: 0,
    position: "absolute",
  },
  variation1: {
    color: Color.globalBlack,
    flex: 1,
  },
  required: {
    color: Color.mediumseagreen_200,
  },
  title: {
    alignItems: "center",
    flexDirection: "row",
  },
  vector: {
    bottom: "0%",
    left: "0%",
    right: "0%",
    top: "0%",
    height: "100%",
    position: "absolute",
  },
  vectorIcon: {
    height: "83.33%",
    width: "83.33%",
    top: "8.33%",
    right: "8.33%",
    bottom: "8.33%",
    left: "8.33%",
  },
  radioButtons: {
    overflow: "hidden",
  },
  label: {
    marginLeft: 12,
    fontFamily: FontFamily.nunitoRegular,
    color: Color.globalBlack,
    flex: 1,
  },
  trailingText: {
    color: Color.grayGray1,
    flex: 1,
  },
  trailingContent: {
    marginLeft: 12,
  },
  container: {
    paddingBottom: Padding.p_base,
    backgroundColor: Color.globalWhite,
    alignSelf: "stretch",
    alignItems: "center",
    flexDirection: "row",
  },
  dividerIcon: {
    height: 1,
    alignSelf: "stretch",
    maxWidth: "100%",
    overflow: "hidden",
    width: "100%",
  },
  listGeneral: {
    width: 375,
  },
  list: {
    marginTop: 8,
    alignSelf: "stretch",
  },
  variation: {
    paddingTop: Padding.p_5xl,
    alignSelf: "stretch",
  },
  spacer1: {
    backgroundColor: Color.grayGray6,
    bottom: "0%",
    left: "0%",
    right: "0%",
    top: "0%",
    height: "100%",
    position: "absolute",
  },
  spacer: {
    height: 8,
    alignSelf: "stretch",
  },
  quanity: {
    color: Color.globalBlack,
    alignSelf: "stretch",
  },
  quanity1: {
    color: Color.globalBlack,
    display: "none",
    fontFamily: FontFamily.bodySemibold17,
    fontWeight: "700",
  },
  title1: {
    alignSelf: "stretch",
    alignItems: "center",
  },
  text: {
    fontFamily: FontFamily.nunitoRegular,
    color: Color.globalBlack,
    marginLeft: 8,
    flex: 1,
  },
  plusIcon: {
    marginLeft: 8,
  },
  textField: {
    borderStyle: "solid",
    borderColor: "#f2f2f7",
    borderWidth: 1,
    marginTop: 16,
    backgroundColor: Color.globalWhite,
    alignSelf: "stretch",
    alignItems: "center",
    flexDirection: "row",
  },
  instructions: {
    paddingBottom: Padding.p_5xl,
    paddingTop: Padding.p_5xl,
  },
  required1: {
    color: Color.globalPrimary,
    display: "none",
  },
  letUsKnow: {
    fontFamily: FontFamily.nunitoRegular,
    color: Color.grayGray1,
  },
  writeTextHere: {
    color: Color.grayGray2,
    fontFamily: FontFamily.nunitoRegular,
    flex: 1,
  },
  instructions4: {
    color: Color.globalBlack,
    alignSelf: "stretch",
    display: "none",
    lineHeight: 28,
    fontSize: FontSize.title2Bold22_size,
    fontWeight: "700",
    letterSpacing: 1,
    textAlign: "left",
  },
  ifTheProduct: {
    color: Color.globalBlack,
    fontFamily: FontFamily.bodySemibold17,
    fontWeight: "700",
  },
  writeTextHere1: {
    fontFamily: FontFamily.nunitoRegular,
    color: Color.globalBlack,
    flex: 1,
  },
  content: {
    width: 375,
    left: 0,
  },
  frame70container: {
    top: 200,
    height: 886,
    width: 375,
    left: 0,
    position: "absolute",
  },
  text1: {
    fontSize: FontSize.title1Bold28_size,
    color: Color.globalBlack,
    letterSpacing: 1,
    fontWeight: "700",
    textAlign: "left",
    flex: 1,
  },
  button1: {
    fontFamily: FontFamily.bodySemibold17,
    fontWeight: "700",
    color: Color.globalWhite,
  },
  button: {
    backgroundColor: Color.mediumseagreen_200,
    marginLeft: 24,
    paddingVertical: Padding.p_base,
    paddingHorizontal: Padding.p_5xl,
    borderRadius: Border.br_base,
  },
  cartBottomBar: {
    marginLeft: -187.5,
    backgroundColor: "rgba(255, 255, 255, 0.9)",
    paddingBottom: 34,
    bottom: 0,
    position: "absolute",
    paddingTop: Padding.p_base,
    paddingRight: Padding.p_4xl,
    paddingLeft: Padding.p_5xl,
    width: 375,
    left: "50%",
    overflow: "hidden",
  },
  frame69layer: {
    top: 1126,
    left: -8,
    height: 104,
    width: 375,
    position: "absolute",
  },
  homeIndicator1: {
    marginLeft: -67,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.globalBlack,
    width: 134,
    height: 5,
    display: "none",
    left: "50%",
    position: "absolute",
  },
  homeIndicator: {
    height: 34,
    left: 0,
    right: 0,
  },
  customerOrder1: {
    backgroundColor: Color.kitchenBG,
    height: 1230,
    overflow: "hidden",
    width: "100%",
    flex: 1,
  },
});

export default CustomerOrder1;
