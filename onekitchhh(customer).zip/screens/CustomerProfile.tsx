import * as React from "react";
import { Image, StyleSheet, View, Pressable, Text } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontSize, Color, FontFamily, Border } from "../GlobalStyles";

const CustomerProfile = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.customerProfile}>
      <View style={[styles.frame9ContainerTopBar, styles.containerPosition]}>
        <Pressable
          style={styles.frame25Actiongobacklaye}
          onPress={() => navigation.navigate("CustomerHome")}
        >
          <Image
            style={styles.icons8Close301}
            resizeMode="cover"
            source={require("../assets/icons8close301.png")}
          />
        </Pressable>
      </View>
      <Pressable
        style={[styles.logoutActionlogoutfirebase, styles.group37294Layout]}
        onPress={() => navigation.navigate("Login1")}
      >
        <View style={[styles.group37294, styles.group37294Layout]}>
          <Pressable
            style={[styles.rectangle4400, styles.group37294Layout]}
            onPress={() => navigation.navigate("LogInNope")}
          />
          <Text style={[styles.signOut, styles.signOutLayout]}>Sign Out</Text>
        </View>
      </Pressable>
      <View style={[styles.frame11Container, styles.containerPosition]}>
        <View style={[styles.line5, styles.lineLayout]} />
        <Pressable
          style={styles.iconEdit}
          onPress={() => navigation.navigate("CustomerProfileEditProfile")}
        >
          <Image
            style={[styles.icon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/iconedit.png")}
          />
        </Pressable>
        <View style={[styles.line6, styles.lineLayout]} />
        <View style={[styles.line7, styles.lineLayout]} />
        <View style={[styles.line8, styles.linePosition]} />
        <View style={[styles.line11, styles.linePosition]} />
        <View style={[styles.line9, styles.linePosition]} />
        <View style={[styles.group37355, styles.groupLayout1]}>
          <Image
            style={[styles.privacy1Icon, styles.signOutLayout]}
            resizeMode="cover"
            source={require("../assets/privacy1.png")}
          />
          <View style={[styles.group37332, styles.groupLayout]}>
            <Text
              style={[styles.privacySecurity, styles.paymentMethodsTypo]}
            >{`Privacy & Security`}</Text>
          </View>
          <Image
            style={[
              styles.arrowDownSignToNavigate7Icon,
              styles.arrowIconLayout,
            ]}
            resizeMode="cover"
            source={require("../assets/arrowdownsigntonavigate7.png")}
          />
        </View>
        <Pressable
          style={[styles.group37354, styles.groupLayout1]}
          onPress={() => navigation.navigate("CustomerProfileFeedback")}
        >
          <Text style={[styles.supportAndFeedback, styles.paymentMethodsTypo]}>
            Support and Feedback
          </Text>
          <Pressable
            style={styles.arrowPosition}
            onPress={() => navigation.navigate("CustomerProfileFeedback")}
          >
            <Image
              style={[styles.icon, styles.iconLayout]}
              resizeMode="cover"
              source={require("../assets/arrowdownsigntonavigate7.png")}
            />
          </Pressable>
          <View style={[styles.support1, styles.iconPosition]}>
            <Image
              style={[styles.support1Icon, styles.iconPosition]}
              resizeMode="cover"
              source={require("../assets/support1.png")}
            />
          </View>
        </Pressable>
        <View style={[styles.group37352, styles.groupLayout1]}>
          <Image
            style={[styles.privacy1Icon, styles.signOutLayout]}
            resizeMode="cover"
            source={require("../assets/wallet1.png")}
          />
          <Text style={[styles.paymentMethods, styles.paymentMethodsTypo]}>
            Payment Methods
          </Text>
          <Image
            style={[
              styles.arrowDownSignToNavigate7Icon,
              styles.arrowIconLayout,
            ]}
            resizeMode="cover"
            source={require("../assets/arrowdownsigntonavigate7.png")}
          />
        </View>
        <View style={[styles.group37357, styles.groupLayout1]}>
          <Text style={[styles.supportAndFeedback, styles.paymentMethodsTypo]}>
            Orders
          </Text>
          <Image
            style={[styles.arrowDownSignToNavigate5Icon, styles.arrowPosition]}
            resizeMode="cover"
            source={require("../assets/arrowdownsigntonavigate7.png")}
          />
          <Image
            style={[styles.online1Icon, styles.iconPosition]}
            resizeMode="cover"
            source={require("../assets/online1.png")}
          />
        </View>
        <View style={[styles.group37353, styles.groupLayout]}>
          <Text style={[styles.privacySecurity, styles.paymentMethodsTypo]}>
            Invite Friends
          </Text>
          <Image
            style={[
              styles.arrowDownSignToNavigate9Icon,
              styles.arrowIconLayout,
            ]}
            resizeMode="cover"
            source={require("../assets/arrowdownsigntonavigate7.png")}
          />
        </View>
        <View style={[styles.group37356, styles.groupLayout1]}>
          <Text style={[styles.paymentMethods, styles.paymentMethodsTypo]}>
            Location
          </Text>
          <Image
            style={[
              styles.arrowDownSignToNavigate7Icon,
              styles.arrowIconLayout,
            ]}
            resizeMode="cover"
            source={require("../assets/arrowdownsigntonavigate7.png")}
          />
          <Image
            style={[styles.privacy1Icon, styles.signOutLayout]}
            resizeMode="cover"
            source={require("../assets/location1.png")}
          />
        </View>
        <Image
          style={[styles.iconPeople, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/iconpeople.png")}
        />
        <View style={[styles.group37328, styles.group37328Layout]}>
          <Text style={[styles.spongeBob, styles.signOutTypo]}>Sponge Bob</Text>
          <Text style={[styles.blockBPhase, styles.group37328Layout]}>
            Block B Phase 2 Johar Town, Lahore
          </Text>
        </View>
        <Image
          style={styles.avatarIcon}
          resizeMode="cover"
          source={require("../assets/avatar1.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  containerPosition: {
    width: 360,
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  group37294Layout: {
    height: 44,
    width: 280,
    position: "absolute",
  },
  signOutLayout: {
    height: 30,
    position: "absolute",
  },
  lineLayout: {
    height: 1,
    width: 312,
    borderTopWidth: 1,
    borderColor: "#8c8c8c",
    borderStyle: "solid",
    position: "absolute",
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  linePosition: {
    left: 25,
    height: 1,
    width: 312,
    borderTopWidth: 1,
    borderColor: "#8c8c8c",
    borderStyle: "solid",
    position: "absolute",
  },
  groupLayout1: {
    width: 304,
    left: 32,
    height: 30,
    position: "absolute",
  },
  groupLayout: {
    height: 22,
    position: "absolute",
  },
  paymentMethodsTypo: {
    fontSize: FontSize.size_base,
    color: Color.globalBlack,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  arrowIconLayout: {
    height: 15,
    width: 15,
    position: "absolute",
  },
  iconPosition: {
    left: "0%",
    bottom: "0%",
    top: "0%",
    height: "100%",
    position: "absolute",
  },
  arrowPosition: {
    height: "50%",
    width: "4.93%",
    bottom: "26.67%",
    right: "0%",
    top: "23.33%",
    left: "95.07%",
    position: "absolute",
  },
  group37328Layout: {
    width: 294,
    position: "absolute",
  },
  signOutTypo: {
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
  },
  icons8Close301: {
    top: 10,
    left: 16,
    width: 20,
    height: 20,
    position: "absolute",
  },
  frame25Actiongobacklaye: {
    top: 14,
    width: 53,
    height: 39,
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  frame9ContainerTopBar: {
    height: 53,
    top: 0,
  },
  rectangle4400: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.kDarkGreen,
    left: 0,
    top: 0,
  },
  signOut: {
    left: 98,
    color: Color.kitchenBG,
    width: 83,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    top: 7,
  },
  group37294: {
    left: 0,
    top: 0,
  },
  logoutActionlogoutfirebase: {
    top: 508,
    left: 40,
  },
  line5: {
    top: 87,
    left: 22,
    height: 1,
    width: 312,
    borderTopWidth: 1,
    borderColor: "#8c8c8c",
    borderStyle: "solid",
  },
  icon: {
    height: "100%",
    maxWidth: "100%",
    width: "100%",
  },
  iconEdit: {
    left: "86.67%",
    top: "1.67%",
    right: "7.36%",
    bottom: "93.21%",
    width: "5.97%",
    height: "5.12%",
    position: "absolute",
  },
  line6: {
    top: 141,
    left: 21,
  },
  line7: {
    top: 195,
    left: 22,
    height: 1,
    width: 312,
    borderTopWidth: 1,
    borderColor: "#8c8c8c",
    borderStyle: "solid",
  },
  line8: {
    top: 303,
  },
  line11: {
    top: 249,
  },
  line9: {
    top: 357,
  },
  privacy1Icon: {
    width: 30,
    left: 0,
    top: 0,
  },
  privacySecurity: {
    color: Color.globalBlack,
    left: 0,
    top: 0,
  },
  group37332: {
    width: 135,
    left: 45,
    top: 4,
  },
  arrowDownSignToNavigate7Icon: {
    left: 289,
    top: 7,
  },
  group37355: {
    top: 207,
  },
  supportAndFeedback: {
    top: "13.33%",
    left: "14.47%",
    color: Color.globalBlack,
  },
  support1Icon: {
    bottom: "0%",
    top: "0%",
    right: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    width: "100%",
  },
  support1: {
    right: "90.13%",
    width: "9.87%",
    bottom: "0%",
    top: "0%",
  },
  group37354: {
    top: 261,
  },
  paymentMethods: {
    color: Color.globalBlack,
    left: 45,
    top: 4,
  },
  group37352: {
    top: 369,
  },
  arrowDownSignToNavigate5Icon: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  online1Icon: {
    right: "90.13%",
    width: "9.87%",
    bottom: "0%",
    top: "0%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  group37357: {
    top: 99,
  },
  arrowDownSignToNavigate9Icon: {
    left: 244,
    top: 4,
    height: 15,
    width: 15,
  },
  group37353: {
    top: 318,
    left: 77,
    width: 259,
  },
  group37356: {
    top: 153,
  },
  iconPeople: {
    height: "7.62%",
    width: "8.87%",
    top: "74.52%",
    right: "82.52%",
    bottom: "17.86%",
    left: "8.61%",
    position: "absolute",
  },
  spongeBob: {
    color: Color.gray_500,
    width: 114,
    height: 32,
    left: 0,
    top: 0,
    position: "absolute",
  },
  blockBPhase: {
    marginTop: 1,
    marginLeft: -147,
    top: "50%",
    left: "50%",
    fontSize: FontSize.caption2Regular11_size,
    letterSpacing: 0,
    lineHeight: 22,
    fontFamily: FontFamily.caption2Regular11,
    textAlign: "left",
    color: Color.globalBlack,
  },
  group37328: {
    top: 21,
    left: 119,
    height: 46,
  },
  avatarIcon: {
    top: 16,
    left: 48,
    width: 56,
    height: 56,
    position: "absolute",
  },
  frame11Container: {
    top: 53,
    height: 420,
  },
  customerProfile: {
    backgroundColor: Color.kitchenBG,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default CustomerProfile;
