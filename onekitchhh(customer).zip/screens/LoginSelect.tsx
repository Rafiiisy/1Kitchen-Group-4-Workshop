import * as React from "react";
import { Text, StyleSheet, View, Pressable, Image } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Border, Padding } from "../GlobalStyles";

const LoginSelect = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.loginSelect}>
      <View style={styles.welcome}>
        <Text style={[styles.welcome1, styles.welcome1Typo]}>Welcome!</Text>
        <Text style={[styles.pleaseChooseAccordingly, styles.welcome1Typo]}>
          Please choose accordingly!
        </Text>
      </View>
      <View style={styles.options}>
        <Pressable
          style={styles.customer}
          onPress={() => navigation.navigate("Login")}
        >
          <Image
            style={styles.icons8ShoppingCart901}
            resizeMode="cover"
            source={require("../assets/icons8shoppingcart901.png")}
          />
          <Text style={styles.driver1Typo}>Customer</Text>
        </Pressable>
        <Pressable
          style={styles.merchant}
          onPress={() => navigation.navigate("LogInNope")}
        >
          <Image
            style={styles.avd437689ef3a02914ac11Icon}
            resizeMode="cover"
            source={require("../assets/avd437689ef3a02914ac11.png")}
          />
          <Text style={styles.driver1Typo}>Merchant</Text>
        </Pressable>
        <Pressable
          style={styles.driver}
          onPress={() => navigation.navigate("Login")}
        >
          <Image
            style={styles.icon}
            resizeMode="cover"
            source={require("../assets/45672181.png")}
          />
          <Text style={[styles.driver1, styles.driver1Typo]}>Driver</Text>
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  welcome1Typo: {
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  driver1Typo: {
    textAlign: "left",
    fontSize: FontSize.size_lg,
    color: Color.globalBlack,
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
  },
  welcome1: {
    top: 0,
    left: 16,
    fontSize: FontSize.size_17xl,
    color: Color.globalBlack,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  pleaseChooseAccordingly: {
    top: 53,
    left: 0,
    fontSize: FontSize.size_base,
    color: Color.kDarkGreen,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  welcome: {
    width: 199,
    height: 75,
  },
  icons8ShoppingCart901: {
    width: 75,
    height: 75,
  },
  customer: {
    alignItems: "center",
  },
  avd437689ef3a02914ac11Icon: {
    width: 80,
    height: 77,
  },
  merchant: {
    alignItems: "flex-end",
    marginTop: 32,
  },
  icon: {
    width: 60,
    height: 61,
  },
  driver1: {
    marginTop: 5,
  },
  driver: {
    marginTop: 32,
    alignItems: "center",
  },
  options: {
    justifyContent: "center",
    marginTop: 79,
    alignItems: "center",
  },
  loginSelect: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.gray_300,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    paddingHorizontal: 80,
    paddingVertical: Padding.p_17xl,
    alignItems: "center",
  },
});

export default LoginSelect;
