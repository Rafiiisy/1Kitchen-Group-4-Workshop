import * as React from "react";
import { Image, StyleSheet, Text, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, Border, FontSize } from "../GlobalStyles";

const CustomerHomeCategory3 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.customerHomeCategory3}>
      <Image
        style={styles.ellipse6Icon}
        resizeMode="cover"
        source={require("../assets/ellipse62.png")}
      />
      <Image
        style={styles.rectangle11Icon}
        resizeMode="cover"
        source={require("../assets/rectangle11.png")}
      />
      <Text
        style={[styles.fastFoodBeveragesContainer, styles.popularNowFlexBox]}
      >
        <Text style={[styles.fastFood, styles.popularTypo]}>{`FAST FOOD
`}</Text>
        <Text style={styles.beverages}>Beverages</Text>
      </Text>
      <Text style={[styles.popularNow, styles.popularNowPosition]}>
        <Text style={[styles.popular, styles.popularTypo]}>{`Popular `}</Text>
        <Text style={styles.now}>Now</Text>
      </Text>
      <View style={[styles.rectangle10, styles.popularNowPosition]} />
      <Text style={[styles.chickenManchurian, styles.chineseCuisinePosition]}>
        Chicken Manchurian
      </Text>
      <Text style={[styles.chineseCuisine, styles.chineseCuisinePosition]}>
        Chinese Cuisine
      </Text>
      <View style={styles.rectangle11} />
      <Image
        style={styles.vector3Icon}
        resizeMode="cover"
        source={require("../assets/vector3.png")}
      />
      <Text style={styles.text}>$110.50</Text>
      <Pressable
        style={styles.group37377}
        onPress={() => navigation.navigate("CustomerHomeCategory1")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/group373771.png")}
        />
      </Pressable>
      <Image
        style={[
          styles.customerHomeCategory3Child,
          styles.fastFoodBeveragesContainerPosition,
        ]}
        resizeMode="cover"
        source={require("../assets/frame-4.png")}
      />
      <View style={styles.frame58containersliderhori}>
        <View style={[styles.riceCard, styles.cardLayout]}>
          <Image
            style={[styles.riceCard, styles.cardLayout]}
            resizeMode="cover"
            source={require("../assets/chineserice.png")}
          />
          <View style={[styles.group1, styles.groupLayout]}>
            <View style={[styles.orice, styles.oriceLayout]}>
              <View style={[styles.rectangle8, styles.rectangleBg]} />
              <Text style={[styles.text1, styles.textTypo]}>$180.35</Text>
            </View>
            <View style={[styles.addButton, styles.rectangleLayout]}>
              <View style={[styles.rectangle9, styles.rectangleLayout]} />
              <Text style={[styles.text2, styles.textPosition]}>+</Text>
            </View>
          </View>
        </View>
        <View style={[styles.zingerCard, styles.cardLayout]}>
          <Image
            style={[styles.riceCard, styles.cardLayout]}
            resizeMode="cover"
            source={require("../assets/maskgroup3.png")}
          />
          <View style={[styles.group11, styles.groupLayout]}>
            <View style={[styles.orice, styles.oriceLayout]}>
              <View style={[styles.rectangle8, styles.rectangleBg]} />
              <Text style={[styles.text3, styles.textTypo]}>$50.50</Text>
            </View>
            <View style={[styles.addButton, styles.rectangleLayout]}>
              <View style={[styles.rectangle91, styles.rectangleLayout]} />
              <Text style={[styles.text4, styles.textPosition]}>+</Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  popularNowFlexBox: {
    textAlign: "left",
    color: Color.gray1,
  },
  popularTypo: {
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
  },
  popularNowPosition: {
    left: 18,
    position: "absolute",
  },
  chineseCuisinePosition: {
    width: 177,
    left: 116,
    textAlign: "left",
    position: "absolute",
  },
  fastFoodBeveragesContainerPosition: {
    left: 17,
    position: "absolute",
  },
  cardLayout: {
    width: 194,
    height: 286,
    top: 0,
    position: "absolute",
  },
  groupLayout: {
    height: 34,
    width: 167,
    top: 240,
    position: "absolute",
  },
  oriceLayout: {
    width: 123,
    height: 34,
    top: 0,
    position: "absolute",
  },
  rectangleBg: {
    backgroundColor: Color.globalWhite,
    borderRadius: Border.br_8xs,
    left: 0,
  },
  textTypo: {
    color: Color.mediumseagreen_300,
    fontFamily: FontFamily.nunitoSemibold,
    fontWeight: "600",
  },
  rectangleLayout: {
    width: 34,
    height: 34,
    top: 0,
    position: "absolute",
  },
  textPosition: {
    left: 12,
    lineHeight: 25,
    fontSize: FontSize.size_xl,
    textAlign: "left",
    position: "absolute",
  },
  ellipse6Icon: {
    width: 573,
    height: 657,
    opacity: 0.5,
    left: 0,
    top: 0,
    position: "absolute",
  },
  rectangle11Icon: {
    left: 28,
    borderRadius: Border.br_2xs,
    width: 72,
    height: 72,
    top: 704,
    position: "absolute",
  },
  fastFood: {
    fontSize: FontSize.size_13xl,
  },
  beverages: {
    fontWeight: "500",
    fontFamily: FontFamily.nunitoMedium,
    fontSize: FontSize.size_xl,
  },
  fastFoodBeveragesContainer: {
    top: 110,
    lineHeight: 31,
    left: 17,
    position: "absolute",
  },
  popular: {
    lineHeight: 31,
  },
  now: {
    lineHeight: 30,
    fontFamily: FontFamily.nunitoLight,
    fontWeight: "300",
  },
  popularNow: {
    top: 648,
    fontSize: FontSize.size_6xl,
    textAlign: "left",
    color: Color.gray1,
  },
  rectangle10: {
    top: 696,
    borderRadius: Border.br_3xs,
    borderStyle: "solid",
    borderColor: "#828282",
    borderWidth: 1.5,
    width: 335,
    height: 87,
  },
  chickenManchurian: {
    lineHeight: 18,
    color: Color.globalBlack,
    fontFamily: FontFamily.nunitoExtralightItalic,
    fontWeight: "200",
    fontStyle: "italic",
    fontSize: FontSize.size_lg,
    width: 177,
    left: 116,
    top: 704,
  },
  chineseCuisine: {
    top: 727,
    fontSize: FontSize.caption3Medium10_size,
    lineHeight: 10,
    color: Color.gray3,
    width: 177,
    left: 116,
    fontFamily: FontFamily.nunitoLight,
    fontWeight: "300",
  },
  rectangle11: {
    top: 721,
    left: 302,
    borderRadius: Border.br_5xs,
    shadowColor: "rgba(0, 0, 0, 0.15)",
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowRadius: 10,
    elevation: 10,
    shadowOpacity: 1,
    width: 38,
    height: 38,
    backgroundColor: Color.dimgray,
    position: "absolute",
  },
  vector3Icon: {
    top: 732,
    left: 316,
    width: 10,
    height: 17,
    position: "absolute",
  },
  text: {
    top: 751,
    lineHeight: 25,
    fontFamily: FontFamily.nunitoExtralightItalic,
    fontWeight: "200",
    fontStyle: "italic",
    left: 116,
    fontSize: FontSize.size_xl,
    textAlign: "left",
    color: Color.gray1,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  group37377: {
    left: 53,
    top: 220,
    width: 254,
    height: 86,
    position: "absolute",
  },
  customerHomeCategory3Child: {
    top: 24,
    width: 329,
    height: 39,
  },
  riceCard: {
    left: 0,
  },
  rectangle8: {
    width: 123,
    height: 34,
    top: 0,
    position: "absolute",
  },
  text1: {
    left: 30,
    top: 5,
    color: Color.mediumseagreen_300,
    fontFamily: FontFamily.nunitoSemibold,
    fontWeight: "600",
    lineHeight: 25,
    fontSize: FontSize.size_lg,
    textAlign: "left",
    position: "absolute",
  },
  orice: {
    left: 0,
  },
  rectangle9: {
    backgroundColor: Color.globalWhite,
    borderRadius: Border.br_8xs,
    left: 0,
  },
  text2: {
    top: 4,
    color: Color.mediumseagreen_300,
    fontFamily: FontFamily.nunitoSemibold,
    fontWeight: "600",
  },
  addButton: {
    left: 133,
  },
  group1: {
    left: 13,
  },
  text3: {
    left: 33,
    top: 5,
    color: Color.mediumseagreen_300,
    fontFamily: FontFamily.nunitoSemibold,
    fontWeight: "600",
    lineHeight: 25,
    fontSize: FontSize.size_lg,
    textAlign: "left",
    position: "absolute",
  },
  rectangle91: {
    borderRadius: Border.br_8xs,
    width: 34,
    backgroundColor: Color.dimgray,
    left: 0,
  },
  text4: {
    top: 1,
    color: Color.globalWhite,
    fontFamily: FontFamily.nunitoExtralightItalic,
    fontWeight: "200",
    fontStyle: "italic",
  },
  group11: {
    left: 14,
  },
  zingerCard: {
    left: 214,
  },
  frame58containersliderhori: {
    top: 335,
    left: 20,
    width: 340,
    height: 286,
    position: "absolute",
  },
  customerHomeCategory3: {
    backgroundColor: Color.kitchenBG,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default CustomerHomeCategory3;
