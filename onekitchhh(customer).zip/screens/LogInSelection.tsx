import * as React from "react";
import { Text, StyleSheet, View, Image, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const LogInSelection = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.logInSelection}>
      <View style={styles.frame37446}>
        <Text style={[styles.welcome, styles.welcomeTypo]}>Welcome!</Text>
        <Text
          style={[styles.pleaseChooseAccordingly, styles.ellipse6IconPosition]}
        >
          Please choose accordingly!
        </Text>
      </View>
      <Image
        style={[styles.ellipse6Icon, styles.ellipse6IconPosition]}
        resizeMode="cover"
        source={require("../assets/ellipse63.png")}
      />
      <View style={styles.frame37449Parent}>
        <Pressable
          style={styles.frame37449}
          onPress={() => navigation.navigate("Login1")}
        >
          <Text style={[styles.driver, styles.driverTypo]}>Driver</Text>
          <Image
            style={[styles.icon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/456721811.png")}
          />
        </Pressable>
        <Pressable
          style={[styles.frame37448, styles.framePosition]}
          onPress={() => navigation.navigate("LogInNope")}
        >
          <Text style={[styles.merchant, styles.driverTypo]}>Merchant</Text>
          <Image
            style={[styles.avd437689ef3a02914ac11Icon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/avd437689ef3a02914ac111.png")}
          />
        </Pressable>
        <Pressable
          style={[styles.frame37447, styles.framePosition]}
          onPress={() => navigation.navigate("Login1")}
        >
          <Text style={[styles.customer, styles.driverTypo]}>Customer</Text>
          <Image
            style={[styles.icons8ShoppingCart901, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/icons8shoppingcart901.png")}
          />
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  welcomeTypo: {
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
  },
  ellipse6IconPosition: {
    left: 0,
    position: "absolute",
  },
  driverTypo: {
    textAlign: "left",
    fontSize: FontSize.size_lg,
    color: Color.globalBlack,
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    top: "0%",
    position: "absolute",
    overflow: "hidden",
  },
  framePosition: {
    left: 37,
    position: "absolute",
  },
  welcome: {
    top: 0,
    left: 16,
    fontSize: FontSize.size_17xl,
    color: Color.globalBlack,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  pleaseChooseAccordingly: {
    top: 53,
    fontSize: FontSize.size_base,
    color: Color.kDarkGreen,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    left: 0,
  },
  frame37446: {
    top: 62,
    left: 80,
    width: 199,
    height: 75,
    position: "absolute",
  },
  ellipse6Icon: {
    top: 625,
    width: 360,
    height: 175,
  },
  driver: {
    top: "72.53%",
    left: "8.33%",
  },
  icon: {
    height: "67.13%",
    bottom: "32.87%",
    left: "0%",
    right: "0%",
    maxWidth: "100%",
    top: "0%",
    width: "100%",
  },
  frame37449: {
    top: 303,
    left: 47,
    width: 60,
    height: 91,
    position: "absolute",
  },
  merchant: {
    top: "75.49%",
    left: "1.25%",
  },
  avd437689ef3a02914ac11Icon: {
    height: "75.63%",
    bottom: "24.37%",
    left: "0%",
    right: "0%",
    maxWidth: "100%",
    top: "0%",
    width: "100%",
  },
  frame37448: {
    top: 169,
    width: 80,
    height: 102,
  },
  customer: {
    top: "75%",
    left: "0%",
  },
  icons8ShoppingCart901: {
    height: "75%",
    width: "92.59%",
    right: "3.7%",
    bottom: "25%",
    left: "3.7%",
    maxWidth: "100%",
    top: "0%",
  },
  frame37447: {
    top: 37,
    width: 81,
    height: 100,
  },
  frame37449Parent: {
    top: 184,
    left: 102,
    width: 140,
    height: 394,
    position: "absolute",
    overflow: "hidden",
  },
  logInSelection: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.kitchenBG,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default LogInSelection;
