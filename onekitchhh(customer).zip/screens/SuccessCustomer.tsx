import * as React from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import { FontFamily, FontSize, Color } from "../GlobalStyles";

const SuccessCustomer = () => {
  return (
    <View style={styles.successCustomer}>
      <Image
        style={styles.asset11Icon}
        resizeMode="cover"
        source={require("../assets/asset111.png")}
      />
      <Text style={[styles.success, styles.successTypo]}>Success!</Text>
      <Text style={[styles.yourSuccessfullyOrdered, styles.successTypo]}>
        Your successfully ordered the items!
      </Text>
      <View style={styles.continueToLogIn}>
        <Text style={[styles.continueToLogContainer, styles.successTypo]}>
          <Text style={styles.continueTo}>{`Continue to `}</Text>
          <Text style={styles.logIn}>Log In</Text>
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  successTypo: {
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  asset11Icon: {
    top: 231,
    left: 92,
    width: 175,
    height: 175,
    position: "absolute",
    overflow: "hidden",
  },
  success: {
    top: 64,
    left: 109,
    fontSize: FontSize.size_17xl,
    color: Color.globalBlack,
  },
  yourSuccessfullyOrdered: {
    top: 117,
    left: 46,
    fontSize: FontSize.size_base,
    color: Color.kDarkGreen,
  },
  continueTo: {
    color: Color.globalBlack,
  },
  logIn: {
    color: Color.seagreen_100,
  },
  continueToLogContainer: {
    top: "0%",
    left: "0%",
    fontSize: FontSize.size_xl,
  },
  continueToLogIn: {
    top: 450,
    left: 94,
    width: 171,
    height: 27,
    position: "absolute",
  },
  successCustomer: {
    backgroundColor: Color.kitchenBG,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default SuccessCustomer;
