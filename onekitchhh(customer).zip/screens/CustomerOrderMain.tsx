import * as React from "react";
import { StyleSheet, View, Text, Image, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Padding, Color, Border } from "../GlobalStyles";

const CustomerOrderMain = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.customerOrderMain}>
      <View style={[styles.appBar, styles.appBarPosition]}>
        <View style={[styles.bg, styles.bgPosition]} />
        <Text style={[styles.headline, styles.skipFlexBox]}>Daily Deli</Text>
        <Image
          style={[styles.arrowleftIcon, styles.iconLayout1]}
          resizeMode="cover"
          source={require("../assets/arrowleft1.png")}
        />
        <View style={[styles.textOrButtons, styles.headlinePosition]}>
          <Text style={[styles.skip, styles.skipLayout]}>Skip</Text>
          <View style={[styles.buttons, styles.rowFlexBox]}>
            <Image
              style={styles.iconLayout1}
              resizeMode="cover"
              source={require("../assets/heart1.png")}
            />
            <Image
              style={[styles.sharenetworkIcon, styles.iconLayout1]}
              resizeMode="cover"
              source={require("../assets/sharenetwork1.png")}
            />
            <Image
              style={[styles.sharenetworkIcon, styles.iconLayout1]}
              resizeMode="cover"
              source={require("../assets/dotsthreevertical1.png")}
            />
          </View>
        </View>
      </View>
      <View style={[styles.frame67, styles.frame67Position]}>
        <Image
          style={[styles.imageIcon, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/image1.png")}
        />
        <Text style={[styles.joharTown, styles.tabTypo]}>Johar Town</Text>
        <Text style={[styles.dailyDeli, styles.popular1Typo]}>Daily Deli</Text>
        <View style={[styles.tabs, styles.rowFlexBox]}>
          <View style={styles.tabsFlexBox}>
            <View style={[styles.content, styles.timeFlexBox]}>
              <Text style={[styles.tabTitle, styles.tabTypo]}>Popular</Text>
            </View>
            <View style={[styles.indicator, styles.spacerLayout]} />
          </View>
          <View style={[styles.tabs2, styles.tabsFlexBox]}>
            <View style={[styles.content, styles.timeFlexBox]}>
              <Text style={[styles.tabTitle1, styles.tabTypo]}>Deals</Text>
            </View>
            <View style={styles.spacerLayout} />
          </View>
          <View style={[styles.tabs2, styles.tabsFlexBox]}>
            <View style={[styles.content, styles.timeFlexBox]}>
              <Text style={[styles.tabTitle1, styles.tabTypo]}>Wraps</Text>
            </View>
            <View style={styles.spacerLayout} />
          </View>
          <View style={[styles.tabs2, styles.tabsFlexBox]}>
            <View style={[styles.content, styles.timeFlexBox]}>
              <Text style={[styles.tabTitle1, styles.tabTypo]}>Beverages</Text>
            </View>
            <View style={styles.spacerLayout} />
          </View>
          <View style={[styles.tabs2, styles.tabsFlexBox]}>
            <View style={[styles.content, styles.timeFlexBox]}>
              <Text style={[styles.tabTitle1, styles.tabTypo]}>Sandwiches</Text>
            </View>
            <View style={styles.spacerLayout} />
          </View>
        </View>
        <View style={[styles.row, styles.rowFlexBox]}>
          <View style={[styles.ratings, styles.timeFlexBox]}>
            <Image
              style={styles.starIcon}
              resizeMode="cover"
              source={require("../assets/star.png")}
            />
            <Text style={[styles.text, styles.textSpaceBlock]}>4.8</Text>
          </View>
          <View style={[styles.time, styles.timeFlexBox]}>
            <Image
              style={styles.starIcon}
              resizeMode="cover"
              source={require("../assets/clock.png")}
            />
            <Text style={[styles.text, styles.textSpaceBlock]}>40min</Text>
          </View>
          <View style={[styles.time, styles.timeFlexBox]}>
            <Image
              style={styles.starIcon}
              resizeMode="cover"
              source={require("../assets/mappin.png")}
            />
            <Text style={[styles.text, styles.textSpaceBlock]}>1.4km</Text>
          </View>
        </View>
        <Pressable
          style={[styles.arrowleft, styles.iconLayout1]}
          onPress={() => navigation.navigate("CustomerHome")}
        >
          <Image
            style={styles.icon}
            resizeMode="cover"
            source={require("../assets/arrowleft1.png")}
          />
        </Pressable>
      </View>
      <View style={[styles.frame68container, styles.frame67Position]}>
        <View style={[styles.content5, styles.frame67Position]}>
          <View style={styles.popular}>
            <View style={styles.title}>
              <Text style={[styles.popular1, styles.popular1Typo]}>
                Popular
              </Text>
            </View>
            <View style={styles.list}>
              <View style={styles.listFood}>
                <Pressable
                  style={[styles.container, styles.containerSpaceBlock]}
                  onPress={() => navigation.navigate("CustomerOrder1")}
                >
                  <View style={styles.image}>
                    <Image
                      style={[styles.imgIcon, styles.imgIconPosition]}
                      resizeMode="cover"
                      source={require("../assets/img.png")}
                    />
                  </View>
                  <View style={styles.content6}>
                    <View style={styles.popular}>
                      <Text
                        style={[styles.chickenFajitaPizza, styles.skipFlexBox]}
                      >
                        Chicken Fajita Pizza
                      </Text>
                      <Text
                        style={[styles.pizzaWithRegular, styles.textSpaceBlock]}
                      >
                        8” pizza with regular soft drink
                      </Text>
                    </View>
                    <Text style={[styles.text1, styles.tabTypo]}>$10</Text>
                  </View>
                </Pressable>
                <Image
                  style={[styles.dividerIcon, styles.frame67Position]}
                  resizeMode="cover"
                  source={require("../assets/divider.png")}
                />
              </View>
              <View style={styles.popular}>
                <View style={[styles.container1, styles.containerSpaceBlock]}>
                  <View style={styles.image}>
                    <Image
                      style={[styles.imgIcon, styles.imgIconPosition]}
                      resizeMode="cover"
                      source={require("../assets/img1.png")}
                    />
                    <View style={[styles.badge, styles.badgeBg]}>
                      <Text style={styles.text2}>1</Text>
                    </View>
                  </View>
                  <View style={styles.content6}>
                    <View style={styles.popular}>
                      <Text
                        style={[styles.chickenFajitaPizza, styles.skipFlexBox]}
                      >
                        Chicken Fajita Pizza
                      </Text>
                      <Text
                        style={[styles.pizzaWithRegular, styles.textSpaceBlock]}
                      >
                        8” pizza with regular soft drink
                      </Text>
                    </View>
                    <Text style={[styles.text1, styles.tabTypo]}>$10</Text>
                  </View>
                  <Image
                    style={[styles.xcircleIcon, styles.iconLayout1]}
                    resizeMode="cover"
                    source={require("../assets/xcircle.png")}
                  />
                </View>
                <Image
                  style={[styles.dividerIcon1, styles.dividerIconLayout]}
                  resizeMode="cover"
                  source={require("../assets/divider.png")}
                />
              </View>
            </View>
          </View>
          <View style={styles.spacer4}>
            <View style={[styles.spacer5, styles.imgIconPosition]} />
          </View>
          <View style={styles.popular}>
            <View style={styles.title}>
              <Text style={[styles.popular1, styles.popular1Typo]}>Deals</Text>
            </View>
            <View style={styles.list}>
              <View style={styles.popular}>
                <View style={[styles.container1, styles.containerSpaceBlock]}>
                  <View style={styles.image}>
                    <Image
                      style={[styles.imgIcon, styles.imgIconPosition]}
                      resizeMode="cover"
                      source={require("../assets/img2.png")}
                    />
                    <View style={[styles.badge, styles.badgeBg]}>
                      <Text style={styles.text2}>1</Text>
                    </View>
                  </View>
                  <View style={styles.content6}>
                    <View style={styles.popular}>
                      <Text
                        style={[styles.chickenFajitaPizza, styles.skipFlexBox]}
                      >
                        Deal 1
                      </Text>
                      <Text
                        style={[styles.pizzaWithRegular, styles.textSpaceBlock]}
                      >
                        1 regular burger with croquette and hot cocoa
                      </Text>
                    </View>
                    <Text style={[styles.text1, styles.tabTypo]}>$12</Text>
                  </View>
                  <Image
                    style={[styles.sharenetworkIcon, styles.iconLayout1]}
                    resizeMode="cover"
                    source={require("../assets/xcircle1.png")}
                  />
                </View>
                <Image
                  style={[styles.dividerIcon1, styles.dividerIconLayout]}
                  resizeMode="cover"
                  source={require("../assets/divider.png")}
                />
              </View>
              <View style={styles.popular}>
                <View style={[styles.container1, styles.containerSpaceBlock]}>
                  <View style={styles.image}>
                    <Image
                      style={[styles.imgIcon, styles.imgIconPosition]}
                      resizeMode="cover"
                      source={require("../assets/img3.png")}
                    />
                    <View style={[styles.badge, styles.badgeBg]}>
                      <Text style={styles.text2}>1</Text>
                    </View>
                  </View>
                  <View style={styles.content6}>
                    <View style={styles.popular}>
                      <Text
                        style={[styles.chickenFajitaPizza, styles.skipFlexBox]}
                      >
                        Deal 2
                      </Text>
                      <Text
                        style={[styles.pizzaWithRegular, styles.textSpaceBlock]}
                      >
                        1 regular burger with small fries
                      </Text>
                    </View>
                    <Text style={[styles.text1, styles.tabTypo]}>$6</Text>
                  </View>
                  <Image
                    style={[styles.sharenetworkIcon, styles.iconLayout1]}
                    resizeMode="cover"
                    source={require("../assets/xcircle1.png")}
                  />
                </View>
                <Image
                  style={[styles.dividerIcon1, styles.dividerIconLayout]}
                  resizeMode="cover"
                  source={require("../assets/divider.png")}
                />
              </View>
              <View style={styles.popular}>
                <View style={[styles.container1, styles.containerSpaceBlock]}>
                  <View style={styles.image}>
                    <Image
                      style={[styles.imgIcon, styles.imgIconPosition]}
                      resizeMode="cover"
                      source={require("../assets/img4.png")}
                    />
                    <View style={[styles.badge, styles.badgeBg]}>
                      <Text style={styles.text2}>1</Text>
                    </View>
                  </View>
                  <View style={styles.content6}>
                    <View style={styles.popular}>
                      <Text
                        style={[styles.chickenFajitaPizza, styles.skipFlexBox]}
                      >
                        Deal 3
                      </Text>
                      <Text
                        style={[styles.pizzaWithRegular, styles.textSpaceBlock]}
                      >
                        2 pieces of beef stew with homemade sauce
                      </Text>
                    </View>
                    <Text style={[styles.text1, styles.tabTypo]}>$23</Text>
                  </View>
                  <Image
                    style={[styles.sharenetworkIcon, styles.iconLayout1]}
                    resizeMode="cover"
                    source={require("../assets/xcircle1.png")}
                  />
                </View>
                <Image
                  style={[styles.dividerIcon4, styles.dividerIconLayout]}
                  resizeMode="cover"
                  source={require("../assets/divider.png")}
                />
              </View>
            </View>
          </View>
        </View>
      </View>
      <View style={[styles.homeIndicator, styles.appBarPosition]}>
        <View style={[styles.homeIndicator1, styles.badgeBg]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  appBarPosition: {
    left: 0,
    right: 0,
    position: "absolute",
  },
  bgPosition: {
    left: "0%",
    position: "absolute",
  },
  skipFlexBox: {
    textAlign: "left",
    letterSpacing: 0,
  },
  iconLayout1: {
    height: 22,
    width: 22,
  },
  headlinePosition: {
    marginTop: 6,
    top: "50%",
  },
  skipLayout: {
    lineHeight: 18,
    fontSize: FontSize.footnoteRegular13_size,
  },
  rowFlexBox: {
    alignItems: "center",
    flexDirection: "row",
  },
  frame67Position: {
    width: 375,
    left: 0,
    position: "absolute",
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  tabTypo: {
    lineHeight: 20,
    fontSize: FontSize.subheadlineRegular15_size,
    textAlign: "left",
  },
  popular1Typo: {
    letterSpacing: 1,
    textAlign: "left",
    fontWeight: "700",
  },
  timeFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  spacerLayout: {
    height: 2,
    alignSelf: "stretch",
  },
  tabsFlexBox: {
    justifyContent: "space-between",
    height: 32,
    alignItems: "center",
    overflow: "hidden",
  },
  textSpaceBlock: {
    marginTop: 4,
    fontFamily: FontFamily.caption2Regular11,
    letterSpacing: 0,
  },
  containerSpaceBlock: {
    paddingBottom: Padding.p_base,
    paddingTop: Padding.p_base,
    backgroundColor: Color.globalWhite,
    paddingRight: Padding.p_4xl,
    paddingLeft: Padding.p_5xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  imgIconPosition: {
    bottom: "0%",
    height: "100%",
    left: "0%",
    right: "0%",
    top: "0%",
    position: "absolute",
    width: "100%",
  },
  badgeBg: {
    backgroundColor: Color.globalBlack,
    display: "none",
    position: "absolute",
  },
  dividerIconLayout: {
    maxWidth: "100%",
    alignSelf: "stretch",
    overflow: "hidden",
    width: "100%",
  },
  bg: {
    height: "181.82%",
    bottom: "-81.82%",
    right: "0%",
    top: "0%",
    left: "0%",
    width: "100%",
  },
  headline: {
    marginLeft: -130,
    display: "none",
    color: Color.globalWhite,
    fontFamily: FontFamily.bodySemibold17,
    fontWeight: "700",
    lineHeight: 22,
    fontSize: FontSize.bodySemibold17_size,
    textAlign: "left",
    left: "50%",
    top: "50%",
    marginTop: 6,
    position: "absolute",
  },
  arrowleftIcon: {
    left: 24,
    position: "absolute",
    top: "50%",
    marginTop: 6,
  },
  skip: {
    color: Color.grayGray1,
    fontFamily: FontFamily.caption2Regular11,
    display: "none",
    textAlign: "left",
    letterSpacing: 0,
  },
  sharenetworkIcon: {
    marginLeft: 16,
  },
  buttons: {
    justifyContent: "flex-end",
    marginLeft: 8,
  },
  textOrButtons: {
    right: 23,
    flexDirection: "row",
    top: "50%",
    position: "absolute",
    marginTop: 6,
  },
  appBar: {
    shadowColor: "rgba(0, 0, 0, 0.08)",
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowRadius: 24,
    elevation: 24,
    shadowOpacity: 1,
    height: 88,
    top: 0,
  },
  imageIcon: {
    height: "61.32%",
    width: "96%",
    top: "0.04%",
    right: "4%",
    bottom: "38.63%",
    left: "0%",
    position: "absolute",
  },
  joharTown: {
    bottom: 147,
    fontFamily: FontFamily.caption2Regular11,
    left: 24,
    position: "absolute",
    color: Color.globalWhite,
    letterSpacing: 0,
    fontSize: FontSize.subheadlineRegular15_size,
  },
  dailyDeli: {
    bottom: 171,
    fontSize: FontSize.title2Bold22_size,
    lineHeight: 28,
    left: 24,
    position: "absolute",
    color: Color.globalWhite,
    fontFamily: FontFamily.bodySemibold17,
  },
  tabTitle: {
    color: Color.mediumseagreen_200,
    fontFamily: FontFamily.bodySemibold17,
    fontWeight: "700",
    letterSpacing: 0,
    fontSize: FontSize.subheadlineRegular15_size,
  },
  content: {
    alignSelf: "stretch",
    flexDirection: "row",
  },
  indicator: {
    borderTopLeftRadius: Border.br_781xl,
    borderTopRightRadius: Border.br_781xl,
    backgroundColor: Color.mediumseagreen_200,
  },
  tabTitle1: {
    color: Color.grayGray1,
    fontFamily: FontFamily.bodySemibold17,
    fontWeight: "700",
    letterSpacing: 0,
    fontSize: FontSize.subheadlineRegular15_size,
  },
  tabs2: {
    marginLeft: 24,
  },
  tabs: {
    top: 294,
    left: 24,
    position: "absolute",
  },
  starIcon: {
    height: 24,
    width: 24,
  },
  text: {
    textAlign: "center",
    color: Color.globalBlack,
    lineHeight: 18,
    fontSize: FontSize.footnoteRegular13_size,
  },
  ratings: {
    flex: 1,
  },
  time: {
    marginLeft: 29,
    flex: 1,
  },
  row: {
    top: 223,
    width: 328,
    left: 24,
    position: "absolute",
  },
  icon: {
    marginTop: -112.93,
    height: "100%",
    width: "100%",
  },
  arrowleft: {
    left: 24,
    position: "absolute",
    top: "50%",
  },
  frame67: {
    height: 326,
    top: 0,
  },
  popular1: {
    fontSize: FontSize.size_xl,
    lineHeight: 24,
    fontFamily: FontFamily.nunitoBold,
    color: Color.globalBlack,
    flex: 1,
  },
  title: {
    paddingTop: Padding.p_5xl,
    paddingRight: Padding.p_4xl,
    paddingLeft: Padding.p_5xl,
    alignSelf: "stretch",
    alignItems: "center",
    flexDirection: "row",
  },
  imgIcon: {
    borderRadius: Border.br_base,
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  image: {
    width: 64,
    height: 64,
  },
  chickenFajitaPizza: {
    fontFamily: FontFamily.nunitoRegular,
    color: Color.globalBlack,
    alignSelf: "stretch",
    lineHeight: 22,
    fontSize: FontSize.bodySemibold17_size,
    textAlign: "left",
  },
  pizzaWithRegular: {
    alignSelf: "stretch",
    lineHeight: 20,
    fontSize: FontSize.subheadlineRegular15_size,
    textAlign: "left",
    color: Color.grayGray1,
  },
  popular: {
    alignSelf: "stretch",
  },
  text1: {
    marginTop: 12,
    color: Color.globalBlack,
    alignSelf: "stretch",
    fontFamily: FontFamily.bodySemibold17,
    fontWeight: "700",
    letterSpacing: 0,
    fontSize: FontSize.subheadlineRegular15_size,
  },
  content6: {
    marginLeft: 16,
    flex: 1,
  },
  container: {
    width: 375,
    left: 0,
    position: "absolute",
    top: 0,
  },
  dividerIcon: {
    top: 109,
    height: 1,
  },
  listFood: {
    height: 110,
    alignSelf: "stretch",
  },
  text2: {
    fontSize: FontSize.caption1Regular12_size,
    lineHeight: 16,
    textAlign: "center",
    fontFamily: FontFamily.caption2Regular11,
    color: Color.globalWhite,
  },
  badge: {
    top: -10,
    right: -10,
    borderRadius: Border.br_781xl,
    borderStyle: "solid",
    borderColor: "#fff",
    borderWidth: 2,
    padding: Padding.p_11xs,
    width: 24,
    justifyContent: "center",
    alignItems: "center",
  },
  xcircleIcon: {
    marginLeft: 16,
    display: "none",
  },
  container1: {
    alignSelf: "stretch",
  },
  dividerIcon1: {
    height: 1,
    alignSelf: "stretch",
  },
  list: {
    marginTop: 8,
    alignSelf: "stretch",
  },
  spacer5: {
    backgroundColor: Color.grayGray6,
  },
  spacer4: {
    height: 8,
    alignSelf: "stretch",
  },
  dividerIcon4: {
    height: 0,
    alignSelf: "stretch",
    display: "none",
  },
  content5: {
    top: 0,
  },
  frame68container: {
    top: 324,
    height: 730,
  },
  homeIndicator1: {
    marginLeft: -67,
    bottom: 8,
    borderRadius: Border.br_81xl,
    width: 134,
    height: 5,
    left: "50%",
  },
  homeIndicator: {
    bottom: 0,
    height: 34,
  },
  customerOrderMain: {
    backgroundColor: Color.kitchenBG,
    height: 1091,
    overflow: "hidden",
    width: "100%",
    flex: 1,
  },
});

export default CustomerOrderMain;
