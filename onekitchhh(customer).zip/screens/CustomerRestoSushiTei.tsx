import * as React from "react";
import { Image, StyleSheet, View, Text } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import FooterContainer from "../components/FooterContainer";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const CustomerRestoSushiTei = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.customerRestoSushiTei}>
      <Image
        style={styles.rectangle4394Position}
        resizeMode="cover"
        source={require("../assets/pexelsphotobypixabay.png")}
      />
      <LinearGradient
        style={[styles.rectangle4394, styles.rectangle4394Position]}
        locations={[0, 0.7]}
        colors={["rgba(22, 22, 22, 0)", "rgba(22, 22, 22, 0.8)"]}
        useAngle={true}
        angle={180.15}
      />
      <Image
        style={[styles.kColour1Icon, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/1kcolour11.png")}
      />
      <Text style={[styles.text, styles.textTypo3]}>4.5</Text>
      <Text style={[styles.ratings, styles.text2Typo]}>560 ratings</Text>
      <Text style={[styles.text1, styles.textTypo3]}>$$$</Text>
      <Text style={[styles.text2, styles.text2Typo]}>$15 - $45</Text>
      <Text style={[styles.likedBy, styles.text2Typo]}>Liked by</Text>
      <Text style={[styles.k, styles.textTypo3]}>435K</Text>
      <Image
        style={[styles.heartIcon, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/hearticon.png")}
      />
      <Text style={[styles.sushiTei, styles.menuClr]}>Sushi Tei</Text>
      <Text style={[styles.menu, styles.menuClr]}>Menu</Text>
      <View style={styles.line1} />
      <View style={styles.rectangle4414Parent}>
        <View style={[styles.rectangle4414, styles.rectangleLayout]} />
        <Image
          style={[styles.maskGroupIcon, styles.rectangleGroupLayout]}
          resizeMode="cover"
          source={require("../assets/maskgroup1.png")}
        />
        <Text style={[styles.sushi1, styles.sushiTypo2]}>Sushi 1</Text>
        <Text style={[styles.text3, styles.textTypo2]}>$20</Text>
        <View style={[styles.rectangle4415, styles.rectangleLayout]} />
        <Image
          style={[styles.maskGroupIcon1, styles.rectangleGroupLayout]}
          resizeMode="cover"
          source={require("../assets/maskgroup2.png")}
        />
        <Text style={[styles.sushi2, styles.sushiTypo2]}>Sushi 2</Text>
        <Text style={[styles.text4, styles.textTypo2]}>$20</Text>
        <View style={[styles.rectangle44141, styles.rectanglePosition1]} />
        <Image
          style={[styles.maskGroupIcon2, styles.rectangleGroupLayout]}
          resizeMode="cover"
          source={require("../assets/maskgroup2.png")}
        />
        <Text style={[styles.sushi3, styles.sushiTypo1]}>Sushi 3</Text>
        <Text style={[styles.text5, styles.textTypo1]}>$20</Text>
        <View style={[styles.rectangle44151, styles.rectanglePosition1]} />
        <Image
          style={[styles.maskGroupIcon3, styles.rectanglePosition1]}
          resizeMode="cover"
          source={require("../assets/maskgroup2.png")}
        />
        <Text style={[styles.sushi4, styles.sushiTypo1]}>Sushi 4</Text>
        <Text style={[styles.text6, styles.textTypo1]}>$20</Text>
        <View style={[styles.rectangle44142, styles.rectanglePosition]} />
        <Image
          style={[styles.maskGroupIcon4, styles.rectanglePosition]}
          resizeMode="cover"
          source={require("../assets/maskgroup2.png")}
        />
        <Text style={[styles.sushi11, styles.sushiTypo]}>Sushi 1</Text>
        <Text style={[styles.text7, styles.textTypo]}>$20</Text>
        <View style={[styles.rectangle44152, styles.rectanglePosition]} />
        <Image
          style={[styles.maskGroupIcon5, styles.rectangleGroupLayout]}
          resizeMode="cover"
          source={require("../assets/maskgroup2.png")}
        />
        <Text style={[styles.sushi21, styles.sushiTypo]}>Sushi 2</Text>
        <Text style={[styles.text8, styles.textTypo]}>$20</Text>
      </View>
      <FooterContainer
        propTop={983}
        onSearchButtonPress={() => navigation.navigate("CustomerSearch")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  rectangle4394Position: {
    height: 241,
    top: 0,
    width: 360,
    left: 0,
    position: "absolute",
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  textTypo3: {
    color: Color.globalWhite,
    lineHeight: 25,
    fontSize: FontSize.size_lg,
    top: 186,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  text2Typo: {
    fontFamily: FontFamily.sFProDisplayMedium,
    fontWeight: "500",
    lineHeight: 22,
    fontSize: FontSize.size_base,
    top: 211,
    textAlign: "center",
    color: Color.globalWhite,
    position: "absolute",
  },
  menuClr: {
    color: Color.globalBlack,
    position: "absolute",
  },
  rectangleLayout: {
    height: 186,
    backgroundColor: Color.mediumseagreen_100,
    borderRadius: Border.br_3xs,
  },
  rectangleGroupLayout: {
    width: 148,
    position: "absolute",
  },
  sushiTypo2: {
    color: Color.gray_500,
    top: 137,
    lineHeight: 22,
    fontSize: FontSize.size_base,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  textTypo2: {
    lineHeight: 20,
    fontSize: FontSize.size_sm,
    top: 159,
    color: Color.gray_500,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  rectanglePosition1: {
    top: 226,
    width: 148,
    position: "absolute",
  },
  sushiTypo1: {
    top: 354,
    color: Color.gray_500,
    lineHeight: 22,
    fontSize: FontSize.size_base,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  textTypo1: {
    top: 376,
    lineHeight: 20,
    fontSize: FontSize.size_sm,
    color: Color.gray_500,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  rectanglePosition: {
    top: 446,
    width: 148,
    position: "absolute",
  },
  sushiTypo: {
    top: 574,
    color: Color.gray_500,
    lineHeight: 22,
    fontSize: FontSize.size_base,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  textTypo: {
    top: 596,
    lineHeight: 20,
    fontSize: FontSize.size_sm,
    color: Color.gray_500,
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  rectangle4394: {
    opacity: 0.8,
    backgroundColor: "transparent",
  },
  kColour1Icon: {
    height: "2.15%",
    width: "8.33%",
    top: "1.61%",
    right: "86.11%",
    bottom: "96.24%",
    left: "5.56%",
  },
  text: {
    left: 63,
    textAlign: "center",
  },
  ratings: {
    left: 18,
  },
  text1: {
    left: 164,
    textAlign: "center",
  },
  text2: {
    left: 145,
  },
  likedBy: {
    left: 268,
  },
  k: {
    left: 292,
    textAlign: "center",
  },
  heartIcon: {
    height: "1.59%",
    width: "5.79%",
    top: "17.56%",
    right: "21.44%",
    bottom: "80.85%",
    left: "72.78%",
  },
  sushiTei: {
    top: 257,
    left: 23,
    fontSize: FontSize.size_5xl,
    lineHeight: 34,
    textAlign: "left",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    color: Color.globalBlack,
  },
  menu: {
    top: 290,
    left: 28,
    fontSize: FontSize.size_xl,
    lineHeight: 28,
    fontWeight: "600",
    fontFamily: FontFamily.nunitoSemibold,
    textAlign: "center",
  },
  line1: {
    right: 118,
    bottom: -14,
    borderStyle: "solid",
    borderColor: "#000",
    borderTopWidth: 4.4,
    width: 137,
    height: 4,
    position: "absolute",
  },
  rectangle4414: {
    width: 148,
    position: "absolute",
    left: 24,
    top: 9,
  },
  maskGroupIcon: {
    height: 124,
    left: 24,
    top: 9,
    width: 148,
  },
  sushi1: {
    left: 36,
  },
  text3: {
    left: 36,
  },
  rectangle4415: {
    left: 188,
    width: 148,
    position: "absolute",
    top: 9,
  },
  maskGroupIcon1: {
    left: 188,
    height: 124,
    top: 9,
    width: 148,
  },
  sushi2: {
    left: 200,
  },
  text4: {
    left: 200,
  },
  rectangle44141: {
    height: 186,
    backgroundColor: Color.mediumseagreen_100,
    borderRadius: Border.br_3xs,
    left: 24,
  },
  maskGroupIcon2: {
    top: 225,
    height: 124,
    left: 24,
  },
  sushi3: {
    left: 36,
  },
  text5: {
    left: 36,
  },
  rectangle44151: {
    left: 188,
    height: 186,
    backgroundColor: Color.mediumseagreen_100,
    borderRadius: Border.br_3xs,
  },
  maskGroupIcon3: {
    left: 188,
    height: 124,
  },
  sushi4: {
    left: 200,
  },
  text6: {
    left: 200,
  },
  rectangle44142: {
    height: 186,
    backgroundColor: Color.mediumseagreen_100,
    borderRadius: Border.br_3xs,
    left: 24,
  },
  maskGroupIcon4: {
    height: 124,
    left: 24,
  },
  sushi11: {
    left: 36,
  },
  text7: {
    left: 36,
  },
  rectangle44152: {
    left: 188,
    height: 186,
    backgroundColor: Color.mediumseagreen_100,
    borderRadius: Border.br_3xs,
  },
  maskGroupIcon5: {
    top: 445,
    left: 188,
    height: 124,
  },
  sushi21: {
    left: 200,
  },
  text8: {
    left: 200,
  },
  rectangle4414Parent: {
    top: 324,
    height: 643,
    width: 360,
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  customerRestoSushiTei: {
    backgroundColor: Color.kitchenBG,
    flex: 1,
    width: "100%",
    height: 1082,
    overflow: "hidden",
  },
});

export default CustomerRestoSushiTei;
