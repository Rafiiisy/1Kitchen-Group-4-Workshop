import * as React from "react";
import { Image, StyleSheet, Text, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color } from "../GlobalStyles";

const SuccessSignUp = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.successSignUp}>
      <View style={[styles.asset11Parent, styles.asset11ParentPosition]}>
        <Image
          style={[styles.asset11Icon, styles.asset11ParentPosition]}
          resizeMode="cover"
          source={require("../assets/asset111.png")}
        />
        <View style={[styles.continueToLogIn, styles.continuePosition]}>
          <Text style={[styles.continueToLog, styles.continueTypo]}>
            Continue to
          </Text>
        </View>
        <Pressable
          style={[styles.continueToLogIn1, styles.continuePosition]}
          onPress={() => navigation.navigate("Login1")}
        >
          <Text style={[styles.continueToLog1, styles.continueTypo]}>
            Log In
          </Text>
        </Pressable>
      </View>
      <View style={[styles.successParent, styles.asset11ParentPosition]}>
        <Text style={[styles.success, styles.successTypo]}>Success!</Text>
        <Text style={[styles.yourAccountHas, styles.successTypo]}>
          Your account has been created!
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  asset11ParentPosition: {
    position: "absolute",
    overflow: "hidden",
  },
  continuePosition: {
    height: 27,
    top: 237,
    position: "absolute",
  },
  continueTypo: {
    textAlign: "left",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    fontSize: FontSize.size_xl,
    left: "0%",
    top: "0%",
    position: "absolute",
  },
  successTypo: {
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  asset11Icon: {
    top: 18,
    left: 39,
    width: 175,
    height: 175,
  },
  continueToLog: {
    color: Color.globalBlack,
  },
  continueToLogIn: {
    left: 41,
    width: 171,
  },
  continueToLog1: {
    color: Color.seagreen_100,
  },
  continueToLogIn1: {
    left: 157,
    width: 68,
  },
  asset11Parent: {
    top: 213,
    left: 53,
    width: 242,
    height: 298,
  },
  success: {
    top: 10,
    left: 79,
    fontSize: FontSize.size_17xl,
    color: Color.globalBlack,
  },
  yourAccountHas: {
    top: 63,
    left: 35,
    fontSize: FontSize.size_base,
    color: Color.kDarkGreen,
  },
  successParent: {
    top: 54,
    left: 30,
    width: 279,
    height: 100,
  },
  successSignUp: {
    backgroundColor: Color.kitchenBG,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default SuccessSignUp;
