import * as React from "react";
import { Text, StyleSheet, View, Pressable, Image } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const SignUp2 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.signUp2}>
      <View style={[styles.frame30, styles.frame30Position]}>
        <View style={[styles.frame24ContainertopBar, styles.frame30Position]}>
          <Text style={[styles.welcome, styles.signUpTypo]}>Welcome!</Text>
          <Text style={[styles.weJustNeed, styles.weJustNeedTypo]}>
            We just need a bit more info!
          </Text>
        </View>
      </View>
      <View style={styles.numberPlateComponentInpParent}>
        <Text
          style={[styles.numberPlate, styles.numberContainerTypo]}
        >{`Home address `}</Text>
        <View style={[styles.frame37462, styles.frameLayout]}>
          <View style={[styles.rectangle4400, styles.frameLayout]} />
          <Text style={styles.enterYourHome}>Enter your Home address</Text>
        </View>
        <Text
          style={[
            styles.cityComponentinputCityContainer,
            styles.numberContainerTypo,
          ]}
        >
          <Text style={styles.city}>{`City `}</Text>
          <Text style={styles.text}>*</Text>
        </Text>
        <View style={[styles.frame37463, styles.frameLayout]}>
          <View style={[styles.rectangle4400, styles.frameLayout]} />
          <Text style={[styles.enterYourCity, styles.enterTypo]}>
            Enter your City
          </Text>
        </View>
        <Pressable
          style={[styles.signUpButton, styles.signUpButtonLayout]}
          onPress={() => navigation.navigate("SuccessSignUp")}
        >
          <Pressable
            style={[styles.rectangle44002, styles.signUpButtonLayout]}
            onPress={() => navigation.navigate("Login1")}
          />
          <Text style={[styles.signUp, styles.signUpTypo]}>Sign Up</Text>
        </Pressable>
        <View style={styles.group37419}>
          <View style={[styles.group37301, styles.group37301Position]}>
            <Text
              style={[styles.byClickingOnContainer, styles.group37301Position]}
            >
              <Text
                style={styles.byClickingOn}
              >{`By clicking on ‘sign up’, you’re agreeing to the Chunky app `}</Text>
              <Text style={styles.termsOfService}>Terms of Service</Text>
              <Text style={styles.byClickingOn}>{` and `}</Text>
              <Text style={styles.termsOfService}>Privacy</Text>
              <Text style={styles.byClickingOn}>{` `}</Text>
              <Text style={styles.termsOfService}>Policy</Text>
            </Text>
          </View>
          <Image
            style={styles.vectorIcon}
            resizeMode="cover"
            source={require("../assets/vector2.png")}
          />
        </View>
        <Text style={[styles.phoneNumberContainer, styles.numberContainerTypo]}>
          <Text style={styles.city}>{`Phone number `}</Text>
          <Text style={styles.text}>*</Text>
        </Text>
        <View style={[styles.frame37464, styles.frameLayout]}>
          <View style={[styles.rectangle4400, styles.frameLayout]} />
          <Text style={[styles.enterYourPhone, styles.enterTypo]}>
            Enter your phone number
          </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frame30Position: {
    width: 360,
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  signUpTypo: {
    textAlign: "center",
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    position: "absolute",
  },
  weJustNeedTypo: {
    fontFamily: FontFamily.nunitoMedium,
    fontWeight: "500",
  },
  numberContainerTypo: {
    fontSize: FontSize.size_base,
    textAlign: "center",
    position: "absolute",
  },
  frameLayout: {
    height: 44,
    width: 304,
    position: "absolute",
  },
  enterTypo: {
    top: 13,
    color: Color.gray_400,
    fontFamily: FontFamily.nunitoRegular,
    fontSize: FontSize.size_sm,
    textAlign: "center",
    position: "absolute",
  },
  signUpButtonLayout: {
    width: 280,
    height: 44,
    position: "absolute",
  },
  group37301Position: {
    width: 295,
    top: 0,
    position: "absolute",
  },
  welcome: {
    top: 11,
    left: 96,
    fontSize: FontSize.size_17xl,
    color: Color.globalBlack,
  },
  weJustNeed: {
    top: 64,
    left: 76,
    fontSize: FontSize.size_base,
    textAlign: "center",
    position: "absolute",
    color: Color.globalBlack,
  },
  frame24ContainertopBar: {
    top: 53,
    height: 92,
  },
  frame30: {
    height: 145,
    top: 0,
  },
  numberPlate: {
    top: 1,
    color: Color.kLightGreen,
    left: 12,
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    fontSize: FontSize.size_base,
  },
  rectangle4400: {
    borderRadius: Border.br_8xs,
    backgroundColor: Color.gray_200,
    borderStyle: "solid",
    borderColor: "#0d7a42",
    borderWidth: 2,
    left: 0,
    top: 0,
  },
  enterYourHome: {
    top: 14,
    left: 6,
    color: Color.gray_400,
    fontFamily: FontFamily.nunitoRegular,
    fontSize: FontSize.size_sm,
    textAlign: "center",
    position: "absolute",
  },
  frame37462: {
    top: 25,
    left: 10,
    width: 304,
  },
  city: {
    color: Color.gray_600,
  },
  text: {
    color: Color.red,
  },
  cityComponentinputCityContainer: {
    top: 89,
    left: 9,
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    fontSize: FontSize.size_base,
  },
  enterYourCity: {
    left: 7,
  },
  frame37463: {
    top: 113,
    left: 10,
    width: 304,
  },
  rectangle44002: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.kDarkGreen,
    left: 0,
    top: 0,
  },
  signUp: {
    top: 7,
    left: 100,
    fontSize: FontSize.size_xl,
    color: Color.kitchenBG,
    width: 79,
    height: 30,
  },
  signUpButton: {
    top: 377,
    left: 24,
  },
  byClickingOn: {
    color: Color.globalBlack,
  },
  termsOfService: {
    color: Color.darkslateblue,
  },
  byClickingOnContainer: {
    fontSize: FontSize.caption1Regular12_size,
    textAlign: "left",
    fontFamily: FontFamily.nunitoMedium,
    fontWeight: "500",
    left: 0,
  },
  group37301: {
    left: 28,
    height: 32,
  },
  vectorIcon: {
    height: "59.38%",
    width: "6.81%",
    top: "15.63%",
    right: "93.19%",
    bottom: "25%",
    left: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  group37419: {
    top: 301,
    left: 1,
    width: 323,
    height: 32,
    position: "absolute",
  },
  phoneNumberContainer: {
    top: 177,
    left: 11,
    fontFamily: FontFamily.nunitoBold,
    fontWeight: "700",
    fontSize: FontSize.size_base,
  },
  enterYourPhone: {
    left: 23,
  },
  frame37464: {
    top: 201,
    left: 12,
  },
  numberPlateComponentInpParent: {
    top: 169,
    left: 18,
    width: 324,
    height: 444,
    position: "absolute",
    overflow: "hidden",
  },
  signUp2: {
    backgroundColor: Color.kitchenBG,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default SignUp2;
