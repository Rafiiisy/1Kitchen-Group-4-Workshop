import React, { useMemo } from "react";
import { Image, StyleSheet, Text, View, Pressable } from "react-native";
import { Color, FontFamily, FontSize, Padding } from "../GlobalStyles";

type FooterContainerType = {
  /** Style props */
  propTop?: number | string;

  /** Action props */
  onSearchButtonPress?: () => void;
};

const getStyleValue = (key: string, value: string | number | undefined) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};

const FooterContainer = ({
  propTop,
  onSearchButtonPress,
}: FooterContainerType) => {
  const footerStyle = useMemo(() => {
    return {
      ...getStyleValue("top", propTop),
    };
  }, [propTop]);

  return (
    <View style={[styles.footer, footerStyle]}>
      <View style={styles.homeButton}>
        <Image
          style={styles.vectorHomeIcon}
          resizeMode="cover"
          source={require("../assets/vectorhome1.png")}
        />
        <Text style={[styles.home, styles.homeTypo]}>Home</Text>
      </View>
      <Pressable
        style={[styles.searchButton, styles.buttonSpaceBlock]}
        onPress={onSearchButtonPress}
      >
        <View style={styles.frame82}>
          <Image
            style={styles.searchvectorIcon}
            resizeMode="cover"
            source={require("../assets/searchvector.png")}
          />
          <Text style={[styles.explore, styles.homeTypo]}>Explore</Text>
        </View>
      </Pressable>
      <View style={[styles.ordersButton, styles.buttonSpaceBlock]}>
        <Image
          style={styles.vectorClockIcon}
          resizeMode="cover"
          source={require("../assets/vectorclock1.png")}
        />
        <Text style={[styles.orders, styles.ordersTypo]}>Orders</Text>
      </View>
      <View style={[styles.ordersButton, styles.buttonSpaceBlock]}>
        <Image
          style={styles.vectorUserIcon}
          resizeMode="cover"
          source={require("../assets/vectoruser.png")}
        />
        <Text style={[styles.account, styles.ordersTypo]}>Account</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  homeTypo: {
    marginTop: 2,
    textAlign: "center",
    color: Color.darkslategray_200,
    fontFamily: FontFamily.caption2Regular11,
    lineHeight: 13,
    letterSpacing: 0,
    fontSize: FontSize.caption2Regular11_size,
  },
  buttonSpaceBlock: {
    marginLeft: 43,
    flex: 1,
  },
  ordersTypo: {
    textAlign: "center",
    color: Color.darkslategray_200,
    fontFamily: FontFamily.caption2Regular11,
    lineHeight: 13,
    letterSpacing: 0,
    fontSize: FontSize.caption2Regular11_size,
  },
  vectorHomeIcon: {
    width: 26,
    height: 21,
  },
  home: {
    width: 32,
  },
  homeButton: {
    flex: 1,
    alignItems: "center",
  },
  searchvectorIcon: {
    width: 22,
    height: 22,
  },
  explore: {
    width: 41,
  },
  frame82: {
    alignItems: "center",
  },
  searchButton: {
    padding: Padding.p_3xs,
  },
  vectorClockIcon: {
    width: 23,
    height: 23,
  },
  orders: {
    width: 43,
    marginTop: 3,
  },
  ordersButton: {
    alignItems: "center",
  },
  vectorUserIcon: {
    width: 24,
    height: 24,
  },
  account: {
    width: 54,
  },
  footer: {
    position: "absolute",
    top: 983,
    left: -9,
    backgroundColor: Color.globalWhite,
    borderStyle: "solid",
    borderColor: "#f3f3f3",
    borderWidth: 1,
    width: 379,
    flexDirection: "row",
    paddingHorizontal: Padding.p_10xl,
    paddingVertical: Padding.p_lgi,
    justifyContent: "center",
    alignItems: "center",
  },
});

export default FooterContainer;
