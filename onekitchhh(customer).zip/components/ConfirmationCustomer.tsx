import * as React from "react";
import { View, Text, StyleSheet, Pressable, Image } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize } from "../GlobalStyles";

type ConfirmationCustomerType = {
  onClose?: () => void;
};

const ConfirmationCustomer = ({ onClose }: ConfirmationCustomerType) => {
  const navigation = useNavigation();

  return (
    <View style={[styles.confirmationCustomer, styles.iconWarning2Layout]}>
      <Text style={[styles.areYouSure, styles.noTypo]}>
        Are you sure about these changes?
      </Text>
      <Pressable
        style={[styles.yes, styles.noPosition]}
        onPress={() => navigation.navigate("CustomerProfile")}
      >
        <Text style={[styles.yes1, styles.noTypo]}>Yes</Text>
      </Pressable>
      <Text style={[styles.no, styles.noPosition]}>No</Text>
      <Image
        style={styles.line16Icon}
        resizeMode="cover"
        source={require("../assets/line16.png")}
      />
      <Image
        style={[styles.iconWarning2, styles.iconWarning2Layout]}
        resizeMode="cover"
        source={require("../assets/iconwarning2.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  iconWarning2Layout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  noTypo: {
    transform: [
      {
        rotate: "0.03deg",
      },
    ],
    height: 34,
    textAlign: "center",
    color: Color.globalBlack,
    fontFamily: FontFamily.nunitoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_base,
  },
  noPosition: {
    top: 120,
    position: "absolute",
  },
  areYouSure: {
    top: 71,
    left: -52,
    width: 410,
    position: "absolute",
  },
  yes1: {
    width: 76,
  },
  yes: {
    left: 50,
  },
  no: {
    left: 195,
    width: 62,
    transform: [
      {
        rotate: "0.03deg",
      },
    ],
    height: 34,
    textAlign: "center",
    color: Color.globalBlack,
    fontFamily: FontFamily.nunitoMedium,
    fontWeight: "500",
    fontSize: FontSize.size_base,
  },
  line16Icon: {
    top: 105,
    left: 156,
    width: 3,
    height: 45,
    position: "absolute",
  },
  iconWarning2: {
    height: "16.63%",
    width: "9.24%",
    top: "11.61%",
    right: "45.49%",
    bottom: "71.76%",
    left: "45.27%",
    position: "absolute",
  },
  confirmationCustomer: {
    backgroundColor: Color.kitchenBG,
    width: 307,
    height: 175,
  },
});

export default ConfirmationCustomer;
