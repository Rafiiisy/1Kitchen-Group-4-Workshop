import { FunctionComponent, useCallback } from "react";
import { Input } from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";
import styles from "./SignUp2.module.css";

const SignUp2: FunctionComponent = () => {
  const navigate = useNavigate();

  const onSignUpButtonClick = useCallback(() => {
    navigate("/success-sign-up");
  }, [navigate]);

  const onRectangle4400Click = useCallback(() => {
    navigate("/login");
  }, [navigate]);

  return (
    <div className={styles.signUp2}>
      <header className={styles.frame30}>
        <div className={styles.frame24ContainertopBar}>
          <b className={styles.welcome}>Welcome!</b>
          <div className={styles.weJustNeed}>We just need a bit more info!</div>
        </div>
      </header>
      <div className={styles.numberPlateComponentInpParent}>
        <b className={styles.numberPlate}>{`Home address `}</b>
        <Input
          className={styles.frame37462}
          variant="flushed"
          width="304px"
          focusBorderColor="#2c7e35"
          placeholder="Enter your Home address"
          w="304px"
        />
        <b className={styles.cityComponentinputCityContainer}>
          <span>{`City `}</span>
          <span className={styles.span}>*</span>
        </b>
        <Input
          className={styles.frame37463}
          variant="flushed"
          width="304px"
          focusBorderColor="#2c7e35"
          placeholder="Enter your City"
          w="304px"
        />
        <button className={styles.signUpButton} onClick={onSignUpButtonClick}>
          <div
            className={styles.rectangle4400}
            onClick={onRectangle4400Click}
          />
          <b className={styles.signUp}>Sign Up</b>
        </button>
        <div className={styles.group37419}>
          <div className={styles.group37301}>
            <div className={styles.byClickingOnContainer}>
              <span>{`By clicking on ‘sign up’, you’re agreeing to the Chunky app `}</span>
              <span className={styles.termsOfService}>Terms of Service</span>
              <span>{` and `}</span>
              <span className={styles.termsOfService}>Privacy</span>
              <span>{` `}</span>
              <span className={styles.termsOfService}>Policy</span>
            </div>
          </div>
          <img className={styles.vectorIcon} alt="" src="/vector2.svg" />
        </div>
        <b className={styles.phoneNumberContainer}>
          <span>{`Phone number `}</span>
          <span className={styles.span}>*</span>
        </b>
        <Input
          className={styles.frame37464}
          variant="flushed"
          width="304px"
          focusBorderColor="#2c7e35"
          type="number"
          placeholder="Enter your phone number"
          w="304px"
        />
      </div>
    </div>
  );
};

export default SignUp2;
