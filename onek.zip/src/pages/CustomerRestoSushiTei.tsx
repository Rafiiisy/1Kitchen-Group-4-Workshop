import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./CustomerRestoSushiTei.module.css";

const CustomerRestoSushiTei: FunctionComponent = () => {
  const navigate = useNavigate();

  const onSearchButtonClick = useCallback(() => {
    navigate("/customersearch");
  }, [navigate]);

  const onAccountButtonClick = useCallback(() => {
    navigate("/menu-customer");
  }, [navigate]);

  return (
    <div className={styles.customerRestoSushiTei}>
      <img
        className={styles.pexelsPhotoByPixabayIcon}
        alt=""
        src="/pexelsphotobypixabay@2x.png"
      />
      <div className={styles.rectangle4394} />
      <img className={styles.kColour1Icon} alt="" src="/1kcolour1@2x.png" />
      <b className={styles.b}>4.5</b>
      <div className={styles.ratings}>560 ratings</div>
      <b className={styles.b1}>$$$</b>
      <div className={styles.div}>$15 - $45</div>
      <div className={styles.likedBy}>Liked by</div>
      <b className={styles.k}>435K</b>
      <img className={styles.heartIcon} alt="" src="/hearticon.svg" />
      <b className={styles.sushiTei}>Sushi Tei</b>
      <div className={styles.menu}>Menu</div>
      <div className={styles.line1} />
      <div className={styles.rectangle4414Parent}>
        <div className={styles.rectangle4414} />
        <img className={styles.maskGroupIcon} alt="" src="/maskgroup1@2x.png" />
        <b className={styles.sushi1}>Sushi 1</b>
        <b className={styles.b2}>$20</b>
        <div className={styles.rectangle4415} />
        <img
          className={styles.maskGroupIcon1}
          alt=""
          src="/maskgroup2@2x.png"
        />
        <b className={styles.sushi2}>Sushi 2</b>
        <b className={styles.b3}>$20</b>
        <div className={styles.rectangle44141} />
        <img
          className={styles.maskGroupIcon2}
          alt=""
          src="/maskgroup2@2x.png"
        />
        <b className={styles.sushi3}>Sushi 3</b>
        <b className={styles.b4}>$20</b>
        <div className={styles.rectangle44151} />
        <img
          className={styles.maskGroupIcon3}
          alt=""
          src="/maskgroup2@2x.png"
        />
        <b className={styles.sushi4}>Sushi 4</b>
        <b className={styles.b5}>$20</b>
        <div className={styles.rectangle44142} />
        <img
          className={styles.maskGroupIcon4}
          alt=""
          src="/maskgroup2@2x.png"
        />
        <b className={styles.sushi11}>Sushi 1</b>
        <b className={styles.b6}>$20</b>
        <div className={styles.rectangle44152} />
        <img
          className={styles.maskGroupIcon5}
          alt=""
          src="/maskgroup2@2x.png"
        />
        <b className={styles.sushi21}>Sushi 2</b>
        <b className={styles.b7}>$20</b>
      </div>
      <footer className={styles.footer}>
        <button className={styles.homeButton}>
          <img
            className={styles.vectorHomeIcon}
            alt=""
            src="/vectorhome1.svg"
          />
          <div className={styles.home}>Home</div>
        </button>
        <button className={styles.searchButton} onClick={onSearchButtonClick}>
          <div className={styles.frame82}>
            <img
              className={styles.searchvectorIcon}
              alt=""
              src="/searchvector.svg"
            />
            <div className={styles.explore}>Explore</div>
          </div>
        </button>
        <div className={styles.ordersButton}>
          <img
            className={styles.vectorClockIcon}
            alt=""
            src="/vectorclock1.svg"
          />
          <div className={styles.orders}>Orders</div>
        </div>
        <button className={styles.accountButton} onClick={onAccountButtonClick}>
          <img
            className={styles.vectorUserIcon}
            alt=""
            src="/vectoruser1.svg"
          />
          <div className={styles.account}>Account</div>
        </button>
      </footer>
    </div>
  );
};

export default CustomerRestoSushiTei;
