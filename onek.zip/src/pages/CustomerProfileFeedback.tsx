import { FunctionComponent, useCallback } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Form } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import styles from "./CustomerProfileFeedback.module.css";

const CustomerProfileFeedback: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrame26ActiongobackLayClick = useCallback(() => {
    navigate("/menu-customer");
  }, [navigate]);

  const onGroup37342Click = useCallback(() => {
    navigate("/menu-customer");
  }, [navigate]);

  const onRectangle4400Click = useCallback(() => {
    navigate("/menu-customer");
  }, [navigate]);

  return (
    <div className={styles.customerProfileFeedback}>
      <div className={styles.frame14ContainerTopBar}>
        <b className={styles.feedback}>Feedback</b>
        <div className={styles.line9} />
        <button
          className={styles.frame26ActiongobackLay}
          onClick={onFrame26ActiongobackLayClick}
        >
          <img
            className={styles.arrowDownSignToNavigate5Icon}
            alt=""
            src="/arrowdownsigntonavigate51@2x.png"
          />
        </button>
      </div>
      <div className={styles.frame15Container}>
        <b className={styles.howDoYou}>How do you feel about 1Kitchen?</b>
        <Form.Select className={styles.group37297Formselect}>
          <option>select options</option>
          <option value="Happy">Happy</option>
          <option value="Okay">Okay</option>
          <option value="Dissatisfied">Dissatisfied</option>
        </Form.Select>
        <b className={styles.tellUsAbout}>Tell us about your experience!</b>
        <input
          className={styles.frame15ContainerChild}
          type="text"
          placeholder="Write your experience..."
          required
          autoFocus
        />
      </div>
      <button className={styles.group37342} onClick={onGroup37342Click}>
        <div className={styles.rectangle4400} onClick={onRectangle4400Click} />
        <b className={styles.submit}>Submit</b>
      </button>
    </div>
  );
};

export default CustomerProfileFeedback;
