import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./CustomerHome.module.css";

const CustomerHome: FunctionComponent = () => {
  const navigate = useNavigate();

  const onCardsImageClick = useCallback(() => {
    navigate("/customerhomecategory-1");
  }, [navigate]);

  const onImgClick = useCallback(() => {
    navigate("/customerorder-main");
  }, [navigate]);

  const onSearchButtonClick = useCallback(() => {
    navigate("/customersearch");
  }, [navigate]);

  const onAccountButtonClick = useCallback(() => {
    navigate("/menu-customer");
  }, [navigate]);

  const onTextFieldClick = useCallback(() => {
    navigate("/customersearch");
  }, [navigate]);

  const onWriteTextHerecomponentiClick = useCallback(() => {
    navigate("/customersearch");
  }, [navigate]);

  return (
    <div className={styles.customerHome}>
      <div className={styles.bannersParent}>
        <div className={styles.banners}>
          <div className={styles.carouselDots}>
            <img
              className={styles.carouselDotIcon}
              alt=""
              src="/carouseldot.svg"
            />
            <img
              className={styles.carouselDotIcon}
              alt=""
              src="/carouseldot1.svg"
            />
            <img
              className={styles.carouselDotIcon}
              alt=""
              src="/carouseldot.svg"
            />
          </div>
        </div>
        <div className={styles.frame61container}>
          <button className={styles.cardsImage} onClick={onCardsImageClick}>
            <img className={styles.imgBlurIcon} alt="" src="/imgblur@2x.png" />
            <img className={styles.imgIcon} alt="" src="/img5@2x.png" />
            <div className={styles.text}>
              <div className={styles.title}>Food</div>
              <div className={styles.subtitle}>Order food you love</div>
            </div>
          </button>
          <div className={styles.cardsImage1}>
            <img
              className={styles.imgBlurIcon1}
              alt=""
              src="/imgblur1@2x.png"
            />
            <img className={styles.imgIcon} alt="" src="/img6@2x.png" />
            <div className={styles.text}>
              <div className={styles.title1}>Drinks</div>
              <div className={styles.subtitle1}>To quench your thirst</div>
            </div>
          </div>
          <div className={styles.cardsImage2}>
            <img
              className={styles.imgBlurIcon2}
              alt=""
              src="/imgblur2@2x.png"
            />
            <img className={styles.imgIcon} alt="" src="/img7@2x.png" />
            <div className={styles.text}>
              <div className={styles.title1}>Deserts</div>
              <div className={styles.subtitle1}>Something Sweet</div>
            </div>
          </div>
        </div>
        <div className={styles.frame54containersliderdefa}>
          <div className={styles.content}>
            <div className={styles.cardsFood}>
              <button className={styles.img} onClick={onImgClick}>
                <img className={styles.imageIcon} alt="" src="/image2@2x.png" />
                <div className={styles.tag}>
                  <b className={styles.min}>40 min</b>
                </div>
                <img
                  className={styles.buttonIcon}
                  alt=""
                  src="/buttonicon.svg"
                />
              </button>
              <div className={styles.content1}>
                <div className={styles.text3}>
                  <b className={styles.popperoniPizza}>Daily Deli</b>
                  <div className={styles.dailyDeli}>Johar Town</div>
                </div>
                <div className={styles.ratings}>
                  <img className={styles.starIcon} alt="" src="/star1.svg" />
                  <b className={styles.b}>4.8</b>
                </div>
              </div>
            </div>
            <div className={styles.cardsFood1}>
              <div className={styles.img1}>
                <img className={styles.imageIcon} alt="" src="/image3@2x.png" />
                <div className={styles.tag}>
                  <b className={styles.min1}>12 min</b>
                </div>
                <img
                  className={styles.buttonIcon}
                  alt=""
                  src="/buttonicon.svg"
                />
              </div>
              <div className={styles.content2}>
                <div className={styles.text3}>
                  <b className={styles.popperoniPizza}>Rice Bowl</b>
                  <div className={styles.dailyDeli}>Wapda Town</div>
                </div>
                <div className={styles.ratings}>
                  <img className={styles.starIcon} alt="" src="/star1.svg" />
                  <b className={styles.b}>4.8</b>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.frame59container}>
          <div className={styles.title3}>
            <b className={styles.deals}>Deals</b>
            <img
              className={styles.arrowrightIcon}
              alt=""
              src="/arrowright.svg"
            />
          </div>
        </div>
        <div className={styles.frame62container}>
          <div className={styles.banners1}>
            <img className={styles.saucesIcon} alt="" src="/sauces@2x.png" />
            <img className={styles.pizzaIcon} alt="" src="/pizza@2x.png" />
            <img className={styles.pizzaHutIcon} alt="" src="/pizzahut.svg" />
            <div className={styles.content3}>
              <div className={styles.text5}>
                <div className={styles.pizzaParty}>Pizza Party</div>
                <div className={styles.enjoyPizzaFrom}>
                  Enjoy pizza from Johnny and get upto 30% off
                </div>
              </div>
              <div className={styles.text6}>
                <div className={styles.startingFrom}>Starting from</div>
                <b className={styles.b2}>$10</b>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.frame60container}>
          <div className={styles.exploreMore}>
            <b className={styles.popperoniPizza}>Explore More</b>
            <div className={styles.frame1}>
              <div className={styles.cardsFood2}>
                <div className={styles.img1}>
                  <img
                    className={styles.imageIcon}
                    alt=""
                    src="/image4@2x.png"
                  />
                  <div className={styles.tag}>
                    <b className={styles.min1}>40 min</b>
                  </div>
                  <img
                    className={styles.buttonIcon}
                    alt=""
                    src="/buttonicon.svg"
                  />
                </div>
                <div className={styles.content2}>
                  <div className={styles.text3}>
                    <b className={styles.popperoniPizza}>Jean’s Cakes</b>
                    <div className={styles.dailyDeli}>Johar Town</div>
                  </div>
                  <div className={styles.ratings}>
                    <img className={styles.starIcon} alt="" src="/star1.svg" />
                    <b className={styles.b}>4.8</b>
                  </div>
                </div>
              </div>
              <div className={styles.cardsFood2}>
                <div className={styles.img1}>
                  <img
                    className={styles.imageIcon}
                    alt=""
                    src="/image5@2x.png"
                  />
                  <div className={styles.tag}>
                    <b className={styles.min1}>20 min</b>
                  </div>
                  <img
                    className={styles.buttonIcon}
                    alt=""
                    src="/buttonicon.svg"
                  />
                </div>
                <div className={styles.content2}>
                  <div className={styles.text3}>
                    <b className={styles.popperoniPizza}>Thicc Shakes</b>
                    <div className={styles.dailyDeli}>Wapda Town</div>
                  </div>
                  <div className={styles.ratings}>
                    <img className={styles.starIcon} alt="" src="/star1.svg" />
                    <b className={styles.b}>4.5</b>
                  </div>
                </div>
              </div>
              <div className={styles.cardsFood2}>
                <div className={styles.img1}>
                  <img
                    className={styles.imageIcon}
                    alt=""
                    src="/image6@2x.png"
                  />
                  <div className={styles.tag}>
                    <b className={styles.min1}>30 min</b>
                  </div>
                  <img
                    className={styles.buttonIcon}
                    alt=""
                    src="/buttonicon.svg"
                  />
                </div>
                <div className={styles.content2}>
                  <div className={styles.text3}>
                    <b className={styles.popperoniPizza}>Daily Deli</b>
                    <div className={styles.dailyDeli}>Garden Town</div>
                  </div>
                  <div className={styles.ratings}>
                    <img className={styles.starIcon} alt="" src="/star1.svg" />
                    <b className={styles.b}>4.8</b>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <footer className={styles.footer}>
        <button className={styles.homeButton}>
          <img
            className={styles.vectorHomeIcon}
            alt=""
            src="/vectorhome2.svg"
          />
          <div className={styles.home}>Home</div>
        </button>
        <button className={styles.searchButton} onClick={onSearchButtonClick}>
          <div className={styles.frame82}>
            <img
              className={styles.searchvectorIcon}
              alt=""
              src="/searchvector.svg"
            />
            <div className={styles.explore}>Explore</div>
          </div>
        </button>
        <div className={styles.ordersButton}>
          <img
            className={styles.vectorClockIcon}
            alt=""
            src="/vectorclock1.svg"
          />
          <div className={styles.orders}>Orders</div>
        </div>
        <button className={styles.accountButton} onClick={onAccountButtonClick}>
          <img
            className={styles.vectorUserIcon}
            alt=""
            src="/vectoruser1.svg"
          />
          <div className={styles.account}>Account</div>
        </button>
      </footer>
      <header className={styles.homeBarcontainertopBarhid}>
        <img className={styles.patternIcon} alt="" src="/pattern@2x.png" />
        <button className={styles.textField} onClick={onTextFieldClick}>
          <img
            className={styles.arrowrightIcon}
            alt=""
            src="/magnifyingglass.svg"
          />
          <div
            className={styles.writeTextHerecomponenti}
            onClick={onWriteTextHerecomponentiClick}
          >
            Search...
          </div>
        </button>
        <div className={styles.location}>
          <img className={styles.arrowrightIcon} alt="" src="/mappin1.svg" />
          <div className={styles.blockBPhase}>
            Block B Phase 2 Johar Town, Lahore
          </div>
        </div>
      </header>
      <div className={styles.cartButtonLayer}>
        <img className={styles.buttonIcon5} alt="" src="/buttonicon1.svg" />
        <div className={styles.badge}>
          <div className={styles.div}>4</div>
        </div>
      </div>
    </div>
  );
};

export default CustomerHome;
