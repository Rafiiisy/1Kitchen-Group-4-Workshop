import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./CustomerOrderMain.module.css";

const CustomerOrderMain: FunctionComponent = () => {
  const navigate = useNavigate();

  const onArrowleftClick = useCallback(() => {
    navigate("/home-customer");
  }, [navigate]);

  const onContainerClick = useCallback(() => {
    navigate("/customerorder-1");
  }, [navigate]);

  return (
    <div className={styles.customerOrderMain}>
      <div className={styles.appBar}>
        <div className={styles.bg} />
        <b className={styles.headline}>Daily Deli</b>
        <img className={styles.arrowleftIcon} alt="" src="/arrowleft1.svg" />
        <div className={styles.textOrButtons}>
          <div className={styles.skip}>Skip</div>
          <div className={styles.buttons}>
            <img className={styles.heartIcon} alt="" src="/heart2.svg" />
            <img className={styles.heartIcon} alt="" src="/sharenetwork2.svg" />
            <img
              className={styles.heartIcon}
              alt=""
              src="/dotsthreevertical1.svg"
            />
          </div>
        </div>
      </div>
      <div className={styles.frame67}>
        <img className={styles.imageIcon} alt="" src="/image1@2x.png" />
        <div className={styles.joharTown}>Johar Town</div>
        <b className={styles.dailyDeli}>Daily Deli</b>
        <div className={styles.tabs}>
          <div className={styles.tabs1}>
            <div className={styles.content}>
              <b className={styles.tabTitle}>Popular</b>
            </div>
            <div className={styles.indicator} />
          </div>
          <div className={styles.tabs2}>
            <div className={styles.content}>
              <b className={styles.tabTitle}>Deals</b>
            </div>
            <div className={styles.spacer} />
          </div>
          <div className={styles.tabs2}>
            <div className={styles.content}>
              <b className={styles.tabTitle}>Wraps</b>
            </div>
            <div className={styles.spacer} />
          </div>
          <div className={styles.tabs2}>
            <div className={styles.content}>
              <b className={styles.tabTitle}>Beverages</b>
            </div>
            <div className={styles.spacer} />
          </div>
          <div className={styles.tabs2}>
            <div className={styles.content}>
              <b className={styles.tabTitle}>Sandwiches</b>
            </div>
            <div className={styles.spacer} />
          </div>
        </div>
        <div className={styles.row}>
          <div className={styles.ratings}>
            <img className={styles.starIcon} alt="" src="/star.svg" />
            <div className={styles.div}>4.8</div>
          </div>
          <div className={styles.ratings}>
            <img className={styles.starIcon} alt="" src="/clock.svg" />
            <div className={styles.div}>40min</div>
          </div>
          <div className={styles.ratings}>
            <img className={styles.starIcon} alt="" src="/mappin.svg" />
            <div className={styles.div}>1.4km</div>
          </div>
        </div>
        <button className={styles.arrowleft} onClick={onArrowleftClick}>
          <img className={styles.arrowleftIcon1} alt="" src="/arrowleft1.svg" />
        </button>
      </div>
      <div className={styles.frame68container}>
        <div className={styles.content5}>
          <div className={styles.popular}>
            <div className={styles.title}>
              <b className={styles.popular1}>Popular</b>
            </div>
            <div className={styles.list}>
              <div className={styles.listFood}>
                <button className={styles.container} onClick={onContainerClick}>
                  <div className={styles.image}>
                    <img className={styles.imgIcon} alt="" src="/img@2x.png" />
                  </div>
                  <div className={styles.content6}>
                    <div className={styles.titleDescp}>
                      <div className={styles.chickenFajitaPizza}>
                        Chicken Fajita Pizza
                      </div>
                      <div className={styles.pizzaWithRegular}>
                        8” pizza with regular soft drink
                      </div>
                    </div>
                    <b className={styles.b}>$10</b>
                  </div>
                </button>
                <img className={styles.dividerIcon} alt="" src="/divider.svg" />
              </div>
              <div className={styles.listFood1}>
                <div className={styles.container1}>
                  <div className={styles.image}>
                    <img className={styles.imgIcon} alt="" src="/img1@2x.png" />
                    <div className={styles.badge}>
                      <div className={styles.div1}>1</div>
                    </div>
                  </div>
                  <div className={styles.content7}>
                    <div className={styles.titleDescp}>
                      <div className={styles.chickenFajitaPizza1}>
                        Chicken Fajita Pizza
                      </div>
                      <div className={styles.pizzaWithRegular1}>
                        8” pizza with regular soft drink
                      </div>
                    </div>
                    <b className={styles.b1}>$10</b>
                  </div>
                  <img
                    className={styles.xcircleIcon}
                    alt=""
                    src="/xcircle.svg"
                  />
                </div>
                <img
                  className={styles.dividerIcon1}
                  alt=""
                  src="/divider.svg"
                />
              </div>
            </div>
          </div>
          <div className={styles.spacer4}>
            <div className={styles.spacer5} />
          </div>
          <div className={styles.popular}>
            <div className={styles.title}>
              <b className={styles.popular1}>Deals</b>
            </div>
            <div className={styles.list}>
              <div className={styles.listFood1}>
                <div className={styles.container1}>
                  <div className={styles.image}>
                    <img className={styles.imgIcon} alt="" src="/img2@2x.png" />
                    <div className={styles.badge}>
                      <div className={styles.div1}>1</div>
                    </div>
                  </div>
                  <div className={styles.content7}>
                    <div className={styles.titleDescp}>
                      <div className={styles.chickenFajitaPizza1}>Deal 1</div>
                      <div className={styles.pizzaWithRegular1}>
                        1 regular burger with croquette and hot cocoa
                      </div>
                    </div>
                    <b className={styles.b1}>$12</b>
                  </div>
                  <img
                    className={styles.heartIcon}
                    alt=""
                    src="/xcircle1.svg"
                  />
                </div>
                <img
                  className={styles.dividerIcon1}
                  alt=""
                  src="/divider.svg"
                />
              </div>
              <div className={styles.listFood1}>
                <div className={styles.container1}>
                  <div className={styles.image}>
                    <img className={styles.imgIcon} alt="" src="/img3@2x.png" />
                    <div className={styles.badge}>
                      <div className={styles.div1}>1</div>
                    </div>
                  </div>
                  <div className={styles.content7}>
                    <div className={styles.titleDescp}>
                      <div className={styles.chickenFajitaPizza1}>Deal 2</div>
                      <div className={styles.pizzaWithRegular1}>
                        1 regular burger with small fries
                      </div>
                    </div>
                    <b className={styles.b1}>$6</b>
                  </div>
                  <img
                    className={styles.heartIcon}
                    alt=""
                    src="/xcircle1.svg"
                  />
                </div>
                <img
                  className={styles.dividerIcon1}
                  alt=""
                  src="/divider.svg"
                />
              </div>
              <div className={styles.listFood1}>
                <div className={styles.container1}>
                  <div className={styles.image}>
                    <img className={styles.imgIcon} alt="" src="/img4@2x.png" />
                    <div className={styles.badge}>
                      <div className={styles.div1}>1</div>
                    </div>
                  </div>
                  <div className={styles.content7}>
                    <div className={styles.titleDescp}>
                      <div className={styles.chickenFajitaPizza1}>Deal 3</div>
                      <div className={styles.pizzaWithRegular1}>
                        2 pieces of beef stew with homemade sauce
                      </div>
                    </div>
                    <b className={styles.b1}>$23</b>
                  </div>
                  <img
                    className={styles.heartIcon}
                    alt=""
                    src="/xcircle1.svg"
                  />
                </div>
                <img
                  className={styles.dividerIcon4}
                  alt=""
                  src="/divider.svg"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.homeIndicator}>
        <div className={styles.homeIndicator1} />
      </div>
    </div>
  );
};

export default CustomerOrderMain;
