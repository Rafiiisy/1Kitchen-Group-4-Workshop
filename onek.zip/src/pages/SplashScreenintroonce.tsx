import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./SplashScreenintroonce.module.css";

const SplashScreenintroonce: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrame37441Click = useCallback(() => {
    navigate("/login");
  }, [navigate]);

  return (
    <div className={styles.splashScreenintroonce}>
      <button className={styles.frame37441} onClick={onFrame37441Click}>
        <img className={styles.kWhite1Icon} alt="" src="/1kwhite1@2x.png" />
        <b className={styles.oneKitchen}>One Kitchen</b>
      </button>
    </div>
  );
};

export default SplashScreenintroonce;
