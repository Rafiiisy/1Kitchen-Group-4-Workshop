import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./CustomerOrderSuccession.module.css";

const CustomerOrderSuccession: FunctionComponent = () => {
  const navigate = useNavigate();

  const onButtonClick = useCallback(() => {
    navigate("/home-customer");
  }, [navigate]);

  return (
    <div className={styles.customerOrderSuccession}>
      <div className={styles.frame73container}>
        <img className={styles.checkcircleIcon} alt="" src="/checkcircle.svg" />
        <div className={styles.text}>
          <b className={styles.thankYouFor}>Thank you for placing the order</b>
          <div className={styles.wellGetTo}>
            We’ll get to you as soon as possible
          </div>
        </div>
        <img
          className={styles.undrawOnTheWayReSwjt1Icon}
          alt=""
          src="/undrawonthewayreswjt1.svg"
        />
        <button className={styles.button} onClick={onButtonClick}>
          <b className={styles.button1}>Go Home</b>
        </button>
      </div>
      <div className={styles.homeIndicator}>
        <div className={styles.homeIndicator1} />
      </div>
    </div>
  );
};

export default CustomerOrderSuccession;
