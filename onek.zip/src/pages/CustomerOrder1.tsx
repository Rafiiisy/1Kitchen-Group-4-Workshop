import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./CustomerOrder1.module.css";

const CustomerOrder1: FunctionComponent = () => {
  const navigate = useNavigate();

  const onArrowleftClick = useCallback(() => {
    navigate("/customerorder-main");
  }, [navigate]);

  const onButtonClick = useCallback(() => {
    navigate("/customerordercart");
  }, [navigate]);

  return (
    <div className={styles.customerOrder1}>
      <div className={styles.imgcontainertopBar}>
        <img className={styles.imageIcon} alt="" src="/image@2x.png" />
        <div className={styles.dailyDeli}>Daily Deli - Johar Town</div>
        <b className={styles.chickenFajitaPizza}>Chicken Fajita Pizza</b>
      </div>
      <div className={styles.appBar}>
        <div className={styles.bg} />
        <b className={styles.headline}>Daily Deli</b>
        <button className={styles.arrowleft} onClick={onArrowleftClick}>
          <img className={styles.arrowleftIcon} alt="" src="/arrowleft1.svg" />
        </button>
        <div className={styles.textOrButtons}>
          <div className={styles.skip}>Skip</div>
          <div className={styles.buttons}>
            <img className={styles.heartIcon} alt="" src="/heart1.svg" />
            <img className={styles.heartIcon} alt="" src="/sharenetwork1.svg" />
            <img
              className={styles.heartIcon}
              alt=""
              src="/dotsthreevertical1.svg"
            />
          </div>
        </div>
      </div>
      <div className={styles.frame70container}>
        <div className={styles.content}>
          <div className={styles.variation}>
            <div className={styles.title}>
              <b className={styles.extraSauce}>Variation</b>
              <div className={styles.required}>Required</div>
            </div>
            <div className={styles.list}>
              <div className={styles.listGeneral}>
                <div className={styles.container}>
                  <div className={styles.radioButtons}>
                    <div className={styles.vector} />
                    <img
                      className={styles.vectorIcon}
                      alt=""
                      src="/vector.svg"
                    />
                  </div>
                  <div className={styles.label}>8”</div>
                  <div className={styles.trailingContent}>
                    <div className={styles.label}>$10</div>
                  </div>
                </div>
                <img className={styles.dividerIcon} alt="" src="/divider.svg" />
              </div>
              <div className={styles.listGeneral}>
                <div className={styles.container}>
                  <div className={styles.radioButtons}>
                    <div className={styles.vector} />
                    <img
                      className={styles.vectorIcon}
                      alt=""
                      src="/vector1.svg"
                    />
                  </div>
                  <div className={styles.label}>10”</div>
                  <div className={styles.trailingContent}>
                    <div className={styles.label}>$12</div>
                  </div>
                </div>
                <img className={styles.dividerIcon} alt="" src="/divider.svg" />
              </div>
              <div className={styles.listGeneral}>
                <div className={styles.container}>
                  <div className={styles.radioButtons}>
                    <div className={styles.vector} />
                    <img
                      className={styles.vectorIcon}
                      alt=""
                      src="/vector.svg"
                    />
                  </div>
                  <div className={styles.label}>12”</div>
                  <div className={styles.trailingContent}>
                    <div className={styles.label}>$16</div>
                  </div>
                </div>
                <img className={styles.dividerIcon} alt="" src="/divider.svg" />
              </div>
            </div>
          </div>
          <div className={styles.spacer}>
            <div className={styles.spacer1} />
          </div>
          <div className={styles.instructions}>
            <div className={styles.title1}>
              <b className={styles.quanity}>Quanity</b>
              <b className={styles.quanity1}>Quanity</b>
            </div>
            <div className={styles.textField}>
              <img className={styles.heartIcon} alt="" src="/minus.svg" />
              <div className={styles.label}>01</div>
              <img className={styles.heartIcon} alt="" src="/plus.svg" />
            </div>
          </div>
          <div className={styles.spacer}>
            <div className={styles.spacer1} />
          </div>
          <div className={styles.variation}>
            <div className={styles.title}>
              <b className={styles.extraSauce}>Extra Sauce</b>
              <div className={styles.required1}>Required</div>
            </div>
            <div className={styles.list}>
              <div className={styles.listGeneral}>
                <div className={styles.container}>
                  <img
                    className={styles.heartIcon}
                    alt=""
                    src="/checkbox.svg"
                  />
                  <div className={styles.label}>Texas Barbeque</div>
                  <div className={styles.trailingContent}>
                    <div className={styles.label}>+$6</div>
                  </div>
                </div>
                <img className={styles.dividerIcon} alt="" src="/divider.svg" />
              </div>
              <div className={styles.listGeneral}>
                <div className={styles.container}>
                  <img
                    className={styles.heartIcon}
                    alt=""
                    src="/checkbox1.svg"
                  />
                  <div className={styles.label}>Char Donay</div>
                  <div className={styles.trailingContent}>
                    <div className={styles.label}>+$8</div>
                  </div>
                </div>
                <img className={styles.dividerIcon} alt="" src="/divider.svg" />
              </div>
            </div>
          </div>
          <div className={styles.spacer}>
            <div className={styles.spacer1} />
          </div>
          <div className={styles.instructions}>
            <div className={styles.title1}>
              <b className={styles.quanity}>Instructions</b>
              <div className={styles.letUsKnow}>
                Let us know if you have specific things in mind
              </div>
            </div>
            <div className={styles.textField1}>
              <div className={styles.label}>e.g. less spices, no mayo etc</div>
            </div>
          </div>
          <div className={styles.spacer}>
            <div className={styles.spacer1} />
          </div>
          <div className={styles.instructions3}>
            <div className={styles.title1}>
              <b className={styles.instructions4}>Instructions</b>
              <b className={styles.ifTheProduct}>
                If the product is not available
              </b>
            </div>
            <div className={styles.textField2}>
              <div className={styles.label}>Remove it from my order</div>
              <img className={styles.heartIcon} alt="" src="/caretdown.svg" />
            </div>
          </div>
        </div>
      </div>
      <div className={styles.frame69layer}>
        <div className={styles.cartBottomBar}>
          <b className={styles.b}>$20</b>
          <button className={styles.button} onClick={onButtonClick}>
            <b className={styles.button1}>Add to cart</b>
          </button>
        </div>
      </div>
      <div className={styles.homeIndicator}>
        <div className={styles.homeIndicator1} />
      </div>
    </div>
  );
};

export default CustomerOrder1;
