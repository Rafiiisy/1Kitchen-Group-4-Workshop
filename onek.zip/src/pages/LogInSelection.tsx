import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./LogInSelection.module.css";

const LogInSelection: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrame37449Click = useCallback(() => {
    navigate("/login");
  }, [navigate]);

  const onFrame37448Click = useCallback(() => {
    // Please sync "log-in-nope" to the project
  }, []);

  const onFrame37447Click = useCallback(() => {
    navigate("/login");
  }, [navigate]);

  return (
    <div className={styles.logInSelection}>
      <div className={styles.frame37446}>
        <b className={styles.welcome}>Welcome!</b>
        <b className={styles.pleaseChooseAccordingly}>
          Please choose accordingly!
        </b>
      </div>
      <img className={styles.ellipse6Icon} alt="" src="/ellipse63.svg" />
      <div className={styles.frame37449Parent}>
        <button className={styles.frame37449} onClick={onFrame37449Click}>
          <b className={styles.driver}>Driver</b>
          <img className={styles.icon} alt="" src="/45672181@2x.png" />
        </button>
        <button className={styles.frame37448} onClick={onFrame37448Click}>
          <b className={styles.merchant}>Merchant</b>
          <img
            className={styles.avd437689ef3a02914ac11Icon}
            alt=""
            src="/avd437689ef3a02914ac11@2x.png"
          />
        </button>
        <button className={styles.frame37447} onClick={onFrame37447Click}>
          <b className={styles.customer}>Customer</b>
          <img
            className={styles.icons8ShoppingCart901}
            alt=""
            src="/icons8shoppingcart901@2x.png"
          />
        </button>
      </div>
    </div>
  );
};

export default LogInSelection;
