import { FunctionComponent, useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./SuccessLogIn.module.css";

const SuccessLogIn: FunctionComponent = () => {
  const navigate = useNavigate();
  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add(styles.animate);
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  const onContinueToLogInClick = useCallback(() => {
    navigate("/home-customer");
  }, [navigate]);

  return (
    <div className={styles.successLogIn}>
      <div className={styles.successParent}>
        <b className={styles.success}>Success!</b>
        <b
          className={styles.youSuccessfullyLogged}
        >{`You successfully logged in to your account! `}</b>
      </div>
      <div className={styles.asset11Parent}>
        <img
          className={styles.asset11Icon}
          alt=""
          src="/asset-1-1.svg"
          data-animate-on-scroll
        />
        <div className={styles.continueToLogIn}>
          <b className={styles.continueToLog}>Continue to</b>
        </div>
        <button
          className={styles.continueToLogIn1}
          onClick={onContinueToLogInClick}
        >
          <b className={styles.continueToLog1}>Home</b>
        </button>
      </div>
    </div>
  );
};

export default SuccessLogIn;
