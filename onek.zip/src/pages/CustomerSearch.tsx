import { FunctionComponent, useCallback } from "react";
import "antd/dist/antd.min.css";
import { Input } from "antd";
import {
  DownOutlined,
  ArrowLeftOutlined,
  ArrowRightOutlined,
  CalendarOutlined,
  CheckOutlined,
  ClockCircleOutlined,
  CloseOutlined,
  DeleteOutlined,
  EditOutlined,
  ExclamationCircleOutlined,
  HeartOutlined,
  LeftOutlined,
  LockOutlined,
  MailOutlined,
  PaperClipOutlined,
  PhoneOutlined,
  QuestionCircleOutlined,
  ReloadOutlined,
  RightOutlined,
  SearchOutlined,
  SendOutlined,
  ShareAltOutlined,
  UserOutlined,
} from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import styles from "./CustomerSearch.module.css";

const CustomerSearch: FunctionComponent = () => {
  const navigate = useNavigate();

  const onPizzaClick = useCallback(() => {
    navigate("/customersearchcategory-2");
  }, [navigate]);

  const onBurger95Click = useCallback(() => {
    navigate("/customersearchcategory-1");
  }, [navigate]);

  const onSearchButtonClick = useCallback(() => {
    // Please sync "xxx" to the project
  }, []);

  const onAccountButtonClick = useCallback(() => {
    navigate("/menu-customer");
  }, [navigate]);

  return (
    <div className={styles.customerSearch}>
      <header className={styles.frame84}>
        <h6 className={styles.search}>Search</h6>
        <Input
          className={styles.searchBar}
          type="text"
          style={{ width: "259px" }}
          prefix={<SearchOutlined />}
          size="middle"
          placeholder="What are you craving?"
          allowClear
        />
      </header>
      <div className={styles.frame37431}>
        <button className={styles.sushi}>
          <div className={styles.burger}>Sushi</div>
        </button>
        <button className={styles.thai}>
          <div className={styles.burger}>Thai</div>
        </button>
        <button className={styles.pizza} onClick={onPizzaClick}>
          <div className={styles.burger}>Pizza</div>
        </button>
        <button className={styles.tortilla}>
          <div className={styles.burger}>Tortilla</div>
        </button>
        <button className={styles.burger95} onClick={onBurger95Click}>
          <div className={styles.burger}>Burger</div>
        </button>
        <div className={styles.rectangle160} />
        <div className={styles.mexican}>Mexican</div>
        <div className={styles.rectangle159} />
        <div className={styles.wings}>Wings</div>
        <div className={styles.rectangle158} />
        <div className={styles.chinese}>Chinese</div>
        <div className={styles.rectangle157} />
        <div className={styles.indian}>Indian</div>
        <div className={styles.rectangle165} />
        <div className={styles.vegetarian}>Vegetarian</div>
        <div className={styles.rectangle163} />
        <div className={styles.rectangle163} />
        <div className={styles.salad}>Salad</div>
        <div className={styles.rectangle162} />
        <div className={styles.padang}>Padang</div>
        <div className={styles.rectangle161} />
        <div className={styles.fastFood}>Fast Food</div>
        <div className={styles.rectangle170} />
        <div className={styles.taco}>Taco</div>
        <div className={styles.rectangle169} />
        <div className={styles.coffee}>Coffee</div>
        <div className={styles.rectangle168} />
        <div className={styles.italian}>Italian</div>
        <div className={styles.rectangle166} />
        <div className={styles.kebab}>Kebab</div>
        <div className={styles.rectangle167} />
        <div className={styles.steak}>Steak</div>
        <div className={styles.rectangle171} />
        <div className={styles.sandwich}>Sandwich</div>
        <div className={styles.rectangle172} />
        <div className={styles.falafel}>Falafel</div>
        <div className={styles.rectangle173} />
        <div className={styles.kosher}>Kosher</div>
      </div>
      <h1 className={styles.popularCategories}>Popular categories</h1>
      <b className={styles.myRecentOrders}>My recent orders</b>
      <div className={styles.frame37428}>
        <img className={styles.intersectIcon} alt="" src="/intersect@2x.png" />
        <div className={styles.km}>3,5 km</div>
        <div className={styles.min}>{`20- 40 min `}</div>
        <button className={styles.greenCurry}>Green Curry</button>
        <div className={styles.indianCurries}>Indian, Curries</div>
        <div className={styles.div}>4.7</div>
        <img className={styles.vectorStarIcon} alt="" src="/vectorstar.svg" />
      </div>
      <div className={styles.frame37429}>
        <img className={styles.intersectIcon} alt="" src="/intersect1@2x.png" />
        <div className={styles.km}>3,5 km</div>
        <div className={styles.min}>{`20- 40 min `}</div>
        <button className={styles.greenCurry}>Suhi Tei</button>
        <div className={styles.indianCurries}>Japanies, Sushi</div>
        <div className={styles.div}>4.7</div>
        <img className={styles.vectorStarIcon} alt="" src="/vectorstar1.svg" />
      </div>
      <div className={styles.frame37430}>
        <img className={styles.intersectIcon} alt="" src="/intersect1@2x.png" />
        <div className={styles.km}>3,5 km</div>
        <div className={styles.min}>{`20- 40 min `}</div>
        <button className={styles.greenCurry}>Pizza Hut</button>
        <div className={styles.indianCurries}>Italian, Pizza</div>
        <div className={styles.div}>4.7</div>
        <img className={styles.vectorStarIcon} alt="" src="/vectorstar1.svg" />
      </div>
      <footer className={styles.frame85}>
        <footer className={styles.footer}>
          <button className={styles.homeButton}>
            <img
              className={styles.vectorHomeIcon}
              alt=""
              src="/vectorhome3.svg"
            />
            <div className={styles.home}>Home</div>
          </button>
          <button className={styles.searchButton} onClick={onSearchButtonClick}>
            <div className={styles.frame82}>
              <img
                className={styles.searchvectorIcon}
                alt=""
                src="/searchvector.svg"
              />
              <div className={styles.explore}>Explore</div>
            </div>
          </button>
          <div className={styles.ordersButton}>
            <img
              className={styles.vectorClockIcon}
              alt=""
              src="/vectorclock.svg"
            />
            <div className={styles.orders}>Orders</div>
          </div>
          <button
            className={styles.accountButton}
            onClick={onAccountButtonClick}
          >
            <img
              className={styles.vectorUserIcon}
              alt=""
              src="/vectoruser4.svg"
            />
            <div className={styles.account}>Account</div>
          </button>
        </footer>
      </footer>
    </div>
  );
};

export default CustomerSearch;
