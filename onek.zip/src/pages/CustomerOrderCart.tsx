import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./CustomerOrderCart.module.css";

const CustomerOrderCart: FunctionComponent = () => {
  const navigate = useNavigate();

  const onGroup37401ContainerClick = useCallback(() => {
    navigate("/customerorder-1");
  }, [navigate]);

  const onOrangeCheckoutButtonClick = useCallback(() => {
    navigate("/customerordersuccession");
  }, [navigate]);

  return (
    <div className={styles.customerOrderCart}>
      <div className={styles.frame72containertopBar}>
        <div className={styles.group37401} onClick={onGroup37401ContainerClick}>
          <div className={styles.cart}>Cart</div>
          <img className={styles.vectorIcon} alt="" src="/vector4.svg" />
          <img className={styles.image2Icon} alt="" src="/image21@2x.png" />
        </div>
      </div>
      <div className={styles.frame71container}>
        <div className={styles.rp16850000}>Rp. 168.500.00</div>
        <div className={styles.total}>Total</div>
        <button
          className={styles.orangeCheckoutButton}
          onClick={onOrangeCheckoutButtonClick}
        >
          <div className={styles.rectangle8} />
          <div className={styles.checkout}>Checkout</div>
        </button>
      </div>
      <div className={styles.frame53container}>
        <div className={styles.group37412}>
          <div className={styles.rectangle12} />
          <div className={styles.whopperComboM}>Whopper Combo M..</div>
          <div className={styles.rp4750000}>Rp. 47.500,00</div>
          <div className={styles.numberOfBoogers}>
            <button className={styles.rectangle10} />
            <img className={styles.plusIcon} alt="" src="/plus1.svg" />
            <div className={styles.div}>1</div>
            <img className={styles.vectorIcon1} alt="" src="/vector5.svg" />
          </div>
          <img className={styles.image4Icon} alt="" src="/image41@2x.png" />
          <img className={styles.iconTrash} alt="" src="/icontrash.svg" />
        </div>
        <div className={styles.group37411}>
          <div className={styles.rectangle12} />
          <div className={styles.btsMeal}>BTS Meal</div>
          <div className={styles.rp9050000}>Rp. 90.500,00</div>
          <div className={styles.numberOfBoogers1}>
            <div className={styles.rectangle101} />
            <img className={styles.plusIcon} alt="" src="/plus1.svg" />
            <div className={styles.div}>2</div>
            <img className={styles.vectorIcon1} alt="" src="/vector5.svg" />
          </div>
          <img className={styles.image3Icon} alt="" src="/image31@2x.png" />
          <img className={styles.iconTrash1} alt="" src="/icontrash.svg" />
        </div>
        <div className={styles.group37410}>
          <div className={styles.rectangle12} />
          <img className={styles.iconTrash1} alt="" src="/icontrash.svg" />
          <div className={styles.popeyesChickenSa}>Popeye’s Chicken Sa...</div>
          <div className={styles.rp47500001}>Rp. 47.500,00</div>
          <div className={styles.numberOfBoogers2}>
            <div className={styles.rectangle101} />
            <img className={styles.plusIcon} alt="" src="/plus1.svg" />
            <div className={styles.div}>1</div>
            <img className={styles.vectorIcon1} alt="" src="/vector5.svg" />
          </div>
          <img className={styles.image5Icon} alt="" src="/image41@2x.png" />
        </div>
        <div className={styles.rectangle15} />
        <div className={styles.whopperComboM1}>Whopper Combo M..</div>
        <div className={styles.rp47500002}>Rp. 47.500,00</div>
        <div className={styles.numberOfBoogers3}>
          <div className={styles.rectangle101} />
          <img className={styles.plusIcon} alt="" src="/plus1.svg" />
          <div className={styles.div}>1</div>
          <img className={styles.vectorIcon1} alt="" src="/vector5.svg" />
        </div>
        <img className={styles.image4Icon1} alt="" src="/image41@2x.png" />
        <img className={styles.iconTrash3} alt="" src="/icontrash1.svg" />
        <img className={styles.iconTrash4} alt="" src="/icontrash.svg" />
        <div className={styles.group37414}>
          <div className={styles.rectangle12} />
          <div className={styles.whopperComboM2}>Whopper Combo M..</div>
          <div className={styles.rp47500003}>Rp. 47.500,00</div>
          <div className={styles.numberOfBoogers4}>
            <div className={styles.rectangle101} />
            <img className={styles.plusIcon4} alt="" src="/plus1.svg" />
            <div className={styles.div}>1</div>
            <img className={styles.vectorIcon5} alt="" src="/vector5.svg" />
          </div>
          <img className={styles.image3Icon} alt="" src="/image41@2x.png" />
          <img className={styles.iconTrash1} alt="" src="/icontrash1.svg" />
        </div>
        <div className={styles.group37413}>
          <div className={styles.rectangle12} />
          <div className={styles.whopperComboM2}>Whopper Combo M..</div>
          <div className={styles.rp47500003}>Rp. 47.500,00</div>
          <div className={styles.numberOfBoogers4}>
            <div className={styles.rectangle101} />
            <img className={styles.plusIcon4} alt="" src="/plus1.svg" />
            <div className={styles.div}>1</div>
            <img className={styles.vectorIcon5} alt="" src="/vector5.svg" />
          </div>
          <img className={styles.image5Icon2} alt="" src="/image41@2x.png" />
          <img className={styles.iconTrash6} alt="" src="/icontrash1.svg" />
        </div>
      </div>
    </div>
  );
};

export default CustomerOrderCart;
