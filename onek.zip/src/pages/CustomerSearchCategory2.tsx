import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./CustomerSearchCategory2.module.css";

const CustomerSearchCategory2: FunctionComponent = () => {
  const navigate = useNavigate();

  const onArrowDownSignToNavigate5Click = useCallback(() => {
    navigate("/customersearch");
  }, [navigate]);

  const onSearchButtonClick = useCallback(() => {
    // Please sync "xxx" to the project
  }, []);

  const onAccountButtonClick = useCallback(() => {
    navigate("/menu-customer");
  }, [navigate]);

  return (
    <div className={styles.customerSearchCategory2}>
      <div className={styles.top}>
        <div className={styles.rectangle4428} />
        <div className={styles.pizza}>Pizza</div>
        <button
          className={styles.arrowDownSignToNavigate5}
          onClick={onArrowDownSignToNavigate5Click}
        />
      </div>
      <div className={styles.didntFindWhat}>
        Didn’t find what you’re looking for?
      </div>
      <div className={styles.options}>
        <div className={styles.group37427}>
          <div className={styles.rectangle4429} />
          <img
            className={styles.mcdonaldsLogo1Icon}
            alt=""
            src="/mcdonaldslogo1@2x.png"
          />
          <div className={styles.pizzaHut}>Pizza Hut</div>
          <div className={styles.internationalFast}>
            International | Fast Food
          </div>
          <div className={styles.div}>$ - $$</div>
        </div>
        <div className={styles.group37426}>
          <div className={styles.rectangle4429} />
          <div className={styles.pizzaHut}>Domino’s</div>
          <div className={styles.internationalFast}>
            International | Fast Food
          </div>
          <div className={styles.div}>$$ - $$$</div>
          <img
            className={styles.burgerking1Icon}
            alt=""
            src="/310burgerking1@2x.png"
          />
        </div>
        <div className={styles.group37425}>
          <div className={styles.rectangle4429} />
          <div className={styles.pizzaHut}>Little Caesars</div>
          <div className={styles.internationalFast}>Burgers | Fast Food</div>
          <div className={styles.div}>{`$ `}</div>
          <img
            className={styles.burgerBangorLogoMin1Icon}
            alt=""
            src="/burgerbangorlogomin1@2x.png"
          />
        </div>
        <div className={styles.group37424}>
          <div className={styles.rectangle4429} />
          <div className={styles.pizzaHut}>Papa Murphy’s</div>
          <div className={styles.internationalFast}>Burgers | Fast Food</div>
          <div className={styles.div}>$ - $$</div>
          <img
            className={styles.bjzosq7a400x4001Icon}
            alt=""
            src="/bjzosq7a400x4001@2x.png"
          />
        </div>
        <div className={styles.group37423}>
          <div className={styles.rectangle4429} />
          <div className={styles.pizzaHut}>Papa Johns</div>
          <div className={styles.internationalFast}>
            International | Fast Food
          </div>
          <div className={styles.div}>$$ - $$$</div>
          <img
            className={styles.wendysLogo1Icon}
            alt=""
            src="/wendyslogo1@2x.png"
          />
        </div>
      </div>
      <footer className={styles.frame85}>
        <footer className={styles.footer}>
          <button className={styles.homeButton}>
            <img
              className={styles.vectorHomeIcon}
              alt=""
              src="/vectorhome1.svg"
            />
            <div className={styles.home}>Home</div>
          </button>
          <button className={styles.searchButton} onClick={onSearchButtonClick}>
            <div className={styles.frame82}>
              <img
                className={styles.searchvectorIcon}
                alt=""
                src="/searchvector.svg"
              />
              <div className={styles.explore}>Explore</div>
            </div>
          </button>
          <div className={styles.ordersButton}>
            <img
              className={styles.vectorClockIcon}
              alt=""
              src="/vectorclock1.svg"
            />
            <div className={styles.orders}>Orders</div>
          </div>
          <button
            className={styles.accountButton}
            onClick={onAccountButtonClick}
          >
            <img
              className={styles.vectorUserIcon}
              alt=""
              src="/vectoruser2.svg"
            />
            <div className={styles.account}>Account</div>
          </button>
        </footer>
      </footer>
    </div>
  );
};

export default CustomerSearchCategory2;
