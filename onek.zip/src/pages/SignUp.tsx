import { FunctionComponent, useCallback } from "react";
import { Input, Stack, Select } from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";
import styles from "./SignUp.module.css";

const SignUp: FunctionComponent = () => {
  const navigate = useNavigate();

  const onEMailComponentinputEmailText1Click = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='rectangle4400']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onFrame37461Click = useCallback(() => {
    navigate("/sign-up-2");
  }, [navigate]);

  return (
    <div className={styles.signUp}>
      <div className={styles.frame23ContainerTopBar}>
        <b className={styles.welcome}>Welcome!</b>
        <div className={styles.weWantTo}>We want to know about you</div>
      </div>
      <div className={styles.nameComponentinputNameParent}>
        <b className={styles.nameComponentinputName}>Name</b>
        <Input
          className={styles.frame37456}
          variant="flushed"
          width="304px"
          focusBorderColor="#2c7e35"
          placeholder="Enter your Full Name"
          w="304px"
        />
        <b className={styles.eMailComponentinputEmail}>E-mail</b>
        <Input
          className={styles.frame37457}
          variant="flushed"
          width="304px"
          focusBorderColor="#2c7e35"
          type="email"
          placeholder="Enter your Email address"
          w="304px"
        />
        <b
          className={styles.eMailComponentinputEmail1}
          onClick={onEMailComponentinputEmailText1Click}
        >
          Roles
        </b>
        <Stack className={styles.frame37458} w="304px">
          <Select
            variant="flushed"
            placeholder="Select  your roles"
            textColor="#868986"
            focusBorderColor="#2c7e35"
          >
            <option value="Customer">Customer</option>
            <option value="Merchant">Merchant</option>
            <option value="Driver">Driver</option>
          </Select>
        </Stack>
        <b className={styles.eMailComponentinputEmail2}>Password</b>
        <Input
          className={styles.frame37459}
          variant="flushed"
          width="304px"
          focusBorderColor="#2c7e35"
          type="password"
          placeholder="Enter your Password"
          w="304px"
        />
        <b className={styles.eMailComponentinputEmail3}>
          Password Confirmation
        </b>
        <Input
          className={styles.frame37460}
          variant="flushed"
          width="304px"
          focusBorderColor="#2c7e35"
          type="password"
          placeholder="Enter your Password"
          w="304px"
        />
        <button className={styles.frame37461} onClick={onFrame37461Click}>
          <div className={styles.rectangle4400} />
          <b className={styles.next}>Next</b>
        </button>
      </div>
    </div>
  );
};

export default SignUp;
