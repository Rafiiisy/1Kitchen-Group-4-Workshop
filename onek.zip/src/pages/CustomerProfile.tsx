import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./CustomerProfile.module.css";

const CustomerProfile: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrame25ActiongobacklayeClick = useCallback(() => {
    navigate("/home-customer");
  }, [navigate]);

  const onLogoutActionlogoutfirebaseClick = useCallback(() => {
    navigate("/login");
  }, [navigate]);

  const onRectangle4400Click = useCallback(() => {
    // Please sync "log-in-nope" to the project
  }, []);

  const onIconEditClick = useCallback(() => {
    navigate("/customerprofileedit-profile");
  }, [navigate]);

  const onGroup37354Click = useCallback(() => {
    navigate("/customerprofilefeedback");
  }, [navigate]);

  const onArrowDownSignToNavigate8IconClick = useCallback(() => {
    navigate("/customerprofilefeedback");
  }, [navigate]);

  return (
    <div className={styles.customerProfile}>
      <div className={styles.frame9ContainerTopBar}>
        <button
          className={styles.frame25Actiongobacklaye}
          onClick={onFrame25ActiongobacklayeClick}
        >
          <img
            className={styles.icons8Close301}
            alt=""
            src="/icons8close301@2x.png"
          />
        </button>
      </div>
      <button
        className={styles.logoutActionlogoutfirebase}
        onClick={onLogoutActionlogoutfirebaseClick}
      >
        <div className={styles.group37294}>
          <div
            className={styles.rectangle4400}
            onClick={onRectangle4400Click}
          />
          <b className={styles.signOut}>Sign Out</b>
        </div>
      </button>
      <div className={styles.frame11Container}>
        <div className={styles.line5} />
        <button className={styles.iconEdit} onClick={onIconEditClick}>
          <img className={styles.groupIcon} alt="" src="/group.svg" />
        </button>
        <div className={styles.line6} />
        <div className={styles.line7} />
        <div className={styles.line8} />
        <div className={styles.line11} />
        <div className={styles.line9} />
        <div className={styles.group37355}>
          <img className={styles.privacy1Icon} alt="" src="/privacy1@2x.png" />
          <div className={styles.group37332}>
            <b className={styles.privacySecurity}>{`Privacy & Security`}</b>
          </div>
          <img
            className={styles.arrowDownSignToNavigate7Icon}
            alt=""
            src="/arrowdownsigntonavigate7@2x.png"
          />
        </div>
        <button className={styles.group37354} onClick={onGroup37354Click}>
          <b className={styles.supportAndFeedback}>Support and Feedback</b>
          <img
            className={styles.arrowDownSignToNavigate8Icon}
            alt=""
            src="/arrowdownsigntonavigate7@2x.png"
            onClick={onArrowDownSignToNavigate8IconClick}
          />
          <div className={styles.support1}>
            <img
              className={styles.support1Icon}
              alt=""
              src="/support1@2x.png"
            />
          </div>
        </button>
        <div className={styles.group37352}>
          <img className={styles.privacy1Icon} alt="" src="/wallet1@2x.png" />
          <b className={styles.paymentMethods}>Payment Methods</b>
          <img
            className={styles.arrowDownSignToNavigate7Icon}
            alt=""
            src="/arrowdownsigntonavigate7@2x.png"
          />
        </div>
        <div className={styles.group37357}>
          <b className={styles.orders}>Orders</b>
          <img
            className={styles.arrowDownSignToNavigate5Icon}
            alt=""
            src="/arrowdownsigntonavigate7@2x.png"
          />
          <img className={styles.online1Icon} alt="" src="/online1@2x.png" />
        </div>
        <div className={styles.group37353}>
          <b className={styles.privacySecurity}>Invite Friends</b>
          <img
            className={styles.arrowDownSignToNavigate9Icon}
            alt=""
            src="/arrowdownsigntonavigate7@2x.png"
          />
        </div>
        <div className={styles.group37356}>
          <b className={styles.paymentMethods}>Location</b>
          <img
            className={styles.arrowDownSignToNavigate7Icon}
            alt=""
            src="/arrowdownsigntonavigate7@2x.png"
          />
          <img className={styles.privacy1Icon} alt="" src="/location1@2x.png" />
        </div>
        <img className={styles.iconPeople} alt="" src="/iconpeople.svg" />
        <div className={styles.group37328}>
          <b className={styles.spongeBob}>Sponge Bob</b>
          <div className={styles.blockBPhase}>
            Block B Phase 2 Johar Town, Lahore
          </div>
        </div>
        <img className={styles.avatarIcon} alt="" src="/avatar1.svg" />
      </div>
    </div>
  );
};

export default CustomerProfile;
