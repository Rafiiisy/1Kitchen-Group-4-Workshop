import { FunctionComponent, useState, useCallback } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Form } from "react-bootstrap";
import ConfirmationCustomer from "../components/ConfirmationCustomer";
import PortalPopup from "../components/PortalPopup";
import { useNavigate } from "react-router-dom";
import styles from "./CustomerProfileEditProfile.module.css";

const CustomerProfileEditProfile: FunctionComponent = () => {
  const [isConfirmationCustomerPopupOpen, setConfirmationCustomerPopupOpen] =
    useState(false);
  const navigate = useNavigate();

  const openConfirmationCustomerPopup = useCallback(() => {
    setConfirmationCustomerPopupOpen(true);
  }, []);

  const closeConfirmationCustomerPopup = useCallback(() => {
    setConfirmationCustomerPopupOpen(false);
  }, []);

  const onArrowleftClick = useCallback(() => {
    navigate("/menu-customer");
  }, [navigate]);

  return (
    <>
      <div className={styles.customerProfileEditProfile}>
        <img className={styles.avatarIcon} alt="" src="/avatar.svg" />
        <div className={styles.credentials}>
          <div className={styles.textFields}>
            <Form.Group className={styles.textFieldFormgroup}>
              <Form.Label>Name</Form.Label>
              <Form.Control type="text" placeholder="John Doe" />
            </Form.Group>
            <Form.Group className={styles.textFieldFormgroup}>
              <Form.Label>Email</Form.Label>
              <Form.Control type="email" placeholder="johndoe123@gmail.com" />
            </Form.Group>
            <Form.Group className={styles.textFieldFormgroup}>
              <Form.Label>Phone No.</Form.Label>
              <Form.Control type="tel" placeholder="+92 3014124781" />
            </Form.Group>
            <Form.Group className={styles.textFieldFormgroup}>
              <Form.Label>Password</Form.Label>
              <Form.Control type="password" placeholder="Input placeholder" />
            </Form.Group>
          </div>
        </div>
        <button
          className={styles.buttons}
          onClick={openConfirmationCustomerPopup}
        >
          <div className={styles.button}>
            <b className={styles.button1}>Save</b>
          </div>
        </button>
        <div className={styles.spacer}>
          <div className={styles.spacer1} />
        </div>
        <div className={styles.appBarcontainertopBar}>
          <div className={styles.bg} />
          <b className={styles.headline}>Edit Account</b>
          <button className={styles.arrowleft} onClick={onArrowleftClick}>
            <img className={styles.arrowleftIcon} alt="" src="/arrowleft.svg" />
          </button>
          <div className={styles.textOrButtons}>
            <div className={styles.skip}>Skip</div>
            <div className={styles.buttons1}>
              <img className={styles.heartIcon} alt="" src="/heart.svg" />
              <img
                className={styles.heartIcon}
                alt=""
                src="/sharenetwork.svg"
              />
              <img
                className={styles.heartIcon}
                alt=""
                src="/dotsthreevertical.svg"
              />
            </div>
          </div>
        </div>
      </div>
      {isConfirmationCustomerPopupOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeConfirmationCustomerPopup}
        >
          <ConfirmationCustomer onClose={closeConfirmationCustomerPopup} />
        </PortalPopup>
      )}
    </>
  );
};

export default CustomerProfileEditProfile;
