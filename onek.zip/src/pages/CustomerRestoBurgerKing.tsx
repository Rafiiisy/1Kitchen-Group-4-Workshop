import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./CustomerRestoBurgerKing.module.css";

const CustomerRestoBurgerKing: FunctionComponent = () => {
  const navigate = useNavigate();

  const onSearchButtonClick = useCallback(() => {
    navigate("/customersearch");
  }, [navigate]);

  const onAccountButtonClick = useCallback(() => {
    navigate("/menu-customer");
  }, [navigate]);

  return (
    <div className={styles.customerRestoBurgerKing}>
      <img
        className={styles.pexelsPhotoByValeriaBoltne}
        alt=""
        src="/pexels-photo-by-valeria-boltneva@2x.png"
      />
      <div className={styles.rectangle4394} />
      <img className={styles.kColour1Icon} alt="" src="/1kcolour1@2x.png" />
      <b className={styles.b}>4.5</b>
      <div className={styles.ratings}>560 ratings</div>
      <b className={styles.b1}>$$$</b>
      <div className={styles.div}>$15 - $45</div>
      <div className={styles.likedBy}>Liked by</div>
      <b className={styles.k}>435K</b>
      <img className={styles.heartIcon} alt="" src="/hearticon.svg" />
      <b className={styles.burgerKing}>Burger King</b>
      <div className={styles.menu}>Menu</div>
      <div className={styles.line1} />
      <div className={styles.rectangle4414Parent}>
        <div className={styles.rectangle4414} />
        <img className={styles.maskGroupIcon} alt="" src="/maskgroup@2x.png" />
        <b className={styles.burger1}>Burger 1</b>
        <b className={styles.b2}>$20</b>
      </div>
      <div className={styles.rectangle4414Group}>
        <div className={styles.rectangle4414} />
        <img className={styles.maskGroupIcon} alt="" src="/maskgroup@2x.png" />
        <b className={styles.burger2}>Burger 2</b>
        <b className={styles.b2}>$20</b>
      </div>
      <div className={styles.rectangle4414Container}>
        <div className={styles.rectangle4414} />
        <img className={styles.maskGroupIcon} alt="" src="/maskgroup@2x.png" />
        <b className={styles.burger2}>Burger 5</b>
        <b className={styles.b2}>$20</b>
      </div>
      <div className={styles.groupDiv}>
        <div className={styles.rectangle4414} />
        <img className={styles.maskGroupIcon} alt="" src="/maskgroup@2x.png" />
        <b className={styles.burger2}>Burger 6</b>
        <b className={styles.b2}>$20</b>
      </div>
      <div className={styles.rectangle4414Parent1}>
        <div className={styles.rectangle4414} />
        <img className={styles.maskGroupIcon} alt="" src="/maskgroup@2x.png" />
        <b className={styles.burger2}>Burger 3</b>
        <b className={styles.b2}>$20</b>
      </div>
      <div className={styles.rectangle4414Parent2}>
        <div className={styles.rectangle4414} />
        <img className={styles.maskGroupIcon} alt="" src="/maskgroup@2x.png" />
        <b className={styles.burger2}>Burger 4</b>
        <b className={styles.b2}>$20</b>
      </div>
      <footer className={styles.footer}>
        <button className={styles.homeButton}>
          <img className={styles.vectorHomeIcon} alt="" src="/vectorhome.svg" />
          <div className={styles.home}>Home</div>
        </button>
        <button className={styles.searchButton} onClick={onSearchButtonClick}>
          <div className={styles.frame82}>
            <img
              className={styles.searchvectorIcon}
              alt=""
              src="/searchvector.svg"
            />
            <div className={styles.explore}>Explore</div>
          </div>
        </button>
        <div className={styles.ordersButton}>
          <img
            className={styles.vectorClockIcon}
            alt=""
            src="/vectorclock.svg"
          />
          <div className={styles.orders}>Orders</div>
        </div>
        <button className={styles.accountButton} onClick={onAccountButtonClick}>
          <img className={styles.vectorUserIcon} alt="" src="/vectoruser.svg" />
          <div className={styles.account}>Account</div>
        </button>
      </footer>
    </div>
  );
};

export default CustomerRestoBurgerKing;
