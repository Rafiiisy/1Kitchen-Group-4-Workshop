import { FunctionComponent } from "react";
import styles from "./SuccessCustomer.module.css";

const SuccessCustomer: FunctionComponent = () => {
  return (
    <div className={styles.successCustomer}>
      <img className={styles.asset11Icon} alt="" src="/asset11.svg" />
      <b className={styles.success}>Success!</b>
      <b className={styles.yourSuccessfullyOrdered}>
        Your successfully ordered the items!
      </b>
      <div className={styles.continueToLogIn}>
        <b className={styles.continueToLogContainer}>
          <span>{`Continue to `}</span>
          <span className={styles.logIn}>Log In</span>
        </b>
      </div>
    </div>
  );
};

export default SuccessCustomer;
