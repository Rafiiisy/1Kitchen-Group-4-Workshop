import { FunctionComponent, useCallback } from "react";
import { Input } from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";
import styles from "./Login.module.css";

const Login: FunctionComponent = () => {
  const navigate = useNavigate();

  const onSignUpClick = useCallback(() => {
    navigate("/sign-up");
  }, [navigate]);

  const onFrame37454Click = useCallback(() => {
    navigate("/success-log-in");
  }, [navigate]);

  return (
    <div className={styles.login}>
      <header className={styles.frame37450}>
        <img className={styles.kColour1Icon} alt="" src="/1kcolour11@2x.png" />
        <b className={styles.welcomeBack}>Welcome Back!</b>
        <b className={styles.logInTo}>Log in to your account</b>
      </header>
      <div className={styles.frame37453Parent}>
        <Input
          className={styles.frame37453}
          variant="filled"
          width="304px"
          focusBorderColor="#226a20"
          size="md"
          type="password"
          placeholder="Enter your password"
          w="304px"
        />
        <b className={styles.passwordComponentinputPass}>Password</b>
        <div className={styles.frame37451}>
          <b className={styles.emailOrPhone}>{`Email `}</b>
          <Input
            className={styles.frame37452}
            variant="filled"
            width="304px"
            focusBorderColor="#2a8431"
            type="email"
            placeholder="Enter your Email address"
            w="304px"
          />
        </div>
        <button className={styles.frame37455}>
          <div className={styles.rectangle4400} />
          <b className={styles.logInWith}>Log in with your Google Account</b>
          <img className={styles.image1Icon} alt="" src="/image11@2x.png" />
        </button>
        <b className={styles.or}>OR</b>
        <b className={styles.dontHaveAn}>{`Don’t have an account? `}</b>
        <button className={styles.signUp} onClick={onSignUpClick}>
          Sign up
        </button>
        <button className={styles.frame37454} onClick={onFrame37454Click}>
          <div className={styles.rectangle44001} />
          <b className={styles.logIn}>Log In</b>
        </button>
      </div>
    </div>
  );
};

export default Login;
