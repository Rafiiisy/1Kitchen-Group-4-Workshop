import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./ConfirmationCustomer.module.css";

type ConfirmationCustomerType = {
  onClose?: () => void;
};

const ConfirmationCustomer: FunctionComponent<ConfirmationCustomerType> = ({
  onClose,
}) => {
  const navigate = useNavigate();

  const onYesClick = useCallback(() => {
    navigate("/menu-customer");
  }, [navigate]);

  return (
    <div className={styles.confirmationCustomer}>
      <div className={styles.areYouSure}>Are you sure about these changes?</div>
      <button className={styles.yes} onClick={onYesClick}>
        Yes
      </button>
      <button className={styles.no} onClick={onClose}>
        No
      </button>
      <img className={styles.line16Icon} alt="" src="/line16.svg" />
      <img className={styles.iconWarning2} alt="" src="/iconwarning2.svg" />
    </div>
  );
};

export default ConfirmationCustomer;
